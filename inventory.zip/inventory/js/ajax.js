//delete the image while uploading
$(document).on("click", ".btn_del_file", function () {
	$("#image_preview").empty();
})

$(document).ready(function () {


	/**
	 * PAGE: payments_list
	 * ADVANCE FILTER
	 * 
	 */


	//filter payments by name
	$('#pay_custo_name').select2({
		//
		minimumInputLength: 1,
		placeholder: "Select Name",
		ajax: {
			url: DOMAIN + "admin/dal?page=payments&ac=pname",
			dataType: "json",
			data: function (term, page) {
				return {
					memcode: term
				};
			},
			results: function (data) {
				var results = [{ id: "0", text: "none" }];
				$.each(data, function (index, item) {
					results.push({
						id: item.pay_custo_name,
						text: item.pay_custo_name,
					});
				});
				return {
					results: results,
				};
			}
		},
	});
	//filter payments by contact
	$("#pay_custo_contact").select2({
		//
		minimumInputLength: 1,
		placeholder: "Select Contact",
		ajax: {
			url: DOMAIN + "admin/dal?page=payments&ac=pcontact",
			dataType: "json",
			data: function (term, page) {
				return {
					memcode: term
				};
			},
			results: function (data) {
				var results = [{ id: "0", text: "none" }];
				$.each(data, function (index, item) {
					results.push({
						id: item.pay_custo_contact,
						text: item.pay_custo_contact,
					});
				});
				return {
					results: results,
				};
			}
		},
	});
	//filter payments by patient type
	$("#pay_custo_type").select2({
		//
		minimumInputLength: 1,
		placeholder: "Select Type",
		ajax: {
			url: DOMAIN + "admin/dal?page=payments&ac=ptype",
			dataType: "json",
			data: function (term, page) {
				return {
					memcode: term
				};
			},
			results: function (data) {
				var results = [{ id: "0", text: "none" }];
				$.each(data, function (index, item) {
					results.push({
						id: item.pay_custo_type,
						text: item.pay_custo_type,
					});
				});
				return {
					results: results,
				};
			}
		},
	});


	//select2 used in product code in advance sale filter 
	$(".product_code").select2({
		multiple: false,
		minimumInputLength: 1,
		placeholder: "Select Product",
		ajax: {
			url: DOMAIN + "admin/dal",
			dataType: "json",
			data: function (term, page) {
				return {
					pcode: term
				};
			},
			results: function (data) {
				var results = [{ id: "0", text: "none" }];
				$.each(data, function (index, item) {
					results.push({
						id: item.p_code,
						text: item.p_name,
					});
				});
				return {
					results: results,
				};
			}
		},
	})
	//select2 to add product in packages
	$("#pro_code").select2({
		multiple: false,
		minimumInputLength: 1,
		placeholder: "Select a product",
		ajax: {
			url: DOMAIN + "admin/dal",
			dataType: "json",
			data: function (term, page) {
				return {
					pcode: term
				};
			},
			results: function (data) {
				var results = [{ id: "0", text: "none" }];
				$.each(data, function (index, item) {
					results.push({
						id: item.p_code,
						text: item.p_name,
					});
				});
				return {
					results: results,
				};
			}
		},
	})

	//member code ajax select2 js
	$("#mem_code").select2({
		minimumInputLength: 1,
		placeholder: "Select a Member",
		ajax: {
			url: DOMAIN + "admin/dal",
			dataType: "json",
			data: function (term, page) {
				return {
					memcode: term
				};
			},
			results: function (data) {
				var results = [{ id: "0", text: "none" }];
				$.each(data, function (index, item) {
					results.push({
						id: item.mem_code,
						text: item.mem_fname + " " + item.mem_lname,
					});
				});
				return {
					results: results,
				};
			}
		},
	})
	$("#mem_code_cart").select2({
		minimumInputLength: 1,
		placeholder: "Select a Member",
		ajax: {
			url: DOMAIN + "admin/dal",
			dataType: "json",
			data: function (term, page) {
				return {
					memcodecart: term
				};
			},
			results: function (data) {
				var results = [{ id: "0", text: "none" }];
				$.each(data, function (index, item) {
					results.push({
						id: item.mem_code,
						text: item.mem_fname + " " + item.mem_lname + " [ " + item.mem_contact + " ]",
					});
				});
				return {
					results: results,
				};
			}
		},
	})

})
$(document).on("change", "#main_cat", function () {
	var main_val = $(this).val();
	if (parseInt(main_val) > 0) {
		data = "action=get-sub-cat&main-cat-id=" + main_val;
		$.post(DOMAIN + "admin/dal", data, function (res) {
			$("#sub_cat").html(res);
		})
	}

})
$(document).on("change", "#sub_cat", function () {
	var sub_val = $(this).val();
	if (parseInt(sub_val) > 0) {
		data = "action=get-leaf-cat&sub-cat-id=" + sub_val;
		$.post(DOMAIN + "admin/dal", data, function (res) {
			$("#p_leaf_cat").html(res);
		})
	}
})

/***************stock out page*********************/
$(document).on("click", ".btn_get_stock_return_form", function () {

	dataString = "action=get_return_form&sid=" + $(this).attr("sid") + "&code=" + $(this).attr("pcode");

	$.ajax({
		type: "POST",
		url: DOMAIN + "admin/dal",
		data: dataString,
		dataType: "html",
		success: function (data) {
			$(".return_form").html(data);
		}
	})
})

/***********************product page********************/
///show add to cart form 
$(document).on("click", ".btn-add-to-cart", function () {
	dataString = "action=get_cart_form&code=" + $(this).attr("code");
	$.ajax({
		type: "POST",
		url: DOMAIN + "admin/dal",
		data: dataString,
		dataType: "html",
		success: function (data) {
			$(".cart_form").html(data);
		}
	})
})

//submit the add to cart form
$(document).on("click", "#p_add_to_cart", function () {

	var q_entered = $("#cart_qty").val();
	$(".overlay").delay(1000).show();
	$(".success_msg_cart").hide();

	if ((q_entered) == "") {
		q_entered = 0;
	}

	var q_left = $("#q_left").val();
	count = $(".cart_cnt").text();
	if (count == "") {
		count = 0;
	} else {
		count = parseInt(count);
	}


	// product id
	var p_id = $("#p_id").val();

	//end product id
	if (parseInt(q_entered) > parseInt(q_left)) {
		$(".overlay").hide();
		$(".mesg").html('<div class="alert alert-danger"><button class="close" data-dismiss="alert"></button><strong><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Error ! </strong> Product limit exceed</div>');
	}
	else if (parseInt(q_entered) == 0) {
		$(".overlay").hide();
		$(".mesg").html('<div class="alert alert-danger"><button class="close" data-dismiss="alert"></button><strong><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Error ! </strong> Enter the quantity</div>');
	}

	else {
		dataString = "action=save_in_cart&pcode=" + $("#cart_pcode").val() + "&qty=" + $("#cart_qty").val() + "&pid=" + $("#p_id").val();
		$.ajax({
			type: "POST",
			url: DOMAIN + "admin/dal",
			data: dataString,
			dataType: "html",
			success: function (data) {
				if (data == 1) {
					$(".overlay").hide();
					$(".success_msg_cart").show();
					$(".count_cart").css("display", "block");
					count = count + 1;
					$(".cart_cnt").text(count);
				}
				else {
					$(".btn_cart_form_close").trigger("click");
					$(".cart_msg").html(data).fadeOut(6000);
				}
			}
		})
	}
})

$(document).on("click", ".btn_stock_in,.btn_edit_stockin", function () {
	var $code = $(this).attr("code");
	var pid = $(this).attr("pid");

	$("#pa_code").val($code);
	$("#pid").val(pid);
	var data = "action=get_pname_forModal&code=" + $code;

	$.post(DOMAIN + "admin/dal", data, function (res) {
		var name = JSON.parse(res);
		$("#pname").val(name.p_name);
	})
})

/***********to view the image of the product on product name click in table************/
$(document).on("click", ".p_image_hover", function () {
	var image_val = $(this).attr("pimg");
	if (image_val == "") {
		$(".pro_image_view").html("<h4>No image.</h4>");
	}
	else {
		$(".pro_image_view").html('<img src="' + DOMAIN + PRODUCT_IMAGE + image_val + '" height="200" width="200">');
	}
})
///

