<?php
session_start();
require_once("conn.php");
/* Master User Class */
class User
{
	private $user_info;
	private $userid;
	private $islogged;
	private $user_type;
	public function __construct()
	{
		if (isset($_SESSION["userid"]) && $_SESSION["userid"] != 0) {
			$this->islogged = true;
			$this->user_info = $_SESSION["username"];
			$this->userid = $_SESSION["userid"];
			$this->user_type = $_SESSION['user_type'];
		} else {
			$this->islogged = false;
			$this->user_info = 0;
			$this->userid = 0;
			$this->user_type = 0;
		}
	}
	function __get($what)
	{
		return $this->$what;
	}
	function __isset($what)
	{
		$val = $this->__get($what);
		return isset($val);
	}

	public function db_add($table, $data)
	{
		return db_add_values($table, $data);
	}
	//login reqired
	public function login_required()
	{
		if ($this->islogged == false) {
			//$_SESSION["_goto"]= "http://" . $_SERVER['HTTP_HOST'] . "/" .$_SERVER['PHP_SELF'] . "?" . $_SERVER['QUERY_STRING'];
			//header("location:".$this->domain."logout");
			header('location:' . _DOMAIN_ . "login");
		}
	}
	//return true if username & password is matched
	public function is_valid_admin($username, $password)
	{
		global $mysqli;
		$username = $mysqli->escape_string($username);
		$password = htmlspecialchars($password);
		$result = db_get_table("login_tbl", "*", array("username" => $username, "password" => md5($password)), "limit 1");

		if (count($result) > 0) {
			$this->islogged = true;
			$_SESSION["userid"] = $result[0]["log_id"];
			$_SESSION["username"] = $result[0]['username'];
			$_SESSION['user_type'] = $result[0]['user_type'];
			return true;
		} else {
			return false;
		}
	}

	//logout the current user
	public function logout()
	{
		$this->islogged = false;
		$_SESSION["userid"] = 0;
		$_SESSION["user_info"] = 0;
		$_SESSION['user_type']	= 0;
	}

	//to send mail 
	public function sendmail($to, $subject, $body)
	{
		include_once("email.php");
		if (mail($to, $subject, $message, $headers))
			return true;
		else
			return false;
	}
}
class Page
{
	private $title;
	public $page_init;
	public $domain;
	public $path;
	public $file;
	public $file_url;
	private $template;
	public $inc;
	public $user;

	public function __construct()
	{
		$this->user = new User();
		$this->page_init = false;
		$this->domain = constant("_DOMAIN_");
		$this->file = "index";
		$this->inc = array('sidebar', 'footer');
		$this->get_path();
	}
	private function get_path()
	{
		$uri = explode("?", $_SERVER["REQUEST_URI"]);
		$url = "http://$_SERVER[HTTP_HOST]" . $uri[0];
		$this->path = str_replace($this->domain, "", $url);

		$path = explode("/", $this->path);

		if (substr($this->path, -1) == "/") {
			if (file_exists($this->path . "index.php"))
				$this->file = 'index';
			else
				$this->path = substr($this->path, 0, -1);
		} elseif (file_exists("view/" . $this->path . ".php")) {
			$this->file = end($path);
			if ($this->file == $this->path)
				$this->path = "";
			else
				$this->path = str_replace("/" . $this->file, "", $this->path);
		}
		$this->file_url = "view/" . ($this->path == "" ? '' : $this->path . "/") . $this->file . ".php";
	}
	public function file_url($p, $f)
	{
		$this->path = $p;
		$this->file = $f;
		$this->file_url = "view/" . ($this->path == "" ? '' : $this->path . "/") . $this->file . ".php";
	}
	public function page_init($template = "default", $title = "", $js = array(), $css = array())
	{
		$this->template = $template;
		$this->page_init = true;
		include_once("template/$template/html.php");
	}
	public function template_file($file)
	{
		include_once("template/" . $this->template . "/" . $file);
	}
	//Error Handling
	public function error()
	{
		error_log("\r\n" . date("D M j G:i:s T Y") . "\tError:Page not found \t" . $_SERVER['HTTP_HOST'] . $_SERVER["REQUEST_URI"] . "\t" . $_SERVER['REMOTE_ADDR'], 3, "my-errors.log");
		//header("location:".$this->domain._ERROR_PAGE);
	}
}
