<?php
class productApp
{

	/**** get product price and quantity left from product_tbl to display in the sales when product code is entered 
	--to auto fill the quantity and price field of the form when product code is entered 
	--- takes the product code(varchar) as an arguement****/
	public function get_product_details($code)
	{
		$ssal = db_get_table("stock_out_tbl", "sal_id", array('sal_product_code' => $code));

		if (count($ssal) > 0) {
			$ret = db_get_table("return_tbl", "r_id", array('r_p_code' => $code));


			// if (count($ret) == 0) {
			// 	$sql = "SELECT A.totalqty - B.soldqty  as p_left ,p_name,p_price,p_code
			// 			FROM 
			// 			(
			// 			SELECT SUM(p_quantity) totalqty,p_price,p_code,p_name
			// 			FROM product_tbl
			// 				where p_code='" . $code . "'

			// 			)A, 
			// 			(
			// 			SELECT SUM(sal_product_qty) soldqty,sal_product_code
			// 			FROM stock_out_tbl 
			// 				WHERE sal_product_code='" . $code . "'

			// 			)B
			// 			WHERE A.p_code = B.sal_product_code";
			// } else {
			// 	$sql = "SELECT A.totalqty - (B.soldqty - C.rqty)  as p_left,p_name ,p_price,p_code
			// 			FROM 
			// 			(
			// 			SELECT SUM(p_quantity) totalqty,p_price,p_code,p_name
			// 			FROM product_tbl
			// 				where p_code='" . $code . "'

			// 			)A, 
			// 			(
			// 			SELECT SUM(sal_product_qty) soldqty,sal_product_code
			// 			FROM stock_out_tbl 
			// 				WHERE sal_product_code='" . $code . "'

			// 			)B,
			// 			(
			// 			SELECT sum(r_qty) rqty,r_p_code
			// 			FROM return_tbl
			// 				where r_p_code='" . $code . "'

			// 			)C

			// 			WHERE A.p_code = B.sal_product_code ";
			// }

			/**
			 * NEW QUERY FOR p_id
			 */
			if (count($ret) == 0) {
				$sql = "SELECT A.totalqty - B.soldqty  as p_left ,p_id,p_name,p_price,p_code
 						FROM 
 						(
 						SELECT SUM(p_quantity) totalqty,p_price,p_code,p_id,p_name
 						FROM product_tbl
 							where p_code='" . $code . "'
 						
 						)A, 
 						(
 						SELECT SUM(sal_product_qty) soldqty,sal_product_code
 						FROM stock_out_tbl 
 							WHERE sal_product_code='" . $code . "'
 						
 						)B
 						WHERE A.p_code = B.sal_product_code";
			} else {
				$sql = "SELECT A.totalqty - (B.soldqty - C.rqty)  as p_left,p_id,p_name ,p_price,p_code
 						FROM 
 						(
 						SELECT SUM(p_quantity) totalqty,p_id,p_price,p_code,p_name
 						FROM product_tbl
 							where p_code='" . $code . "'
 						
 						)A, 
 						(
 						SELECT SUM(sal_product_qty) soldqty,sal_product_code
 						FROM stock_out_tbl 
 							WHERE sal_product_code='" . $code . "'
 						
 						)B,
 						(
 						SELECT sum(r_qty) rqty,r_p_code
 						FROM return_tbl
 							where r_p_code='" . $code . "'
 						
 						)C
 						
 						WHERE A.p_code = B.sal_product_code ";
			}

			$res = db_get_table_sql($sql);
			if (count($res) > 0)
				return $res[0];
			else
				return 0;
		} else {
			$sql = "SELECT p_price,sum(p_quantity) as p_left ,p_name,p_id,p_code from product_tbl  where p_code='" . $code . "'";
			//echo $sql;
			$res = db_get_table_sql($sql);
			if (count($res) > 0)
				return $res[0];
			else
				return 0;
		}
	}
	public function get_total_stock_price()
	{
		$pro = db_get_table("product_tbl", "p_id,p_code", array());
		$tprice = 0;
		foreach ($pro as $p) :
			$res = $this->get_product_left($p['p_code']);;
			if ($res != 0) {
				$tprice = $tprice + ($res['p_left'] * $res['p_price']);
			}
		endforeach;
		return round($tprice, 3);
	}
	//get the product left in the stock
	public function get_product_left($code)
	{
		$ssal = db_get_table("stock_out_tbl", "sal_id", array('sal_product_code' => $code));

		if (count($ssal) > 0) {
			$ret = db_get_table("return_tbl", "r_id", array('r_p_code' => $code));

			if (count($ret) == 0) {
				$sql = "SELECT A.totalqty - B.soldqty  as p_left ,p_price
 						FROM 
 						(
 						SELECT SUM(p_quantity) totalqty,p_price,p_code
 						FROM product_tbl
 							where p_code='" . $code . "'
 						
 						)A, 
 						(
 						SELECT SUM(sal_product_qty) soldqty,sal_product_code
 						FROM stock_out_tbl 
 							WHERE sal_product_code='" . $code . "'
 						
 						)B
 						WHERE A.p_code = B.sal_product_code";
			} else {
				$sql = "SELECT A.totalqty - (B.soldqty - C.rqty)  as p_left ,p_price
 						FROM 
 						(
 						SELECT SUM(p_quantity) totalqty,p_price,p_code
 						FROM product_tbl
 							where p_code='" . $code . "'
 						
 						)A, 
 						(
 						SELECT SUM(sal_product_qty) soldqty,sal_product_code
 						FROM stock_out_tbl 
 							WHERE sal_product_code='" . $code . "'
 						
 						)B,
 						(
 						SELECT sum(r_qty) rqty,r_p_code
 						FROM return_tbl
 							where r_p_code='" . $code . "'
 						
 						)C
 						
 						WHERE A.p_code = B.sal_product_code ";
			}
			$res = db_get_table_sql($sql);
			if (count($res) > 0)
				return $res[0];
			else
				return 0;
		} else {
			$sql = "SELECT p_price,sum(p_quantity) as p_left from product_tbl where p_code='" . $code . "'";

			$res = db_get_table_sql($sql);
			if (count($res) > 0)
				return $res[0];
			else
				return 0;
		}
	}

	public function get_all_products_for_dashboard()
	{
		$sql = " SELECT count(p_id) as pro from product_tbl where 1";
		$res = db_get_table_sql($sql);
		return ($res[0]['pro']);
	}
	//for to count all products added today
	public function get_todays_product()
	{
		$today = date("Y-m-d");
		$sql = " SELECT count(p_id) as pro from product_tbl where `p_added_date` like '%%" . $today . "%%'";
		$res = db_get_table_sql($sql);
		return ($res[0]['pro']);
	}
	public function get_all_product($curr_yr, $curr_mth)
	{
		$sql = " SELECT count(p_id) as pro from product_tbl where `p_added_date` like '%%" . $curr_yr . "-" . $curr_mth . "%%'";

		$res = db_get_table_sql($sql);
		return ($res[0]['pro']);
	}

	//get_todays_in_out_patient
	public function get_todays_in_out_patient()
	{
		$today = date("Y-m-d");
		$sql = ' SELECT (SELECT SUM(`pay_amount`) FROM `payments_tbl` WHERE `pay_custo_type`="In Patient" AND  `pay_created_date` LIKE "%%' . $today . '%%") as inPatient,(SELECT SUM(`pay_amount`) FROM `payments_tbl` WHERE `pay_custo_type`="Out Patient" AND  `pay_created_date` LIKE "%%' . $today . '%%") as outPatient FROM payments_tbl WHERE `pay_created_date` like "%%' . $today . '%%"';;

		// $sql = " SELECT count(p_id) as pro from product_tbl where `p_added_date` like '%%" . $today . "%%'";
		$res = db_get_table_sql($sql);
		// print_r($res);
		if (!empty($res)) {
			return $res[0];
		} else {
			$res[0]['inPatient'] = 0;
			$res[0]['outPatient'] = 0;
			return $res[0];
		}
		// return ($res[0]);
	}


	//check if the product exists or not in database using the product code
	public function product_exists($code)
	{
		$res = db_get_table("product_tbl", "p_id", array('p_code' => $code));
		if (count($res) > 0) {
			return 1;
		} else {
			return 0;
		}
	}

	public function get_product_name($pcode)
	{
		$res = db_get_table("product_tbl", "p_name", array("p_code" => $pcode));
		if (count($res) > 0)
			return $res[0];
		else
			return 0;
	}
	public function get_p_Incart($code)
	{
		$sql = "SELECT sum(cart_qty) as qty from cart_tbl where `cart_p_code`='" . $code . "'";
		$res = db_get_table_sql($sql);
		if (count($res) > 0)
			return $res[0];
		else
			return 0;
	}
	public function get_cart_dtls($cid)
	{
		$sql = "SELECT * from cart_tbl left join product_tbl on p_code=cart_p_code where cart_id=" . $cid;

		$res = db_get_table_sql($sql);
		if (count($res) > 0)
			return $res[0];
		else
			return 0;
	}
	public function get_p_cnt_inCart()
	{
		$res = db_get_table("cart_tbl", "count(cart_id) as cnt", array());
		return $res[0];
	}
	public function get_product_qnty($code)
	{
		$sql = "SELECT p_quantity from product_tbl where p_code='" . $code . "'";

		$res = db_get_table_sql($sql);
		if (count($res) > 0)
			return $res[0];
		else
			return 0;
	}
	// public function get_p_dtls_fromID($id)
	// {
	//  $res=db_get_table("product_tbl","*",array("p_id"=>$id));
	// 	if(count($res)>0)
	// 		return $res[0];
	// 	else
	// 		return 0;
	// }
	public function get_product_qty_5()
	{
		$result = '';
		$p_code = db_get_table("product_tbl", "p_code", array(), "");
		foreach ($p_code as $pcode) :

			$res = $this->get_product_details($pcode['p_code']);

			if ($res['p_left'] <= 5) {
				$result .= '<div class="col-md-3 nopadding">
								<div class="followup-notification-box">
									<h5>Product Name: ' . $res['p_name'] . '</h5>
									<h5>Product Code: ' . $res['p_code'] . '</h5>
									<h5>Stock: ' . $res['p_left'] . ' left</h5>
								</div>
							</div>
							';
			}


		endforeach;
		return $result;
	}
	public function get_main_category_dropdown()
	{
		$options = '<option value="0">Select</option>';
		$res = db_get_table("category_tbl", "c_id,c_name", array('c_main_category' => 0, 'c_sub_category' => 0));
		foreach ($res as $r) {
			$options .= '<option value="' . $r['c_id'] . '">' . $r['c_name'] . '</option>';
		}
		return $options;
	}
	public function cnt_product_in_package($packid)
	{
		$res = db_get_table("package_product_tbl", "count(pp_id) as total", array('pp_pack_id' => $packid));
		if ($res[0]['total'] == "0")
			return 0;
		else
			return $res[0]['total'];
	}
}
$Product = new productApp();
