<?php
class memberApp
{

	/****get all member's name and code to display in select option which takes member code as value and name to display ****/
	public function get_mem_code()
	{
		$result = array();
		$res = db_get_table("members_tbl ", "mem_code,mem_fname,mem_lname", array());
		foreach ($res as $value) {
			$result[] .= "<option value='" . $value['mem_code'] . "'>" . $value['mem_fname'] . " " . $value['mem_lname'] . "</option>";
		}
		return implode($result, ",");
	}

	/********get the last purchase date of the member from the sales table
-----to know whether the member has bought the product that applies the rules 
-----takes the member code(varchar) and product code(varchar) as a parameter which uniquely defines the member and product*********/
	public function get_mem_purchase_dtls($mem_code, $pro_code, $ruleStartDate, $ruleEndDate)
	{

		$sql = "SELECT sal_type,sum(sal_product_qty) as dis_sold_items from stock_out_tbl where `sal_mem_code`='" . $mem_code . "' and `sal_product_code`= '" . $pro_code . "' and  `sal_type`='D' and `sal_date` between '" . $ruleStartDate . "' and '" . $ruleEndDate . "' order by sal_type ";
		//echo $sql;
		$res = db_get_table_sql($sql);
		if (count($res) > 0)
			return $res[0];
		else
			return 0;
	}
	/*********to get the name of the member to display in the sales table .Takes mem_code as a parameter ***********/
	public function get_mem_details($mcode)
	{
		$res = db_get_table("members_tbl", "mem_fname,mem_lname,mem_status", array('mem_code' => $mcode));
		return $res[0];
	}
	public function get_last_mem_id()
	{
		$last_id = db_get_table('members_tbl', 'mem_id', array(), "ORDER BY `mem_id` DESC LIMIT 1");
		$cid = (count($last_id) > 0 ? "MEM" . ($last_id[0]['mem_id'] + 1) : $cid = "MEM1");
		return $cid;
	}
}
$Mem = new memberApp();
