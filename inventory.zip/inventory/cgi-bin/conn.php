<?php
include("cgi-bin/config.php");

$mysqli = new mysqli($db[0], $db[1], $db[2], $db[3]);
$mysqli_error = "";
/* check connection */
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}
function array_push_assoc($array, $key, $value)
{
    $array[$key] = $value;
    return $array;
}

function db_insert_sql($query)
{
    global $mysqli;
    $mysqli->query($query);
    return $mysqli->insert_id;
}

function db_execute_sql($query)
{
    global $mysqli;
    if (!$mysqli->query($query))
        printf("\nmysql:Error Message: %s\n", $mysqli->error);
    if ($mysqli->affected_rows > 0)
        return $mysqli->affected_rows;
    else
        return false;
}
function __db_add_values($tablename, $data)
{
    global $mysqli;
    $rows = "";
    $values = "";
    foreach ($data as $row => $key) {
        $rows .= "`" . $row . "`,";
        $values .= "'" . $key . "',";
    }
    $sql = "INSERT INTO $tablename (" . substr($rows, 0, -1) . ") VALUES (" . substr($values, 0, -1) . ")";
    //echo $sql;
    if (!$mysqli->query($sql))
        printf("\nmysql:Error Message: %s\n", $mysqli->error);
    else
        return true;
}
function db_get_table($tablename, $fld, $arr, $cond = "")
{
    global $mysqli;
    $fields = "";
    $result = array();

    if (count($arr) != 0) {
        $fields = " where ";

        foreach ($arr as $i => $j) {
            $fields .= "`" . $i . "`='" . $j . "' &&";
        }
        $fields = substr($fields, 0, -3);
    }

    if ($cond != "" && $arr == 0)
        $cond = "where " . $cond;
    if ($cond != "" && $arr == 1)
        $cond = "and " . $cond;

    $sql = "select $fld from $tablename $fields $cond";
    //echo $sql;
    if (!$result = $mysqli->query($sql))
        printf("\nmysql:Error Message: %s\n", $mysqli->error);

    while ($rows[] = mysqli_fetch_assoc($result));
    array_pop($rows);
    return $rows;
}


function db_get_table_sql($sql)
{
    global $mysqli;
    $result = $mysqli->query($sql);
    while ($rows[] = mysqli_fetch_assoc($result));
    array_pop($rows);
    return $rows;
}

function db_add_values($tablename, $data)
{
    global $mysqli;
    $rows = "";
    $values = "";
    foreach ($data as $row => $key) {
        $rows .= "`" . $row . "`,";
        $values .= "'" . $mysqli->escape_string($key) . "',";
    }
    $sql = "INSERT INTO $tablename (" . substr($rows, 0, -1) . ") VALUES (" . substr($values, 0, -1) . ")";
    //echo $sql;
    if (!$mysqli->query($sql)) {
        $mysqli_error = "mysql:Error Message: " . $mysqli->error;
        return 0;
    } else
        return $mysqli->insert_id;
}
function db_update_values($table, $data = array(), $condition = array())
{
    global $mysqli;
    $values = "";
    foreach ($data as $v => $k)
        $values .= "`" . $v . "`='" . $mysqli->escape_string($k) . "',";
    if (count($condition) != 0) {
        $fields = " where ";
        foreach ($condition as $i => $j) {
            $fields .= "`" . $i . "`='" . $j . "' &&";
        }
        $fields = substr($fields, 0, -3);
    }
    $sql = "update $table SET " . substr($values, 0, -1) . " " . $fields;
    // echo $sql;
    if (!$mysqli->query($sql))
        return 0;
    //printf("\nmysql:Error Message: %s\n", $mysqli->error);	
    else
        return $mysqli->affected_rows;
}
function combo_values_member($tablename, $fld, $arr, $cond = "")
{
    global $mysqli;
    $res = array();
    $fields = "";
    if ($arr != 0) {
        $fields = " where ";
        foreach ($arr as $i => $j) {
            $fields .= "`" . $i . "`='" . $j . "' &&";
        }
        $fields = substr($fields, 0, -3);
    }

    if ($cond != "" && $arr == 0)
        $cond = "where " . $cond;
    if ($cond != "" && $arr == 1)
        $cond = "and " . $cond;
    $sql = "select $fld from $tablename $fields $cond";

    //Exploding 2 fields sepratly
    $fld = explode(",", $fld);

    $result = $mysqli->query($sql);
    while ($rows = mysqli_fetch_assoc($result)) {
        $temp = $rows[$fld[0]];
        //array_push($res,$temp);
        $res[$temp] = $rows[$fld[1]] . '&nbsp;' . $rows[$fld[2]];
    }
    return $res;
}
function combo_values($tablename, $fld, $arr, $cond = "") //Table Name
{
    global $mysqli;
    $res = array();
    $fields = "";

    if (count($arr) != 0) {
        $fields = " where ";
        foreach ($arr as $i => $j) {
            $fields .= "`" . $i . "`='" . $j . "' &&";
        }
        $fields = substr($fields, 0, -3);
    }

    if ($cond != "" && count($arr) == 0)
        $cond = "where " . $cond;
    if ($cond != "" && count($arr) == 1)
        $cond = "and " . $cond;
    $sql = "select $fld from $tablename $fields $cond";

    //Exploding 2 fields sepratly
    $fld = explode(",", $fld);

    $result = $mysqli->query($sql);
    $temp = 0;
    // $res[$temp]="select this if no value";      
    while ($rows = mysqli_fetch_assoc($result)) {
        $temp = $rows[$fld[0]];
        //array_push($res,$temp);
        $res[$temp] = $rows[$fld[1]];
    }
    return $res;
}

function mysql_password_hash($input, $hex = true)
{
    $sha1_stage1 = sha1($input, true);
    $output = sha1($sha1_stage1, !$hex);
    return $output;
} //END function mysql_password_hash


function encrypt($sData, $sKey = 'mysecretkey')
{
    $sResult = '';
    for ($i = 0; $i < strlen($sData); $i++) {
        $sChar    = substr($sData, $i, 1);
        $sKeyChar = substr($sKey, ($i % strlen($sKey)) - 1, 1);
        $sChar    = chr(ord($sChar) + ord($sKeyChar));
        $sResult .= $sChar;
    }
    return encode_base64($sResult);
}

function decrypt($sData, $sKey = 'mysecretkey')
{
    $sResult = '';
    $sData   = decode_base64($sData);
    for ($i = 0; $i < strlen($sData); $i++) {
        $sChar    = substr($sData, $i, 1);
        $sKeyChar = substr($sKey, ($i % strlen($sKey)) - 1, 1);
        $sChar    = chr(ord($sChar) - ord($sKeyChar));
        $sResult .= $sChar;
    }
    return $sResult;
}


function encode_base64($sData)
{
    $sBase64 = base64_encode($sData);
    return strtr($sBase64, '+/', '-_');
}

function decode_base64($sData)
{
    $sBase64 = strtr($sData, '-_', '+/');
    return base64_decode($sBase64);
}
function time_left($timestamp)
{

    $return = array();
    //type cast, current time, difference in timestamps
    $timestamp      = strtotime($timestamp);
    $current_time   = time();
    $diff           = $timestamp - $current_time;
    //intervals in seconds
    $intervals      = array(
        'year' => 31556926, 'month' => 2629744, 'week' => 604800, 'day' => 86400, 'hour' => 3600, 'minute' => 60
    );

    //now we just find the difference
    if ($diff < 0)
        return -1;
    if ($diff == 0) {
        return 'just now';
    }

    if ($diff < 60) {

        $return[0] = $diff == 1 ? $diff : $diff;
        $return[1] = $diff == 1 ? ' second left' : ' seconds remaining';
    }

    if ($diff >= 60 && $diff < $intervals['hour']) {
        $diff = floor($diff / $intervals['minute']);
        $return[0] = $diff == 1 ? $diff  : $diff;
        $return[1] = $diff == 1 ? ' minute remaining' : ' minutes remaining';
    }

    if ($diff >= $intervals['hour'] && $diff < $intervals['day']) {
        $diff = floor($diff / $intervals['hour']);
        $return[0] = $diff == 1 ? $diff : $diff;
        $return[1] = $diff == 1 ? ' hour remaining' : ' hours remaining';
    }

    if ($diff >= $intervals['day'] && $diff < $intervals['week']) {
        $diff = floor($diff / $intervals['day']);
        $return[0] = $diff == 1 ? $diff : $diff;
        $return[1] = $diff == 1 ? ' day remaining' : ' days remaining';
    }

    if ($diff >= $intervals['week'] && $diff < $intervals['month']) {
        $diff = floor($diff / $intervals['week']);
        $return[0] = $diff == 1 ? $diff : $diff;
        $return[1] = $diff == 1 ? ' week remaining' : ' weeks remaining';
    }

    if ($diff >= $intervals['month'] && $diff < $intervals['year']) {
        $diff = floor($diff / $intervals['month']);
        $return[0] = $diff == 1 ? $diff : $diff;
        $return[1] = $diff == 1 ? ' month remaining' : ' months remaining';
    }

    if ($diff >= $intervals['year']) {
        $diff = floor($diff / $intervals['year']);
        $return[0] = $diff == 1 ? $diff : $diff;
        $return[1] = $diff == 1 ? ' year remaining' : ' years remaining';
    }
    return $return;
}
function time_passed($timestamp)
{
    //type cast, current time, difference in timestamps

    $timestamp      = strtotime($timestamp);
    $current_time   = time();
    $diff           = $current_time - $timestamp;

    //intervals in seconds
    $intervals      = array(
        'year' => 31556926, 'month' => 2629744, 'week' => 604800, 'day' => 86400, 'hour' => 3600, 'minute' => 60
    );

    //now we just find the difference
    if ($diff == 0) {
        return 'just now';
    }

    if ($diff < 60) {
        return $diff == 1 ? $diff . ' second ago' : $diff . ' seconds ago';
    }

    if ($diff >= 60 && $diff < $intervals['hour']) {
        $diff = floor($diff / $intervals['minute']);
        return $diff == 1 ? $diff . ' minute ago' : $diff . ' minutes ago';
    }

    if ($diff >= $intervals['hour'] && $diff < $intervals['day']) {
        $diff = floor($diff / $intervals['hour']);
        return $diff == 1 ? $diff . ' hour ago' : $diff . ' hours ago';
    }

    if ($diff >= $intervals['day'] && $diff < $intervals['week']) {
        $diff = floor($diff / $intervals['day']);
        return $diff == 1 ? $diff . ' day ago' : $diff . ' days ago';
    }

    if ($diff >= $intervals['week'] && $diff < $intervals['month']) {
        $diff = floor($diff / $intervals['week']);
        return $diff == 1 ? $diff . ' week ago' : $diff . ' weeks ago';
    }

    if ($diff >= $intervals['month'] && $diff < $intervals['year']) {
        $diff = floor($diff / $intervals['month']);
        return $diff == 1 ? $diff . ' month ago' : $diff . ' months ago';
    }

    if ($diff >= $intervals['year']) {
        $diff = floor($diff / $intervals['year']);
        return $diff == 1 ? $diff . ' year ago' : $diff . ' years ago';
    }
}

//Amount Filtering
function my_money_format($num)
{
    $pp = array();
    $taka_add = "";
    $num = number_format($num, 2, '.', '');
    $money = explode('.', $num);
    if (strlen($money[0]) > 2) {
        $taka = $money[0];
        $thousand = substr($taka, -3);
        $taka = substr($taka, 0, strlen($taka) - 3);
        $i = 0;
        while (strlen($taka) > 0) {
            if (strlen($taka) > 1) {
                $pp[$i] = substr($taka, -2);
                $taka = substr($taka, 0, strlen($taka) - 2);
            } else {
                $pp[$i] = substr($taka, -1);
                $taka = substr($taka, 0, strlen($taka) - 1);
            }
            $i++;
        }
        for ($j = sizeof($pp) - 1; $j >= 0; $j--)
            $taka_add .= $pp[$j] . ',';
        return $taka_add . $thousand . "." . $money[1];
    } else
        return $money[0] . "." . $money[1];
}
