<?php
/*
Global Config file & GLOBAL functions for the entire website
*/
/*  Set time zone  */
date_default_timezone_set('Asia/Kathmandu');
/*  Root domain  */
define("_DOMAIN_", "http://localhost/inventory/");
define("_MEMBER_IMAGE_", "files/member/");
define("_PRODUCT_IMAGE_", "files/product/");
define("_INVEST_POINT_", 15);
define("_MAIL_FROM", "saayamiagency@gmail.com");
define("MAX_SIZE", "2000");
define("MYSQLDUMP", "D:/XAMPP/mysql/bin/mysqldump");
/*  Error Page  */
define("_ERROR_PAGE", 'error');
/*	mysql database config   */
$db[0] = "localhost";         //host name
$db[1] = "root";                //user name
$db[2] = "";                     //password
$db[3] = "inventory"; 	//datatbase name
