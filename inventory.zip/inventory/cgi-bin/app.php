<?php
/* Master User App Class */
class App
{
	public function save($tbl, $data)
	{
		return db_add_values($tbl, $data);
	}
	public function is_valid_password($id, $name, $pass)
	{

		$res = db_get_table("login_tbl", "log_id", array('log_id' => $id, 'username' => $name, 'password' => md5($pass)));

		if (count($res) > 0) {
			return true;
		} else {
			return false;
		}
	}
	//get the name of category to substring with product code and to display in the product table
	public function get_category_name($cid)
	{
		$res = db_get_table("category_tbl", "c_name", array('c_id' => $cid));
		return $res[0]['c_name'];
	}
	public function get_cart_data()
	{
		$res = db_get_table("cart_tbl", "*", array());
		return $res;
	}
	public function get_p_qty_taken($sid)
	{
		$res = db_get_table("stock_out_tbl", "sal_product_qty", array('sal_id' => $sid));
		return $res[0];
	}
	public function get_qty_returned($sid)
	{
		$res = db_get_table("return_tbl", "sum(r_qty) as returned", array('r_sale_id' => $sid));
		if (count($res) > 0) {
			return $res[0];
		} else {
			return 0;
		}
	}
	public function get_all_members($curr_yr, $curr_mth)
	{
		$sql = " SELECT count(mem_id) as mem from members_tbl where `mem_status`=1 and `mem_added_date` like '%%" . $curr_yr . "-" . $curr_mth . "%%'";
		$res = db_get_table_sql($sql);
		return ($res[0]['mem']);
	}
	public function get_todays_stockout($today)
	{
		$sql = " SELECT count(sal_id) as sal from stock_out_tbl where `sal_date` like '%%" . $today . "%%'";
		$res = db_get_table_sql($sql);
		return ($res[0]['sal']);
	}
	//re created by g
	public function get_todays_stockout_new($today)
	{
		$sql = " SELECT count(sal_id) as sal, SUM(sal_total_amt) as tamt from stock_out_tbl where `sal_date` like '%%" . $today . "%%'";
		$res = db_get_table_sql($sql);
		return ($res[0]);
	}
	public function get_todays_p_return($today)
	{
		$sql = " SELECT count(r_id) as ret from return_tbl where `r_date` like '%%" . $today . "%%'";
		$res = db_get_table_sql($sql);
		return ($res[0]['ret']);
	}
	public function get_category_list($role)
	{
		$main = db_get_table("category_tbl", "c_id,c_name", array('c_main_category' => 0, 'c_sub_category' => 0));
		if (count($main) > 0) {
			foreach ($main as $parent) :
				echo '<div class="' . $parent['c_id'] . ' checkbox">
						   	<span class="fas fa-angle-right"></span>' . ' ' . $parent['c_name'] . ' 
						   	<div class="cat-edit-del">
								   <a href="add_category?edit=' . $parent['c_id'] . '" id="' . $parent['c_id'] . '" class="btn btn-primary btn-xs"><i class="glyphicon glyphicon-edit"></i> Edit</a>&nbsp;&nbsp;';

				if ($role == 1) {
					echo '<button type="button" cid="' . $parent['c_id'] . '" class="btn btn-xs btn-danger btn-del-category"><i class="glyphicon glyphicon-trash"></i> Delete</button>';
				}
				echo ' 	</div>
						  </div>';
				$sub = db_get_table("category_tbl", "c_id,c_name", array('c_main_category' => $parent['c_id'], 'c_sub_category' => 0));
				foreach ($sub as $ch1) :
					echo '<div class="' . $ch1['c_id'] . ' checkbox chmargin1" >
							   	<span class="fas fa-angle-right"></span>' . ' ' . $ch1['c_name'] . '
								<div class="cat-edit-del">
									<a href="add_category?edit=' . $ch1['c_id'] . '" id="' . $ch1['c_id'] . '" class="btn btn-primary btn-xs"><i class="glyphicon glyphicon-edit"></i> Edit</a>&nbsp;&nbsp;';
					if ($role == 1) {
						echo '<button type="button" cid="' . $ch1['c_id'] . '" class="btn btn-xs btn-danger btn-del-category"><i class="glyphicon glyphicon-trash"></i> Delete</button>';
					}
					echo ' </div>
							  </div>';

					$leaf = db_get_table("category_tbl", "c_id,c_name", array("c_sub_category" => $ch1['c_id']));
					foreach ($leaf as $ch2) :
						echo '<div class="' . $ch2['c_id'] . ' checkbox chmargin2">
								    <span class="fas fa-angle-right"></span>' . ' ' . $ch2['c_name'] . '
								    <div class="cat-edit-del">
										   	<a href="add_category?edit=' . $ch2['c_id'] . '" id="' . $ch2['c_id'] . '" class="btn btn-primary btn-xs"><i class="glyphicon glyphicon-edit"></i> Edit</a>&nbsp;&nbsp;';
						if ($role == 1) {
							echo '<button type="button" cid="' . $ch2['c_id'] . '" class="btn btn-xs btn-danger btn-del-category"><i class="glyphicon glyphicon-trash"></i> Delete</button>';
						}
						echo ' 	</div>
								</div>';
					endforeach;
				endforeach;
			endforeach;
		} else {
			echo "No category";
		}
	}
	public function check_product_exists($cid)
	{
		$sql = "SELECT p_id from product_tbl where `p_parent_cat`=" . $cid . " or `p_child_cat_1`=" . $cid . " or `p_child_cat_2`=" . $cid . "";
		$res = db_get_table_sql($sql);
		if (count($res) > 0) {
			return 1;
		} else {
			return 0;
		}
	}
	public function get_last_product_id()
	{
		$last_id = db_get_table('product_tbl', 'p_id', array(), "ORDER BY `p_id` DESC LIMIT 1");
		$lastid = (count($last_id) == 0 ? "0" : $last_id[0]['p_id'] + 1);
		return $lastid;
	}
	public function get_product_return($salid)
	{
		$ret_qty = db_get_table("stock_out_tbl", "sal_return_qty", array('sal_id' => $salid));
		return $ret_qty[0]['sal_return_qty'];
	}
	public function check_package_exists($cid)
	{
		$res = db_get_table("package_tbl left join package_product_tbl on pack_id=pp_pack_id", "pp_id", array('pack_category' => $cid));
		if (count($res) > 0) {
			return true;
		} else {
			return false;
		}
	}
	//get product details by id
	public function get_product_details_by_id($pid)
	{
		$res = db_get_table("product_tbl", "*", array("p_id" => $pid));
		return $res[0];
	}


	//payments table
	public function checkPatientByContactNo($contactNo, $table)
	{
		$sql = "SELECT pay_custo_contact FROM $table WHERE pay_custo_contact = $contactNo";
		return db_execute_sql($sql);
	}
}
$App = new App();
