The minimized JavaScript file contains the minimized version of the "zebra_form.src.js" file and the minimized version of the Zebra_DatePicker (http://stefangabos.ro/jquery/zebra-datepicker/) plugin!

The source file contains *only* the JavaScript source for the Zebra_Form!