-- MariaDB dump 10.19  Distrib 10.4.24-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: inventory_db
-- ------------------------------------------------------
-- Server version	10.4.24-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cart_tbl`
--

DROP TABLE IF EXISTS `cart_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cart_tbl` (
  `cart_id` int(11) NOT NULL AUTO_INCREMENT,
  `cartpid` int(11) NOT NULL,
  `cart_p_code` varchar(10) NOT NULL,
  `cart_qty` int(11) NOT NULL,
  PRIMARY KEY (`cart_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_tbl`
--

LOCK TABLES `cart_tbl` WRITE;
/*!40000 ALTER TABLE `cart_tbl` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_tbl`
--

DROP TABLE IF EXISTS `category_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_tbl` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `c_name` varchar(50) NOT NULL,
  `c_main_category` int(11) NOT NULL,
  `c_sub_category` int(11) NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_tbl`
--

LOCK TABLES `category_tbl` WRITE;
/*!40000 ALTER TABLE `category_tbl` DISABLE KEYS */;
INSERT INTO `category_tbl` VALUES (50,'syrup',0,0),(52,'oil',0,0),(53,'Tablets',0,0);
/*!40000 ALTER TABLE `category_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_backups`
--

DROP TABLE IF EXISTS `db_backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_backups` (
  `db_id` int(11) NOT NULL AUTO_INCREMENT,
  `db_name` varchar(255) NOT NULL,
  `db_created_date` datetime NOT NULL,
  `db_is_deleted` tinyint(1) NOT NULL,
  PRIMARY KEY (`db_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_backups`
--

LOCK TABLES `db_backups` WRITE;
/*!40000 ALTER TABLE `db_backups` DISABLE KEYS */;
/*!40000 ALTER TABLE `db_backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_tbl`
--

DROP TABLE IF EXISTS `login_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_tbl` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `contact` bigint(15) NOT NULL,
  `u_added_date` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `user_type` int(11) NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_tbl`
--

LOCK TABLES `login_tbl` WRITE;
/*!40000 ALTER TABLE `login_tbl` DISABLE KEYS */;
INSERT INTO `login_tbl` VALUES (1,'Admin','admin','36aba7ac608d9f5dacb81c00c82bc54d',0,'2019-08-09 06:12:10',1,1),(9,'User','User','25d55ad283aa400af464c76d713c07ad',9800000000,'2022-08-08 12:51:37',1,2);
/*!40000 ALTER TABLE `login_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_tbl`
--

DROP TABLE IF EXISTS `members_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members_tbl` (
  `mem_id` int(11) NOT NULL AUTO_INCREMENT,
  `mem_code` varchar(20) NOT NULL,
  `mem_fname` varchar(20) NOT NULL,
  `mem_mname` varchar(20) NOT NULL,
  `mem_lname` varchar(20) NOT NULL,
  `mem_address` varchar(100) NOT NULL,
  `mem_email` varchar(100) NOT NULL,
  `mem_contact` bigint(15) NOT NULL,
  `mem_image` text NOT NULL,
  `mem_added_date` datetime NOT NULL,
  `mem_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`mem_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_tbl`
--

LOCK TABLES `members_tbl` WRITE;
/*!40000 ALTER TABLE `members_tbl` DISABLE KEYS */;
INSERT INTO `members_tbl` VALUES (9,'MEM1','GUEST','','Patient','gwarko','safalhealthhome@gmail.com',9,'','2022-07-29 09:03:22',1),(10,'MEM10','Aashik','','Mnandhar','satdobato','saayamiagency@gmail.com',917672323,'','2022-07-29 10:32:21',1),(20,'','gyanendra','','','','',9864374699,'','2022-08-08 16:06:28',0),(21,'','fdsa','','','','',9223372036854775807,'','2022-08-08 16:11:16',0),(22,'MEM22','gyanendra','prasad','chaudhary','Karaiyamai-5','chaudharygyane699@gmail.com',9223372036854775807,'','2022-08-08 16:12:04',1),(23,'','demo','','','','',986437469900000,'','2022-08-08 16:25:20',0);
/*!40000 ALTER TABLE `members_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package_product_tbl`
--

DROP TABLE IF EXISTS `package_product_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `package_product_tbl` (
  `pp_id` int(11) NOT NULL AUTO_INCREMENT,
  `pp_pack_id` int(11) NOT NULL,
  `pp_product_code` varchar(20) NOT NULL,
  `pp_product_qty` int(11) NOT NULL,
  PRIMARY KEY (`pp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package_product_tbl`
--

LOCK TABLES `package_product_tbl` WRITE;
/*!40000 ALTER TABLE `package_product_tbl` DISABLE KEYS */;
/*!40000 ALTER TABLE `package_product_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package_tbl`
--

DROP TABLE IF EXISTS `package_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `package_tbl` (
  `pack_id` int(11) NOT NULL AUTO_INCREMENT,
  `pack_name` varchar(50) NOT NULL,
  `pack_category` int(11) NOT NULL,
  `pack_date` date NOT NULL,
  PRIMARY KEY (`pack_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package_tbl`
--

LOCK TABLES `package_tbl` WRITE;
/*!40000 ALTER TABLE `package_tbl` DISABLE KEYS */;
/*!40000 ALTER TABLE `package_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments_tbl`
--

DROP TABLE IF EXISTS `payments_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments_tbl` (
  `pay_id` int(11) NOT NULL AUTO_INCREMENT,
  `pay_custo_id` int(11) NOT NULL,
  `pay_custo_name` varchar(255) NOT NULL,
  `pay_custo_contact` text NOT NULL,
  `pay_custo_type` varchar(50) NOT NULL,
  `pay_amount` decimal(10,0) NOT NULL,
  `pay_new_user` tinyint(1) NOT NULL,
  `pay_remark` text NOT NULL,
  `pay_created_date` datetime NOT NULL,
  `pay_modified_date` datetime NOT NULL,
  `pay_is_deleted` tinyint(1) NOT NULL,
  PRIMARY KEY (`pay_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments_tbl`
--

LOCK TABLES `payments_tbl` WRITE;
/*!40000 ALTER TABLE `payments_tbl` DISABLE KEYS */;
INSERT INTO `payments_tbl` VALUES (4,0,'gyanendra','9864374699','Out Patient',100,0,'test','2022-08-08 16:06:28','0000-00-00 00:00:00',0),(5,0,'Test Payment','9864374699','Out Patient',500,0,'faf','2022-08-08 16:06:58','0000-00-00 00:00:00',0),(6,0,'dgdgdffsf','9864374699','In Patient',400,0,'dsfsaf','2022-08-08 16:08:20','0000-00-00 00:00:00',0),(7,0,'fdsa','986437469900000000000000000','In Patient',0,0,'','2022-08-08 16:11:16','0000-00-00 00:00:00',0),(8,0,'demo','986437469900000','In Patient',222,0,'dfasf','2022-08-08 16:25:20','0000-00-00 00:00:00',0);
/*!40000 ALTER TABLE `payments_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_added_tbl`
--

DROP TABLE IF EXISTS `product_added_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_added_tbl` (
  `p_add_id` int(11) NOT NULL AUTO_INCREMENT,
  `p_add_date` datetime NOT NULL,
  `p_add_qty` int(11) NOT NULL,
  `p_add_pro_code` varchar(20) NOT NULL,
  `p_add_note` text NOT NULL,
  `p_add_price` float NOT NULL,
  `p_add_pro_id` int(11) NOT NULL,
  PRIMARY KEY (`p_add_id`),
  KEY `p_add_pro_code` (`p_add_pro_code`),
  CONSTRAINT `product_added_tbl_ibfk_1` FOREIGN KEY (`p_add_pro_code`) REFERENCES `product_tbl` (`p_code`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=490 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_added_tbl`
--

LOCK TABLES `product_added_tbl` WRITE;
/*!40000 ALTER TABLE `product_added_tbl` DISABLE KEYS */;
INSERT INTO `product_added_tbl` VALUES (487,'2022-08-08 13:00:57',100,'Tab-0','',30,457),(488,'2022-08-08 13:01:47',200,'oil-458','',10,458),(489,'2022-08-08 13:02:55',200,'oil-459','test',10,459);
/*!40000 ALTER TABLE `product_added_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_tbl`
--

DROP TABLE IF EXISTS `product_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_tbl` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT,
  `p_code` varchar(20) NOT NULL,
  `p_name` varchar(100) DEFAULT NULL,
  `p_added_date` datetime DEFAULT NULL,
  `p_parent_cat` int(11) NOT NULL,
  `p_child_cat_1` int(11) NOT NULL,
  `p_child_cat_2` int(11) NOT NULL,
  `p_image` text NOT NULL,
  `p_quantity` int(11) NOT NULL,
  `p_price` float NOT NULL,
  `p_note` text DEFAULT NULL,
  `p_stnd_qnty` int(11) NOT NULL DEFAULT 0,
  `p_is_available` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`p_code`,`p_id`),
  UNIQUE KEY `p_id` (`p_id`)
) ENGINE=InnoDB AUTO_INCREMENT=460 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_tbl`
--

LOCK TABLES `product_tbl` WRITE;
/*!40000 ALTER TABLE `product_tbl` DISABLE KEYS */;
INSERT INTO `product_tbl` VALUES (458,'oil-458','Test Product 2','2022-08-08 13:01:47',52,0,0,'',200,10,'fasdf',0,1),(459,'oil-459','Test Product 3','2022-08-08 13:02:55',52,0,0,'',200,10,'fafdfa fadf',0,1),(457,'Tab-0','Test Product','2022-08-08 13:00:57',53,0,0,'',100,30,'test note',0,1);
/*!40000 ALTER TABLE `product_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `return_tbl`
--

DROP TABLE IF EXISTS `return_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `return_tbl` (
  `r_id` int(11) NOT NULL AUTO_INCREMENT,
  `r_sale_id` int(11) NOT NULL,
  `r_qty` int(11) NOT NULL,
  `r_date` datetime NOT NULL,
  `r_p_code` varchar(20) NOT NULL,
  PRIMARY KEY (`r_id`),
  KEY `r_sale_id` (`r_sale_id`),
  CONSTRAINT `return_tbl_ibfk_1` FOREIGN KEY (`r_sale_id`) REFERENCES `stock_out_tbl` (`sal_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `return_tbl`
--

LOCK TABLES `return_tbl` WRITE;
/*!40000 ALTER TABLE `return_tbl` DISABLE KEYS */;
INSERT INTO `return_tbl` VALUES (24,250,10,'2022-08-08 15:23:03','oil-459'),(25,250,10,'2022-08-08 15:23:25','oil-459'),(26,250,13,'2022-08-08 15:23:44','oil-459');
/*!40000 ALTER TABLE `return_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_out_tbl`
--

DROP TABLE IF EXISTS `stock_out_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_out_tbl` (
  `sal_id` int(11) NOT NULL AUTO_INCREMENT,
  `sal_staff_id` int(11) NOT NULL,
  `sal_mem_code` varchar(20) NOT NULL,
  `sal_product_code` varchar(20) NOT NULL,
  `sal_product_qty` int(11) NOT NULL,
  `sal_return_id` int(11) NOT NULL,
  `sal_return_qty` int(11) NOT NULL,
  `sal_total_amt` decimal(10,0) NOT NULL,
  `sal_date` date NOT NULL,
  PRIMARY KEY (`sal_id`),
  KEY `sal_product_code` (`sal_product_code`),
  CONSTRAINT `stock_out_tbl_ibfk_1` FOREIGN KEY (`sal_product_code`) REFERENCES `product_tbl` (`p_code`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_out_tbl`
--

LOCK TABLES `stock_out_tbl` WRITE;
/*!40000 ALTER TABLE `stock_out_tbl` DISABLE KEYS */;
INSERT INTO `stock_out_tbl` VALUES (250,1,'MEM1','oil-459',50,26,33,170,'2022-08-08');
/*!40000 ALTER TABLE `stock_out_tbl` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-08 16:28:19
