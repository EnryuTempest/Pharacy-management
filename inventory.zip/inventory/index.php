<?php
ob_start('ob_gzhandler');
include_once("cgi-bin/class.php");
$page = new Page();
/*
	Customized root path
*/
$root_path=explode("/",$page->path); 	
if(file_exists($page->file_url))
	include_once($page->file_url);
else
	$page->error();
	
if($page->page_init==true)
	{
	if(isset($page->inc['footer']))include_once($page->inc['footer']);
	echo "</body></html>";	
	}
ob_end_flush();		
?>