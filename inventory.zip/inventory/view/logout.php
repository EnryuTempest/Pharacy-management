<?php
require_once('cgi-bin/app.php');
$page->user->logout();
header('location:login');
?>