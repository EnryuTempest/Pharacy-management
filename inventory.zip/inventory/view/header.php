<?php
$page->page_init('bootstrap','Knowledgeguide | Login',array('jquery.js','bootstrap.min.js'),array('bootstrap.min.css','dashboard.css'));
?>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>/plugins/zform/public/javascript/zebra_form.js"></script>
<link rel="stylesheet" href="<?php echo _DOMAIN_;?>/plugins/zform/public/css/zebra_form.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_;?>css/style.css" />
<div  class="top_header_bg">
<div style="width:980px; margin:0 auto;">
 <div class="navbar navbar-default" role="navigation">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#" style="text-align:center;font-size:25px; line-height:26px;padding: 0px 20px 0px 0px;"><!--img src="images/car.png" width="50" height="50"  /-->IMONETARY ADVISORY <br/>CUSTOMER SUPPORT TOOL</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav" style="float:right;padding-bottom:5px;border-bottom:1px #ed6d23 solid;">
                <li class="active"><a href="index">Home</a></li>
                <li><a href="add_ticket">Raise Ticket</a></li>
                <li><a href="#" id="tkt_status">Ticket Status</a></li>	
            <!--li><a href="#" id="login">Login</a></li-->
          </ul>
        </div><!--/.nav-collapse -->
      </div>
      </div>
      </div>