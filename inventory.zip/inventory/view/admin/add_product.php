<?php include "header.php"; ?>
<?php

require_once('plugins/zform/Zebra_Form.php');
?>
<?php


$form = new Zebra_Form('add_nproduct_form', 'post', '', array('autocomplete' => 'off', 'class' => 'form-horizontal'));
$form->csrf(false, 0);
//for default add
$obj = $form->add('hidden', 'pid', '0');
$obj = $form->add('hidden', 'pcode', '');
$obj = $form->add('hidden', 'hidden_p_image', '');

//product name
$obj = $form->add('text', 'pname', '', array('class' => 'form-control', 'placeholder' => 'Product Name'));
$obj->set_rule(array(
	'required'  =>  array('error', 'Product name is required!'),
));
//product main  category
$obj = $form->add('select', 'main_cat', '', array('class' => 'form-control', 'placeholder' => 'Parent Category'));
$obj->add_options(combo_values("category_tbl", "c_id,c_name", array('c_main_category' => 0, 'c_sub_category' => 0)));
$obj->set_rule(array(
	'required'  =>  array('error', 'Main Category of the product is required!'),
));
//product sub category
$obj = $form->add('select', 'sub_cat', '', array('class' => 'form-control', 'placeholder' => 'Child Category 1'));
$obj->add_options(combo_values("category_tbl", "c_id,c_name", array(), "c_main_category!=0 and c_sub_category=0"));
$obj->set_rule(array());
//product leaf category
$obj = $form->add('select', 'p_leaf_cat', '', array('class' => 'form-control', 'placeholder' => 'Child Category 2'));
$obj->add_options(combo_values("category_tbl", "c_id,c_name", array(), "c_main_category!=0 and c_sub_category!=0"));

$obj->set_rule(array(
	// 'required'  =>  array('error', 'sub Category of the product is required!'),
));
//ctevt standard quantity
if ($page->user->user_type != 1) {
	$obj = $form->add('text', 'st_qty', '', array('class' => 'form-control', 'placeholder' => 'st', 'readonly' => 'readonly'));
	$obj->set_rule(array(
		'digits' => array('', 'error', 'numbers only'),
	));
} else {
	$obj = $form->add('text', 'st_qty', '', array('class' => 'form-control', 'placeholder' => 'standard quantity'));
	$obj->set_rule(array(

		'digits' => array('', 'error', 'numbers only'),
	));
}
//product quantity
$obj = $form->add('text', 'p_qty', '', array('class' => 'form-control', 'placeholder' => 'Quantity'));
$obj->set_rule(array(
	'required'  =>  array('error', 'Quantity product is required!'),
	'digits' => array('', 'error', 'numbers only'),
));

$obj = $form->add('text', 'tot_price', '', array('class' => 'form-control', 'placeholder' => 'Total Price', 'readonly' => 'readonly'));
$obj->set_rule(array(
	'required'  =>  array('error', 'Quantity product is required!'),
	'digits' => array('.', 'error', 'numbers only'),
));
$obj = $form->add('text', 'p_price', '', array('class' => 'form-control', 'placeholder' => 'Price'));
$obj->set_rule(array(
	'required'  =>  array('error', 'Price of the product is required!'),
	'digits' => array('.', 'error', 'Only numbers'),
));
$obj = $form->add('checkbox', 'pro_available', '1', array('checked' => 'checked'));
$obj = $form->add('label', 'label_pro_available_1', 'pro_available_1', 'Product is available in inventory');

$obj = $form->add('textarea', 'p_note', '', array('class' => 'form-control', 'row' => '3', 'placeholder' => 'About product'));
$obj->set_rule(array());
//if edit auto fill the existing data
if (isset($_GET['edit'])) {
	//get the existing data
	$result = db_get_table('product_tbl ', '*', array('p_id' => $_GET['edit']));
	$form->auto_fill(array(
		'pid'  => $result[0]['p_id'],
		'pname' => $result[0]['p_name'],
		'pcode'	=> $result[0]['p_code'],
		'main_cat' => $result[0]['p_parent_cat'],
		//'sub_cat' => $result[0]['p_child_cat_1'],
		//'p_leaf_cat' => $result[0]['p_child_cat_2'],
		'p_qty' => $result[0]['p_quantity'],
		'p_price' => $result[0]['p_price'],
		'p_note' => $result[0]['p_note'],
		'tot_price' => $result[0]['p_price'] * $result[0]['p_quantity'],
		//'hidden_p_image' => $result[0]['p_image'],
		//'st_qty' => $result[0]['p_stnd_qnty'],
		//'pro_available' => $result[0]['p_is_available'],

	));
}
?>
<?php
if ($form->validate()) {
	$lastid = $App->get_last_product_id();
	$categoryname = $App->get_category_name($_POST['main_cat']);
	$code = (substr($categoryname, 0, 3)) . "-" . $lastid;

	$pdata = array(
		'p_code' => $code,
		'p_name' => $_POST['pname'],
		'p_added_date' => date("Y-m-d H:i:s"),
		'p_parent_cat' => $_POST['main_cat'],
		//'p_child_cat_1' => ($_POST['sub_cat'] != "" ? $_POST['sub_cat'] : "0"),
		//'p_child_cat_2' => ($_POST['p_leaf_cat'] != "" ? $_POST['p_leaf_cat'] : "0"),
		'p_price' => $_POST['p_price'],
		'p_quantity' => $_POST['p_qty'],
		//'p_image' => $_POST['hidden_p_image'],
		'p_note' => $_POST['p_note'],
		//'p_stnd_qnty' => (empty($_POST['st_qty']) ? "0" : $_POST['st_qty']),
		//'p_is_available' => (empty($_POST['pro_available']) ? "0" : $_POST['pro_available']),
	);

	if ($_POST['pid'] == '0') {
		if (($id = $App->save('product_tbl', $pdata)) > 0) {
			$cat_data = array(
				'p_add_pro_code' => $code,
				'p_add_qty' => $_POST['p_qty'],
				'p_add_price' => $_POST['p_price'],
				'p_add_date' => date("Y-m-d H:i:s"),
				'p_add_pro_id' => $id,
			);
			if (($App->save("product_added_tbl", $cat_data)) > 0) {
				$okmsg = '<div class="alert alert-success">
						<button class="close" data-dismiss="alert"></button>
						<strong><span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span> Success ! </strong> New product Successfully added with ID:' . $id . '!Click <a href="add_product">here to continue</a><span style="float:right;"><a href="product"> view list</a></span>
					</div>';
			} else {
				$msg = '<div class="alert alert-danger">
						<button class="close" data-dismiss="alert"></button>
						<strong><span class="glyphicon glyphicon-remove" aria-hidden="true"></span>Error ! </strong> Problem adding product !
					</div>';
			}
		} else {
			$msg = '<div class="alert alert-warning">
				<button class="close" data-dismiss="alert"></button>
				<strong><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Error ! </strong> Problem  adding product .Please check the product code which must be unique!
			</div>';
		}
		// if (($_POST['sub_cat'] == 0 || $_POST['sub_cat'] == "") && $_POST['p_leaf_cat'] > 0) {
		// 	$msg = '<div class="alert alert-danger">
		// 				<button class="close" data-dismiss="alert"></button>
		// 				<strong><span class="glyphicon glyphicon-remove" aria-hidden="true"></span>Error ! </strong> Select child category !
		// 			</div>';
		// } else {
			
		// }
	} else {
		//updating existing values
		$id = db_update_values('product_tbl', $pdata, array('p_id' => $_POST['pid']));
		$msg = '<div class="alert alert-success">
					<button class="close" data-dismiss="alert"></button><span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span>
					<strong>Success ! </strong> Product Updated Successfully <span style="float:right;"><a href="product"> view list</a></span>
					</div>';
	}
}


?>

<div class="container nopadding" style="border:1px #CCC solid;background:#FFF;">
	<div class="col-md-12 wrapper-pad" style="padding:20px;">
		<?php
		if (isset($msg)) {
			echo $msg;
		}
		if (isset($okmsg)) {
			echo $okmsg;
		} ?>

		<div id="new_product_form" style="margin-left:30px;">
			<h3><i class="glyphicon glyphicon-plus"></i> Add Product</h3>
			<div class="clearfix"></div>
			<form class="form-horizontal" method="post" id="add_nproduct_form" name="add_nproduct_form">
				<?php $form->render('view/zform_template/add_new_product_zform.php'); ?>
			</form>

		</div>
	</div>
</div>
<?php include "footer.php"; ?>
<script type="text/javascript" src="<?php echo _DOMAIN_ ?>js/ajax.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
		var img = ($("#hidden_p_image").val());
		if (img != "") {
			$("#img_preview").html('<img src="<?php echo _DOMAIN_ . _PRODUCT_IMAGE_; ?>' + img + '" target="_blank" class="img-responsive">');
		}

		$('input[type=file]').change(function() {

			$(this).simpleUpload("ajaxImageUpload?product=image", {
				start: function(file) {
					$('#photos').html(file.name);
					$('#progress').html("");
					$('#progressBar').width(0);
				},
				progress: function(progress) {
					$('#progress').html("Progress: " + Math.round(progress) + "%");
					$('#progressBar').width(progress + "%");
				},

				success: function(data) {
					if (data == "4") {
						$(".display_msg").html('<span class="imgList"><span class="glyphicon glyphicon-remove-circle" aria-hidden="true"></span> Unknown File Extension !</span>');

					} else if (data == "2" || data == "3") {
						$(".display_msg").html('<span class="imgList"><span class="glyphicon glyphicon-remove-circle" aria-hidden="true"></span> File Size Exceed !</span>');

					} else if (data != 2 || data != 3 || data != 4) {
						var name = data;
						var foldername = name.trim();
						var index = name.lastIndexOf("/");
						var filename = name.substring(index + 1);
						$("#hidden_p_image").val(filename);
						$("#img_preview").html('<img src="<?php echo _DOMAIN_; ?>' + foldername + '" target="_blank" class="img-responsive">');
						console.log(filename);
					}
				}

			});

		});

	});

	$(document).on("change", "#p_qty,#p_price", function() {
		var qty = $("#p_qty").val();
		var price = $("#p_price").val();
		console.log(parseFloat(qty));
		console.log(parseFloat(price));
		if (qty != "" && price != "") {
			var total = parseFloat(qty) * parseFloat(price);
			console.log(parseFloat(total));
			$("#tot_price").val(total);
		}
	})

	$(document).on("click", "#submit", function() {

		<?php if (isset($okmsg)) { ?>
			$(this).attr("disabled", "true");
		<?php } ?>
	})
</script>