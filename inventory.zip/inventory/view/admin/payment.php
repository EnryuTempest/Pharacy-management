<?php include "header.php"; ?>
<?php
require_once('plugins/zform/Zebra_Form.php');
?>
<?php
$form = new Zebra_Form('add_payment_form', 'post', '', array('autocomplete' => 'off', 'class' => 'form-horizontal'));
$form->csrf(false, 0);

$obj = $form->add('text', 'pname', '', array('class' => 'form-control', 'placeholder' => 'Patient Name'));
$obj->set_rule(array(
    'required'  =>  array('error', "Patient's name is required...!"),
));
//patient contact
$obj = $form->add('text', 'p_contact', '', array('class' => 'form-control', 'placeholder' => 'Contact'));
$obj->set_rule(array(
    'required'  =>  array('error', 'Quantity product is required!'),
    'digits' => array('', 'error', 'Patient number not valid!'),
    'length'    => array(10, 10, 'error', 'Contact number must be valid.'),
));
//product price
$obj = $form->add('text', 'p_amount', '', array('class' => 'form-control', 'placeholder' => 'Amount'));
$obj->set_rule(array(
    'required'  =>  array('error', 'Payment amount is required!'),
    'digits' => array('.', 'error', 'Input a valid amount!'),
));

//about product
$obj = $form->add('textarea', 'p_note', '', array('class' => 'form-control', 'row' => '3', 'placeholder' => 'Payment details'));
$obj->set_rule(array());
//payment type
$obj = $form->add('select', 'p_type', '', array('class' => 'form-control', 'row' => '3'));
$obj->add_options(array(
    'In Patient' => 'In Patient',
    'Out Patient' => 'Out Patient',
), true);

?>
<?php
if ($form->validate()) {
    $pdata = array(
        'pay_custo_id' => '',
        'pay_custo_name' => $_POST['pname'],
        'pay_custo_contact' => $_POST['p_contact'],
        'pay_custo_type' => $_POST['p_type'],
        'pay_amount' => $_POST['p_amount'],
        'pay_remark' => $_POST['p_note'],
        'pay_created_date' => date("Y-m-d H:i:s"),
        'pay_modified_date' => '',
    );
    $patientExist = $App->checkPatientByContactNo($_POST['p_contact'], "payments_tbl");

    if ($patientExist > 0) {

        if ($App->save('payments_tbl', $pdata)) {
            $okmsg = '<div class="alert alert-success">
    				<button class="close" data-dismiss="alert"></button>
    				<strong><span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span> Success ! </strong> Payment Successfully added.<span style="float:right;"><a href="payments_list"> view list</a></span>
    			</div>';
        }
    } else {
        $memdata = array(
            'mem_fname' => $_POST['pname'],
            'mem_contact' => $_POST['p_contact'],
            'mem_added_date' => date("Y-m-d H:i:s")
        );
        $App->save('payments_tbl', $pdata);
        if ($App->save('members_tbl', $memdata)) {
            $okmsg = '<div class="alert alert-success">
    				<button class="close" data-dismiss="alert"></button>
    				<strong><span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span> Success ! </strong> Payment & Patient Successfully Added.<span style="float:right;"><a href="payments_list"> view list</a></span>
    			</div>';
        }
    }
}
?>
<div class="container nopadding" style="border:1px #CCC solid;background:#FFF;">
    <div class="col-md-12 wrapper-pad" style="padding:35px 25px;">
        <?php
        if (isset($msg)) {
            echo $msg;
        }
        if (isset($okmsg)) {
            echo $okmsg;
        } ?>

        <div id="new_product_form" style="margin-left:30px;">
            <div class="" style="display: flex; justify-content: space-between;">
                <h3><i class="glyphicon glyphicon-plus" style="font-size:17px;"></i> Add Payment Details</h3>
                <h3 class="">
                    <a href="payments_list" class="small btn btn-success">
                        <i class="glyphicon glyphicon-eye-open"></i>&nbsp;View All
                    </a>
                </h3>
            </div>
            <hr />
            <div class="clearfix"></div>
            <form class="form-horizontal" method="post" id="add_nproduct_form" name="add_nproduct_form">
                <?php $form->render('view/zform_template/add_payment_zform.php'); ?>
            </form>

        </div>
    </div>
</div>
<?php include "footer.php"; ?>
<script type="text/javascript" src="<?php echo _DOMAIN_ ?>js/ajax.js"></script>

<script type="text/javascript">
    $(document).ready(function() {
        <?php if (isset($okmsg)) { ?>
            $(this).attr("disabled", "true");
        <?php } ?>
    })

    $(document).on("click", "#submit", function() {

        <?php if (isset($okmsg)) { ?>
            $(this).attr("disabled", "true");
        <?php } ?>
    })
</script>