<?php 

include "header.php";
?>

<div class="container-fluid nopadding" style="border:1px #CCC solid;background:#FFF;">
	<div class="col-md-12 wrapper-pad" style="padding:0px 30px 20px;">
		<div class="flash"></div> 
		<h3 class="followup-heading">Package List </h3>
		
		<table class="table table-hover table-striped" id="view_package_table" aria-describedby="view_package_table">
			<thead>
				<tr role="row" style="background:#337ab7;color:#FFF;">
					<th class="sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 60px;" aria-label="Name">ID</th>
					<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 100px;" > Name</th>
					<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 100px;" >Category</th>
					<th class="" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 100px;" aria-label="Name">Products</th>
					<th class="hidden-480" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 250px;"  >Action</th>
				</tr> 
			</thead>
			<tbody >

			</tbody>
		</table>
	</div>
</div>
<div class="modal fade" id="view_package_dtl" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Package Details</h4>
      </div>
      <div class="modal-body">
        <div class="view_package_details"></div>
      </div>
      
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<?php 
	
	include "footer.php"; ?>
  <link rel="stylesheet" href="<?php echo _DOMAIN_;?>css/demo_table.css" />
<script type="text/javascript">
$(document).ready(function()
{
		 var table;
		    table=$('#view_package_table').dataTable({
		    "aaSorting": [[ 0, 'desc' ]],
	        "bProcessing": true,
		    "bRetrieve": true,
	        "bServerSide": true,
			"pagingType": "simple",
	        "sAjaxSource": "<?php echo _DOMAIN_;?>admin/zform/view_package_server",
	    });

	    $(document).on("click",".btn-del-package",function(){
	    	var result=confirm("Are you sure you want delete this package?");
	    	if(result)
			{
				var packid=$(this).attr("id");
				data="action=delete-package&packid="+packid;
				$.post("<?php echo _DOMAIN_;?>admin/dal",data,function(res){
					table.fnDraw();
				})
			}
		}) 
})
$(document).on("click",".view_package",function(){
	var packid=$(this).attr("id");
	data="action=get_package_details&packid="+packid;
	
	$.post("<?php echo _DOMAIN_;?>admin/dal",data,function(res){
		$(".view_package_details").html(res);
	})
})

</script>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/ajax.js"></script>