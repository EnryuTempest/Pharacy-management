<?php include "header.php";
require_once "cgi-bin/objects.php" ?>
<div class="container-fluid nopadding" style="border:1px #CCC solid;background:#FFF;">
	<div class="col-md-12 wrapper-pad" style="padding:20px 30px;">
		<?php if (isset($msg)) echo $msg; ?>
		<div class="msg"></div>
		<div class="clearfix"></div>
		<?php $style = "";
		if ($count['cnt'] == "0") {
			$style = "display:none;";
		}
		?>
		<button class="btn btn-danger btn-empty-cart " style="float: right;<?php echo $style; ?>">Empty the cart</button>
		<h3>List of product in cart</h3>
		<div class="col-md-6" style="margin:15px 0px">
			<input type="text" name="mem_code_cart" id="mem_code_cart" value="">
		</div>
		<table class="table table-hover table-striped" id="cart_table" aria-describedby="sample_2_info">
			<thead>
				<tr role="row" style="background:#337ab7;color:#FFF;">
					<th class="sorting_asc" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" style="width: 60px;" aria-sort="ascending" aria-label="Client ID">ID</th>
					<th class="sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" style="width: 100px;" aria-label="Name">Product</th>
					<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" style="width: 150px;">Quantity</th>
					<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" style="width: 100px;">Price</th>
					<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" style="width: 250px;">Action</th>
				</tr>
			</thead>
			<tbody role="alert" aria-live="polite" aria-relevant="all"></tbody>
		</table>
		<div class="col-md-12" style="margin-top: 20px;">
			<button type="button" class="btn btn-success btn-stock-out" style="<?php echo $style; ?>">Check Out</button>
		</div>
	</div>
</div>
<!--edit cart modal--->
<div id="edit_cart_data" class="modal fade" role="dialog">
	<div class="modal-dialog">

		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close btn_cart_form_close btn-lg" data-dismiss="modal">Close X</button>
				<h4 class="modal-title"> Update Cart</h4>
			</div>
			<div class="modal-body ">

				<div class="cart_form">

				</div>
			</div>
			<div class="modal-footer">

			</div>
		</div>

	</div>
</div>
<?php include "footer.php"; ?>
<script type="text/javascript">
	$(document).ready(function() {

		var table;
		table = $('#cart_table').dataTable({
			"bProcessing": true,
			"bRetrieve": true,
			"bServerSide": true,
			"pagingType": "simple",
			"sAjaxSource": "<?php echo _DOMAIN_; ?>admin/zform/view_cart_data_server",
			"aaSorting": [
				[0, "desc"]
			]
		});
		$("")

		//delete from cart one at a time
		$(document).on("click", ".btn-del-from-cart", function() {
			$ele = $(this);
			var count = $(".cart_cnt").text();

			var conf = confirm("Äre you sure you want to delete?");
			if (conf) {

				dataString = "action=del_from_cart&id=" + $ele.attr("cid");
				$.ajax({
					type: "POST",
					url: "<?php echo _DOMAIN_; ?>admin/dal",
					data: dataString,
					dataType: "html",
					success: function(data) {
						table.fnDraw();
						count = parseInt(count) - 1;

						$(".cart_cnt").text(count);
					}
				})
			}

		})
		//empty the cart
		$(document).on("click", ".btn-empty-cart", function() {
			var conf = confirm("Do you want to empty the card?");
			if (conf) {
				dataString = "action=del_from_cart&id=0";
				$.post("<?php echo _DOMAIN_; ?>admin/dal", dataString, function(res) {
					table.fnDraw();
					$(".count_cart").css("display", "none");
				})
			}
		})

		//send the data into stock-out table adn empty the cart table
		$(document).on("click", ".btn-stock-out", function() {
			$mname = $("#mem_code_cart").val();
			if ($mname == "" || $mname == "0") {
				alert("Please select a patient! ");
			} else {
				dataString = "action=send-to-stock-out&cartempty=1&mem=" + $mname;
				$.post("<?php echo _DOMAIN_; ?>admin/dal", dataString, function(res) {
					window.location.href = "stock_out";
				})
			}
		})

		//edit the the cart
		$(document).on("click", ".btn-get-edit-form", function() {
			dataString = "action=get_cart_form_toEdit&cartid=" + $(this).attr("cid");

			$.ajax({
				type: "POST",
				url: "<?php echo _DOMAIN_; ?>admin/dal",
				data: dataString,
				dataType: "html",
				success: function(data) {

					$(".cart_form").html(data);
				}
			})
		})
		$(document).on("click", "#btn_edit_cart_submit", function() {
			var qty = $("#c_qty").val();
			if (qty == "" || parseInt(qty) == 0) {
				$(".msg_display").html("<div class='alert alert-danger'><button class='close' data-dismiss='alert'></button><strong><span class='glyphicon glyphicon-remove' aria-hidden='true'></span> Success ! </strong> Enter the Quantity!</div>");
			} else {
				dataString = "action=edit_cart_form&cartid=" + $("#cart_id").val() + "&qty=" + $("#c_qty").val();

				$.ajax({
					type: "POST",
					url: "<?php echo _DOMAIN_; ?>admin/dal",
					data: dataString,
					dataType: "html",
					success: function(data) {

						$(".btn_cart_form_close").click();
						$(".msg").html("<div class='alert alert-success'><button class='close' data-dismiss='alert'></button><strong><span class='glyphicon glyphicon-ok-circle' aria-hidden='true'></span> Success ! </strong>Successfully updated!</div>");
						$(".msg").delay(6000).hide();
						table.fnDraw();
					}
				})
			}
		})
	})
</script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/ajax.js"></script>