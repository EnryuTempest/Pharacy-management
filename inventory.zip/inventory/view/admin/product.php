<?php include "header.php"; ?>
<?php include "stockin_product.php"; ?>
<!-- Main container area -->
<div class="container-fluid nopadding">
	<div class="col-md-12 wrapper-pad" style="padding:0px 30px 20px;">
		<div class="cart_msg"></div>
		<!-- View list of existing groups -->
		<h3>List of Products <a href="add_product" class="btn btn-lg btn-primary " id="add_new_product" style="float: right;"><i class="fas fa-plus-square"></i> Add New Product</a></h3>
		<hr />
		<div class="filter_div" style="display:none;">
			Filter By category: <select name="parent_cat" id="parent_cat"><?php echo $Product->get_main_category_dropdown(); ?></select>
		</div>
		<table class="table table-hover table-striped" id="product_table" aria-describedby="sample_2_info">
			<thead>
				<tr role="row" style="background:#337ab7;color:#FFF;">
					<th class="sorting_asc" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" style="width: 50px;" aria-sort="ascending" aria-label="Client ID">S.No.</th>
					<th class="sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" style="width: 90px;" aria-label="Name">Code</th>
					<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" style="width: 150px;">Name</th>
					<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" style="width: 120px;"> Category</th>
					<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" style="width: 80px;">Quantity</th>
					<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" style="width: 80px;">Unit Price</th>
					<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" style="width: 80px;">Total Price</th>
					<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" style="width: 250px;">Action</th>
				</tr>
			</thead>
			<tbody role="alert" aria-live="polite" aria-relevant="all">

			</tbody>
		</table>
	</div>
</div><!-- End Main container -->
<!-- Modal to show add to cart-->
<div id="modal_add_to_cart" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close btn_cart_form_close btn-lg" data-dismiss="modal">Close X</button>
				<h4 class="modal-title"> Add Product to Cart</h4>
			</div>
			<div class="modal-body ">
				<div class="overlay"></div>
				<div class="success_msg_cart">
					SUCCESSFULLY ADDED!
					<br>
					<a href="cart" class="btn btn-primary">View Cart</a>
				</div>
				<div class="cart_form">

				</div>
			</div>
			<div class="modal-footer">
			</div>
		</div>
	</div>
</div>
<!-- Modal to stockin the productss-->
<div id="refill_stock" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close btn-lg " id="btn-close-stockin-form" data-dismiss="modal">Close X</button>
				<h4 class="modal-title">Refill Stock</h4>
			</div>
			<div class="modal-body" style="margin:0px;padding:0px;">
				<div class="overlay"></div>
				<div class="success_msg">
					SUCCESSFULLY ADDED!
				</div>
				<div class="col-md-12 ">
					<div class="add_msg"></div>
					<form method="post" id="add_product_form" name="add_product_form">
						<?php $form->render('view/zform_template/add_product_zform.php'); ?>
					</form>
				</div>
			</div>
			<div class="modal-footer">

			</div>
		</div>
	</div>
</div>
<!--ends  -->
<!-----------VIEW PRODUCT DETAIL---------->
<div id="modal_view_pro_detail" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close btn-lg " id="btn-close-stockin-form" data-dismiss="modal">Close X</button>
				<h4 class="modal-title">Product Detail</h4>
			</div>
			<div class="modal-body" style="margin:0px;padding:0px;">
				<div id="product-detail">

				</div>
			</div>
		</div>
	</div>
</div>
<!---->
<?php //include "stockin_modal.php";
?>
<?php include "footer.php"; ?>
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>css/demo_table.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>css/buttons.dataTables.min.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>css/buttons.bootstrap4.min.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>css/buttons.foundation.min.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>css/buttons.jqueryui.min.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>css/buttons.semanticui.min.css" />

<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/buttons.bootstrap4.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/buttons.html5.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/buttons.jqueryui.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/buttons.semanticui.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/buttons.flash.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/buttons.colVis.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/jszip.min.js"></script>

<script type="text/javascript">
	var table;
	$(document).ready(function() {
		table = $('#product_table').dataTable({
			"bProcessing": true,
			"bRetrieve": true,
			"bServerSide": true,
			"pagingType": "simple",
			"sAjaxSource": "<?php echo _DOMAIN_; ?>admin/zform/view_product_server",
			"aaSorting": [
				[0, "desc"]
			],
			"fnServerData": function(sSource, aoData, fnCallback) {
				aoData.push({
					"name": "main_cat",
					"value": $("#parent_cat").val()
				});
				$.getJSON(sSource, aoData, function(json) {
					fnCallback(json);
				})
			},
			"aoColumnDefs": [{
				'bSortable': true,
				'aTargets': [0]
			}],
			"bAutoWidth": false,
			"aLengthMenu": [
				[25, 50, 100, 200],
				[25, 50, 100, 200]
			],
			"iDisplayLength": 10,
			"dom": 'lBfrtip',
			"buttons": [{
				extend: 'excel',
				messageTop: 'Product List ',
				exportOptions: {
					columns: ':visible',
				}
			}],
			//columnDefs: [ {
			//  targets: -1,
			//visible: false
			//}]


		});
		$(document).on("click", "#btn-close-stockin-form", function() {
			table.fnDraw()
		});

		$("#add_product_form").submit(function(e) {

			var $form = $('#add_product_form').data('Zebra_Form');

			if ($form.validate()) {
				$(".overlay").delay(1000).show();
				e.preventDefault();
				dataString = $("#add_product_form").serialize();
				console.log(dataString);
				$.ajax({
					type: "POST",
					url: "<?php echo _DOMAIN_; ?>admin/dal?action=test",
					data: dataString,
					dataType: "html",
					success: function(data) {
						if (data == 1) {
							$(".add_msg").html(data);
							$(".overlay").hide();
							$(".success_msg").show();
						} else {
							$(".overlay").hide();
							$(".add_msg").html(data);
						}

					}
				});
			}
			return false;
		});
		$("#parent_cat").change(function() {
			table.fnDraw();
		});

		$(document).on("click", ".btn-del-product", function(res) {
			var pcode = $(this).attr("code");
			var pid = $(this).attr("pid");
			var result = confirm("Are you sure want to delete this product? All the related information about this product from other tables will also be deleted. Do you want to continue???");
			if (result) {
				data = "action=delete-product&p_code=" + pcode + "&pid=" + pid;
				$.post("<?php echo _DOMAIN_; ?>admin/dal", data, function(res) {
					table.fnDraw();
				});
			}
		});
		$(document).on("click", ".btn-get-pro-det", function(res) {
			var pcode = $(this).attr("code");
			var pid = $(this).attr("pid");
			data = "action=get-product-detail&pcode=" + pcode + "&pid=" + pid;
			$.post("<?php echo _DOMAIN_; ?>admin/dal", data, function(res) {
				$('#product-detail').html(res);
			});

		});
	});
</script>
<script src="<?php echo _DOMAIN_; ?>js/ajax.js"></script>