<?php 
include "header.php";


?>
<!-- Main container area -->
<div class="container-fluid nopadding" style="border:1px #CCC solid;background:#FFF;">
	<div class="col-md-12 wrapper-pad" style="padding:20px 30px;">
		<div class="flash"></div> 
		<h3 class="followup-heading">Product Returned History </h3>
				<!-- Add Member form -->
			<table class="table table-hover table-striped" id="viewtable" aria-describedby="viewtable_info">
				<thead>
					<tr role="row" style="background:#337ab7;color:#FFF;">
<th class="sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 70px;" aria-label="Name">S.No.</th>
						
						<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 140px;" >Name</th>
						<th class="" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 130px;" aria-label="Name">Product</th>
						<th class="" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 150px;" aria-label="Name">Qty</th>
						<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 150px;" >Date</th>
						<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 180px;" >Returned</th>
						<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 150px;" >Ret-Date</th>
					</tr> 
				</thead>
				<tbody >

				</tbody>
			</table>
			
	</div>
</div>
<!-- End Main container -->
<?php include "pro_pic_model.html";?>
<?php include "footer.php"; ?>
  <link rel="stylesheet" href="<?php echo _DOMAIN_;?>css/demo_table.css" />
<script type="text/javascript">
$(document).ready(function()
{
		 var table;
		    table=$('#viewtable').dataTable({
		    "aaSorting": [[ 0, 'desc' ]],
	        "bProcessing": true,
		    "bRetrieve": true,
	        "bServerSide": true,
			"pagingType": "simple",
	        "sAjaxSource": "<?php echo _DOMAIN_;?>admin/zform/view_stock_returned_server",
	  }); 
})
</script>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/ajax.js"></script>

