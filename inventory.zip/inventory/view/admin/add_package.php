<?php include "header.php"; ?>
<?php 
require_once('plugins/zform/Zebra_Form.php'); 

?>
<?php 
	$form = new Zebra_Form('addpackage_form', 'post', '', array('autocomplete' => 'off','class'=>'form-horizontal'));
    $form->csrf(false,0);
	//default value
	$obj = $form->add('hidden', 'hidden_pacid', '0');
	$obj =$form->add("text","name","", array('autocomplete' => 'off','class'=>'form-control','placeholder'=>'Name'));
	$obj->set_rule(array(
		'required' => array('error','Package Name is required')));

	$obj =$form->add("select","category","", array('autocomplete' => 'off','class'=>'form-control','placeholder'=>'First Name'));
	$obj->add_options(combo_values('category_tbl ','c_id,c_name',array('c_main_category'=>0,'c_sub_category'=>0),"order by c_name asc"));
	$obj->set_rule(array(
		'required' => array('error','Category is required')));

	if(isset($_GET['edit']) && $_GET['edit']!="")
	{
		 $res=db_get_table("package_tbl","*",array('pack_id'=>$_GET['edit']));
		 $form->auto_fill(array(
		 	'hidden_pacid'=>$_GET['edit'],
		 	'name'=>$res[0]['pack_name'],
		 	'catgeory'=>$res[0]['pack_category'],
		 ));
	}
	?>
	<?php 
	if($form->validate())
		{
			$data=array(
				'pack_name'=>$_POST['name'],
				'pack_category'=>$_POST['category'],
				'pack_date'=>date("Y-m-d"),
			);
			if($_POST['hidden_pacid']=="0")
			{
				if($id=$App->save("package_tbl",$data)>0)
				{
					$msg='<div class="alert alert-success">
							<button class="close" data-dismiss="alert"></button>
							<strong><span class="glyphicon glyphicon-ok-sign" aria-hidden="true"></span> Success !</strong>New package has been added successfully with ID :'.$id.'!
						</div>';
				}
				else
				{
					$msg='<div class="alert alert-warning">
								<button class="close" data-dismiss="alert"></button>
								<strong><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Error ! </strong> problem adding new package.
							</div>';
				}
			}else
			{
				db_update_values("package_tbl",$data,array('pack_id'=>$_POST["hidden_pacid"]));
				$msg='<div class="alert alert-success">
								<button class="close" data-dismiss="alert"></button>
								<strong><span class="glyphicon glyphicon-ok-sign" aria-hidden="true"></span> Success ! </strong> updated successfully
							</div>';
			}
		}?>
<div class="container-fluid nopadding" style="border:1px #CCC solid;background:#FFF;">
	<div class="col-md-12 wrapper-pad" style="padding:20px;">
	<?php if(isset($msg)) echo $msg; ?>
			<div  style="padding:15px 30px 50px 30px;">
				<a href="add_pack_product" class="btn btn-primary btn-lg" style="float:right;"><i class="glyphicon glyphicon-plus"></i> Add Product in Package</a>
				<?php if(isset($_GET['edit']) && $_GET['edit'])
					{
						echo '<h3> Edit Package</h3>';
					}
					else
					{
						echo '<h3> Add Package</h3>';
					}?>
					
					<form class="form-horizontals col-md-5" method="post" id="addpackage_form" name="addpackage_form" >
						<?php
						$form->render('view/zform_template/add_package_zform.php');
						?>
					</form><!-- ends form -->
			</div>
			<div class="clearfix"></div>
		<?php if(isset($_GET['edit']) && $_GET['edit'])
			{?>
				<h3>List of product in package</h3>
			<table class="table table-hover table-striped" id="view_productinpackage_table" aria-describedby="view_package_table">
				<thead>
					<tr role="row" style="background:#337ab7;color:#FFF;">
						<th class="sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 60px;" aria-label="Name">ID</th>
						<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 100px;" > Name</th>
						<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 100px;" >Code</th>
						<th class="" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 100px;" aria-label="Name">Quantity</th>
						<th class="hidden-480" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 250px;"  >Action</th>
					</tr> 
				</thead>
				<tbody >

				</tbody>
			</table>
		<?php }?>
	</div>
</div>
<!-- modal to edit package product -->
<div id="edit_package" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
	    <div class="modal-header">
	    	<button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
	    	<h4 class="modal-title">Edit Package</h4>
	    </div>
	    <div class="modal-body ">
	    	
	       <div class="view_package_for_edit">
	       
	       </div>
	    </div>
	    <div class="modal-footer">
	        
	    </div>
    </div>

  </div>
</div>
<div clas="clearfix"></div>
<?php include "footer.php";?>
<script type="text/javascript">
	$(document).ready(function()
	{
		 var table;
		    table=$('#view_productinpackage_table').dataTable({
		    "aaSorting": [[ 0, 'desc' ]],
	        "bProcessing": true,
		    "bRetrieve": true,
	        "bServerSide": true,
			"pagingType": "simple",
	        "sAjaxSource": "<?php echo _DOMAIN_;?>admin/zform/view_product_in_package_server",
	    });
	
	//get data in modal
	$(document).on("click",".btn-edit-package",function()
	{
		var ppid=$(this).attr("id");
		data="action=edit_package_products_form&ppid="+ppid;
		$.post("<?php echo _DOMAIN_;?>admin/dal",data,function(res){
			$(".view_package_for_edit").html(res);
		})
	})
//update the quantity of the product
	$(document).on("click",".btn-update-package-product",function(){
		var qty=$("#qty").val();
		var ppid=$(this).attr("id");
		if(qty==""||parseInt(qty)==0)
		{
			alert("Enter the quantity");
		}
		else
		{
			dataString="action=edit-package-products&qty="+qty+"&ppid="+ppid;
			$.post("<?php echo _DOMAIN_;?>admin/dal",dataString,function(res){
				$(".msg").html(res);
				table.fnDraw();
			})
		}
	});

	$(document).on("click",".btn-delete-package-product",function()
	{
		var ele=$(this);
		var id=$(this).attr('id');
		var result=confirm("Are you sure you want to delete this product?");
		if(result)
		{
			data="action=delete-package-product&ppid="+id;
			$.post("<?php echo _DOMAIN_;?>admin/dal",data,function(res){
				table.fnDraw();
			})
		}
	});
});
</script>

	