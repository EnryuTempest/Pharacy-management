<?php
include "header.php";


?>
<!-- Main container area -->
<div class="container-fluid nopadding" style="border:1px #CCC solid;background:#FFF;">
	<div class="col-md-12 wrapper-pad" style="padding:0px 30px 20px; ">
		<div class="flash"></div>
		<div class="row">
			<h3> <i class="fas fa-users"></i> List of Patients </h3>
			<table class="table table-hover table-striped" id="viewtable" aria-describedby="viewtable_info">
				<thead>
					<tr role="row" style="background:#337ab7;color:#FFF;">
						<th class="sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 70px;" aria-label="Name">S.No.</th>
						<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 100px;">Code</th>
						<th class="" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 120px;" aria-label="Name">First Name</th>
						<th class="" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 120px;" aria-label="Name">Last Name</th>
						<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 180px;">Address</th>
						<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 150px;">Contact</th>
						<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 200px;">Email</th>
						<th class="hidden-480" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 250px;">Action</th>
					</tr>
				</thead>
				<tbody>

				</tbody>
			</table>
		</div>
	</div>
</div>
<!-- End Main container -->
<?php include "footer.php"; ?>
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>css/demo_table.css" />
<script type="text/javascript">
	$(document).ready(function() {
		var table;
		table = $('#viewtable').dataTable({
			"aaSorting": [
				[0, 'desc']
			],
			"bProcessing": true,
			"bRetrieve": true,
			"bServerSide": true,
			"pagingType": "simple",
			"sAjaxSource": "<?php echo _DOMAIN_; ?>admin/zform/view_mem_server",
		});


		/***************to Deactivate the member (takes rule id to change the values)******************/
		$(document).on("click", ".mem-deactivate-btn", function() {
			var $confirm = confirm("Are you sure you want to Deactivate this member?");
			if ($confirm) {
				dataString = "action=deactivate-mem&mem-id=" + $(this).attr("id");
				$.ajax({
					type: "POST",
					url: "<?php echo _DOMAIN_; ?>admin/dal",
					data: dataString,
					dataType: "html",
					success: function(data) {
						table.fnDraw();
					}
				})
			}
		})
		/*********to Activate the rule (takes rule id to chnage the values)***********/
		$(document).on("click", ".mem-activate-btn", function() {
			var $confirm = confirm("Are you sure you want to Activate this member?");
			if ($confirm) {
				dataString = "action=activate-mem&mem-id=" + $(this).attr("id");
				$.ajax({
					type: "POST",
					url: "<?php echo _DOMAIN_; ?>admin/dal",
					data: dataString,
					dataType: "html",
					success: function(data) {
						table.fnDraw();
					}
				})
			}
		})
		/*************delete the member*********************/
		$(document).on("click", ".btn-del-member", function() {
			$result = confirm("Are you you want to delete this member? You can deactivate the member instead of deleting it.");
			if ($result) {
				dataString = "action=delete-mem&mem-id=" + $(this).attr("id");
				$.ajax({
					type: "POST",
					url: "<?php echo _DOMAIN_; ?>admin/dal",
					data: dataString,
					dataType: "html",
					success: function(data) {
						table.fnDraw();
					}
				})
			}
		})

	});
</script>