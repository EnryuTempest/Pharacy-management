<?php include "header.php"; ?>
<h1 class="text-center">Payment Details</h1>
<hr>

<div class="" style="display: flex; justify-content:center;">
    <ol type="1" class="shadow" style="padding: 45px;background: #f1f1f1;width: fit-content;border-radius: 7px;box-shadow: 2px 2px 7px #e0e0e0;">
        <?php

        if (isset($_GET['view'])) {
            $result = db_get_table('payments_tbl', '*', array('pay_id' => $_GET['view']));
            foreach ($result[0] as $key => $value) {
                if ($key == "pay_custo_name" || $key == "pay_custo_contact" || $key == "pay_amount" || $key == "pay_remark" || $key == "pay_created_date") {
        ?>
                    <li>
                        <h4><strong><?php echo strtoupper(str_replace("_", " ", str_replace("pay", "payment", $key))); ?></strong></h4>
                        <p><strong><?php echo $value; ?></strong></p>
                    </li>
        <?php
                }
            }
        }

        ?>
    </ol>
</div>
<?php include "footer.php"; ?>