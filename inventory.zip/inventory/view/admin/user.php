<?php include "header.php";
require_once('plugins/zform/Zebra_Form.php'); ?>
<?php $form = new Zebra_Form('add_user_form', 'post', '', array('autocomplete' => 'off', 'class' => 'form-horizontal'));
$form->csrf(false, 0);
//default value
$obj = $form->add('hidden', 'hidden_u_id', '0');
$obj = $form->add('hidden', 'hidden_pass', '');
$obj = $form->add('text', 'f_name', '', array('autocomplete' => 'off', 'class' => 'form-control', 'placeholder' => 'Name'));
$obj->set_rule(array(
	'required'  =>  array('error', 'Name is required!'),
));
$obj = $form->add('text', 'username', '', array('autocomplete' => 'off', 'class' => 'form-control', 'placeholder' => 'username'));
$obj->set_rule(array(
	'required'  => array('error', 'username is required!'),
));
$obj = $form->add('password', 'pass', '', array('autocomplete' => 'off', 'class' => 'form-control', 'placeholder' => '******'));
$obj->set_rule(array(
	'required'  =>  array('error', 'pass is required!'),
));
$obj = $form->add('password', 'conf_pass', '', array('class' => 'form-control'));
$obj->set_rule(array(
	'compare' => array('pass', 'error', 'Password not confirmed correctly!')
));
$obj = $form->add('text', 'contact', '', array('autocomplete' => 'off', 'class' => 'form-control', 'placeholder' => 'username'));
$obj->set_rule(array(
	'required'  => array('error', 'Contact is required!'),
	'digits'    => array('', 'error', 'Accepts only digits (0 to 9)'),
));

if (isset($_GET['id'])) {
	//get the existing data to autofill for updating
	$result = db_get_table('login_tbl', '*', array('log_id' => $_GET['id']));
	$form->auto_fill(array(
		'hidden_u_id'  => $result[0]['log_id'],
		'hidden_pass' => $result[0]['password'],
		'f_name' => $result[0]['name'],
		'username' => $result[0]['username'],
		'pass' => $result[0]['password'],
		'conf_pass' => $result[0]['password'],
		'contact' => $result[0]['contact'],
		'role' => $result[0]['user_type'],
	));
}
?>
<?php

if ($form->validate()) {
	if ($_POST['hidden_pass'] != $_POST['pass']) {
		$pass = md5($_POST['pass']);
	} else {
		$pass = $_POST['pass'];
	}
	$data = array(
		'name'			=> $_POST['f_name'],
		'username' 		=> $_POST['username'],
		'password' 		=> $pass,
		'contact'		=> $_POST['contact'],
		'user_type' 	=> 2,
		'is_active'		=> 1,
		'u_added_date'	=> date("Y-m-d H:i:s"),
	);

	if ($_POST['hidden_u_id'] == '0') {
		$id = $App->save('login_tbl', $data);
		if ($id > 0) {
			$okmsg = '<div class="alert alert-success">
								<button class="close" data-dismiss="alert"></button>
								<strong><span class="glyphicon glyphicon-ok-sign" aria-hidden="true"></span> Success ! </strong>New user has been added Successfully with ID :' . $id . '! Click <a href="user">here to continue</a> 
						</div>';
		} else {
			$msg = '<div class="alert alert-warning">
								<button class="close" data-dismiss="alert"></button>
								<strong><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Error ! </strong> problem creating new user.
							</div>';
		}
	} else {
		db_update_values("login_tbl", $data, array('log_id' => $_POST['hidden_u_id']));
		$msg = '<div class="alert alert-success">
								<button class="close" data-dismiss="alert"></button>
								<strong><span class="glyphicon glyphicon-ok-sign" aria-hidden="true"></span> Success ! </strong> member detail has been successfully updated 
						</div>';
	}
}
?>
<div class="container-fluid">
	<div class="col-md-12 wrapper-pad" style="padding:15px;">
		<h2><i class="fas fa-user"></i> Add User</h2>
		<?php if (isset($msg)) {
			echo $msg;
		}
		if (isset($okmsg)) {
			echo $okmsg;
		} ?>

		<div style="padding:0px 30px 20px 30px;">
			<!-- Add student form -->
			<form class="form-horizontals" method="post" id="add_user_form" name="add_user_form">
				<?php
				$form->render('view/zform_template/add_user_zform.php');
				?>
			</form><!-- ends form -->
		</div>
		<hr>
		<div class="row" style="padding:0px 10px;">
			<h3> <i class="fas fa-users"></i> List of User </h3>
			<table class="table table-hover table-striped" id="viewtable" aria-describedby="viewtable_info">
				<thead>
					<tr role="row" style="background:#337ab7;color:#FFF;">
						<th class="sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 70px;" aria-label="Name">S.No.</th>
						<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 100px;">Name</th>
						<th class="" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 120px;" aria-label="Name">Username</th>
						<th class="" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 120px;" aria-label="Name">Contact</th>
						<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 180px;">Role</th>
						<th class="hidden-480" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 250px;">Action</th>
					</tr>
				</thead>
				<tbody>

				</tbody>
			</table>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>
<script type="text/javascript">
	$(document).ready(function() {
		var table;
		table = $('#viewtable').dataTable({
			"aaSorting": [
				[0, 'desc']
			],
			"bProcessing": true,
			"bRetrieve": true,
			"bServerSide": true,
			"pagingType": "simple",
			"sAjaxSource": "<?php echo _DOMAIN_; ?>admin/zform/view_user_server",
		});

		$(document).on("click", ".btn-activate-user", function() {
			var result = confirm("Do you want to activate this user?");
			if (result) {
				dataString = "action=activate-user&uid=" + $(this).attr("uid");
				$.post("<?php echo _DOMAIN_; ?>admin/dal", dataString, function(res) {
					table.fnDraw();
				})
			}
		})
		$(document).on("click", ".btn-deactivate-user", function() {
			var result = confirm("Do you want to deactivate this user?");
			if (result) {
				dataString = "action=deactivate-user&uid=" + $(this).attr("uid");
				$.post("<?php echo _DOMAIN_; ?>admin/dal", dataString, function(res) {
					table.fnDraw();
				})
			}
		})
		$(document).on("click", ".btn-del-user", function() {
			var result = confirm("Do you want to delete this user?");
			if (result) {
				dataString = "action=delete-user&uid=" + $(this).attr("uid");
				$.post("<?php echo _DOMAIN_; ?>admin/dal", dataString, function(res) {
					table.fnDraw();
				})
			}
		})
	});

	$(document).on("click", "#submit", function() {

		<?php if (isset($okmsg)) { ?>
			$(this).attr("disabled", "true");
		<?php } ?>
	})
</script>