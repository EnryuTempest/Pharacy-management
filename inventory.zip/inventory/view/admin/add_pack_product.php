<?php include "header.php"; ?>
<?php 
require_once('plugins/zform/Zebra_Form.php'); 

?>
<?php 
	$form = new Zebra_Form('addpackage_form', 'post', '', array('autocomplete' => 'off','class'=>'form-horizontal'));
    $form->csrf(false,0);
	//default value
	$obj = $form->add('hidden', 'hidden_ppid', '0');

	$obj =$form->add("select","package","", array('autocomplete' => 'off','class'=>'form-control','placeholder'=>'package '));
	$obj->add_options(combo_values('package_tbl','pack_id,pack_name',array(),""));
	$obj->set_rule(array(
		'required' => array('error','Package is required')));

	$obj =$form->add("text","pro_code","", array('autocomplete' => 'off','placeholder'=>'Product'));
	
	$obj->set_rule(array(
		'required' => array('error','Product is required')));

	$obj= $form->add("text","qty","",array('autocomplete' => 'off','class'=>'form-control form-horizontal','placeholder'=>'Product Quantity'));
	$obj->set_rule(array(
		'required' => array('error','Quantity is required')));


	if(isset($_GET['edit']) && $_GET['edit']!="")
	{

	}
	?>
	<?php 
	if($form->validate())
		{
			$data=array(
				'pp_pack_id'=>$_POST['package'],
				'pp_product_code'=>$_POST['pro_code'],
				'pp_product_qty'=>$_POST['qty'],
			);
			if($_POST['hidden_ppid']=="0")
			{
				if($id=$App->save("package_product_tbl",$data)>0)
				{
					$msg='<div class="alert alert-success">
							<button class="close" data-dismiss="alert"></button>
							<strong><span class="glyphicon glyphicon-ok-sign" aria-hidden="true"></span> Success !</strong>product has been added successfully!
						</div>';
				}
				else
				{
					$msg='<div class="alert alert-warning">
								<button class="close" data-dismiss="alert"></button>
								<strong><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Error ! </strong> problem adding product to the chosen package.
							</div>';
				}
			}
			else
			{
				db_update_values("package_product_tbl",$data,array('pp_id'=>$_POST["hidden_ppid"]));
				$msg='<div class="alert alert-warning">
								<button class="close" data-dismiss="alert"></button>
								<strong><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Success ! </strong> updated successfully
							</div>';
			}
		}?>
<div class="container-fluid nopadding" style="border:1px #CCC solid;background:#FFF;">
	<div class="col-md-12 wrapper-pad" style="padding:20px;">
	<?php if(isset($msg)) echo $msg; ?>
			<div class="col-md-5" style="padding:15px 30px 50px 30px;">
				<h3> Add product in package</h3>
					<form class="form-horizontals" method="post" id="addpackage_form" name="addpackage_form" >
						<?php
						$form->render('view/zform_template/add_product_package_zform.php');
						?>
					</form><!-- ends form -->
			</div>
	</div>
</div>	

<?php include "footer.php";?>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/ajax.js"></script>
<script type="text/javascript">
	// $(document).on("change","#package",function(){
	// 	var packid=$(this).val();
	// 	console.log(packid);
	// 	data="action=get_pack_related_product&packid="+packid;
	// 	$.post("<?php echo _DOMAIN_?>admin/dal",data,function(res){
	// 		$("#pro_code").html(res);
	// 	})
	// })

	// $(document).on("change","#pro_code",function(){
	// 	var packid=$(this).val();
	// 	console.log(packid);
	// })
</script>



	