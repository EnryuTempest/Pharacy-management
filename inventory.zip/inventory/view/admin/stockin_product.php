<?php
require_once("header.php");
require_once('plugins/zform/Zebra_Form.php'); 
require_once('cgi-bin/objects.php');
?>
<?php

$form = new Zebra_Form('add_product_form', 'post', '', array('autocomplete' => 'off','class'=>'form-horizontal'));
$form->csrf(false,0);

//for default add
$obj = $form->add('hidden', 'pa_id', '0');
$obj = $form->add('hidden','pid','');
$obj = $form->add('hidden','previous_qty','');

//product code in select
$obj = $form->add('text', 'pname','',array('class'=>'form-control','readonly'=>'readonly'));
$obj->set_rule(array(
        // 'required'  =>  array('error', 'Select the product!'),
	));
$obj = $form->add('text', 'pa_code','',array('class'=>'form-control','readonly'=>'readonly'));
$obj->set_rule(array(
        'required'  =>  array('error', 'Select the product!'),
	));
//product qnty
$obj = $form->add('text', 'pa_qty','',array('class'=>'form-control','placeholder'=>'Quantity '));
$obj->set_rule(array(
        'required'  =>  array('error', 'Quantity added is required!'),
        'number'=>array('','error','Number only'),
	));
//product_price
$obj = $form->add('text', 'pa_price','',array('class'=>'form-control'));
$obj->set_rule(array(
		'required'  =>  array('error', 'Price is required!'),
		'number' => array('.','error', 'Numbers only'),
    ));
//note
$obj = $form->add('textarea', 'pa_note','',array('class'=>'form-control','row'=>'3','placeholder'=>'Note'));
$obj->set_rule(array(
        // 'required'  =>  array('error', 'Select the product!'),
	));
	
	if(isset($_GET['edit']) && $_GET['edit']!="")
	{
		$res=db_get_table("product_added_tbl left join product_tbl on p_code=p_add_pro_code","*",array("p_add_id"=>$_GET['edit']));
		//print_r($res);
		$form->auto_fill(array(
			'pa_id'=>$res[0]['p_add_id'],
			'pname'=>$res[0]['p_name'],
			'pa_code'=>$res[0]['p_add_pro_code'],
			'pa_qty'=>$res[0]['p_add_qty'],
			'pa_price'=>$res[0]['p_add_price'],
			'pa_note'=>$res[0]['p_add_note'],
			'previous_qty'=>$res[0]['p_add_qty']
		));

		if ($form->validate()) 
		{
			$data=array(
				'p_add_qty'=>$_POST['pa_qty'],
				'p_add_price'=>$_POST['pa_price'],
				'p_add_note'=>$_POST['pa_note'],
			);
			
			$pqty=$Product->get_product_qnty($_POST['pa_code']);
			$new_qty=($pqty['p_quantity']-$_POST['previous_qty'])+$_POST['pa_qty'];
			if($_POST['pa_id']!=0)
			{
				db_update_values("product_added_tbl",$data,array('p_add_id'=>$_POST['pa_id']));
				db_update_values("product_tbl",array('p_quantity'=>$new_qty,'p_price'=>$_POST['pa_price']),array('p_code'=>$_POST['pa_code']));
				$msg='<div class="alert alert-success"><button class="close" data-dismiss="alert"></button><strong><span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span> Success ! </strong> Product Updated Successfully. <span style="float:right;"><a href="stockIn"><< Back to Stock History</a></span></div>';
			}

		}
	}

?>
<?php if(isset($_GET['edit']) && $_GET['edit']!=""){?>
<div class="container nopadding" style="border:1px #CCC solid;background:#FFF;">
	<div class="col-md-12 wrapper-pad" style="padding:20px;">
	<?php if(isset($msg)) echo $msg; ?>
			<div  style="padding:0px 30px 50px 30px;">
				<h3><i class="glyphicon glyphicon-edit"></i>Edit Stock In</h3>
			<!-- Edit Stock form -->
				<form class="form-horizontals" method="post" id="addmem_form" name="addmem_form" >
					<?php
					$form->render('view/zform_template/add_product_zform.php');
					?>
				</form><!-- ends form -->
			</div>
	</div>
</div><!--end container-->
<?php }?>
