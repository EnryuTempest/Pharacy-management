<?php 

include "header.php";
include "stockin_product.php";
?>
<?php if(!isset($_GET['edit']))
{?>
	<div class="container-fluid nopadding" style="border:1px #CCC solid;background:#FFF;">
		<div class="col-md-12 wrapper-pad" style="padding:0px 30px 20px;">
			<div class="flash"></div> 
			<div class="row">
				<div class="bs-example-title" data-example-id="striped-table">	
					<h4 class="followup-heading">Advance Filter</h4>
					<div class="advance_filter">
						<div class="col-md-3">
							<label>Filter By category</label>
							<select name="parent_cat" id="parent_cat" class="form-control" >
								<?php echo $Product->get_main_category_dropdown();?>
							</select>
							
						</div>
						<div class="col-md-3 ">
							<label for="InputServiceCode">Product</label>
							<input type="text" name="product_code" id="product_code" class="product_code ">
						</div>
						<div class="col-md-2 control-label ">
							<label for="inputDOB">Date: From </label>
							<input type="date" class="form-control" name="start_date" id="start_date"/>
						</div>
		
						<div class="col-md-2 control-label ">
							<label for="inputDOB">To</label>
							<input type="date" class="form-control" name="end_date" id="end_date" />
						</div>
						<div class="col-md-2 control-label nopadding">
							<button type="button" id="adv-filter" class="btn btn-warning btn_search" style="margin-top:23px"> <span class="glyphicon glyphicon-search" aria-hidden="true"></span> Search</button>
						</div>
					</div>
				</div>
			</div>
		
			<h3 class="followup-heading">StockIn History </h3>
			<!-- Add Member form -->
			<table class="table table-hover table-striped" id="view_p_added_table" aria-describedby="viewtable_info">
				<thead>
					<tr role="row" style="background:#337ab7;color:#FFF;">
						<th class="sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 70px;" aria-label="Name">Sno</th>
						
						<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 180px;" > Product Name</th>
						<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 100px;" >Code</th>
						<th class="" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 150px;" aria-label="Name">Date</th>
						<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 70px;" > Qty</th>
						<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 90px;" >Price</th>
						<th class="hidden-480" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 250px;"  >Note</th>
						<th class="hidden-480" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 50px;"  >Action</th>
					</tr> 
				</thead>
				<tbody >

				</tbody>
			</table>

		</div>
	</div>
<?php }?>
<!--  -->
<?php 

	include "pro_pic_model.html";
	include "footer.php"; ?>
  <link rel="stylesheet" href="<?php echo _DOMAIN_;?>css/demo_table.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_;?>css/buttons.dataTables.min.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_;?>css/buttons.foundation.min.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_;?>css/buttons.jqueryui.min.css" />
  <link rel="stylesheet" href="<?php echo _DOMAIN_;?>css/buttons.bootstrap4.min.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_;?>css/buttons.semanticui.min.css" />

<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/buttons.bootstrap4.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/buttons.html5.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/buttons.jqueryui.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/buttons.semanticui.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/buttons.flash.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/buttons.colVis.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/jszip.min.js"></script>

<script type="text/javascript">
$(document).ready(function()
{
		 var table;
		    table=$('#view_p_added_table').dataTable({
		    "aaSorting": [[ 0, 'desc' ]],
	        "bProcessing": true,
		    "bRetrieve": true,
	        "bServerSide": true,
			"pagingType": "simple",
	        "sAjaxSource": "<?php echo _DOMAIN_;?>admin/zform/view_product_added_server",
	        "fnServerData": function ( sSource, aoData, fnCallback ) {
					aoData.push( { "name": "main_cat", "value": $("#parent_cat").val() },{ "name": "product_code", "value": $("#product_code").val() },{ "name": "start_date", "value": $("#start_date").val() },{ "name": "end_date", "value": $("#end_date").val() } );
					$.getJSON( sSource, aoData, function (json) {
						fnCallback(json);
					})
				},
			"aoColumnDefs": [{
                        'bSortable': true,
                        'aTargets': [0]
                    }],
			"bAutoWidth": false,
			"dom": 'lBfrtip',
                "buttons": [
                {
                     extend: 'excel',
                   messageTop: 'Stock In History ',
                    exportOptions: {
                    	columns: ':visible',
                	}
                },'colvis'
	        ],
	        columnDefs: [ {
	            targets: -1,
	            visible: false
	        }]
	  }); 

		$(document).on("click","#adv-filter",function(){
			table.fnDraw();
		})
})
</script>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/ajax.js"></script>