<?php
global $mysqli;
require_once('cgi-bin/objects.php');

/*****Member******/
//deactivate the member on button click using the mem_id which is in integer format
if (isset($_POST['action']) && $_POST['action'] == "deactivate-mem") {
	$res = db_update_values("members_tbl", array('mem_status' => 0), array('mem_id' => $_POST['mem-id']));
	echo $res;
}
//activate the member on button click using the mem_id which is in integer format
else if (isset($_POST['action']) && $_POST['action'] == "activate-mem") {
	$res = db_update_values("members_tbl", array('mem_status' => 1), array('mem_id' => $_POST['mem-id']));
	echo $res;
}
//delete the member
else if (isset($_POST['action']) && $_POST['action'] == "delete-mem") {
	$sql = "DELETE from members_tbl where mem_id=" . $_POST['mem-id'];
	$res = db_execute_sql($sql);
	echo $res;
}
/**************Product*****************/
else if (isset($_GET['action']) && $_GET['action'] == "test") {
	$pqty = $Product->get_product_qnty($_POST['pa_code']);

	$pdata = array(
		'p_add_pro_code' => $_POST['pa_code'],
		'p_add_qty' => $_POST['pa_qty'],
		'p_add_price' => $_POST['pa_price'],
		'p_add_note' => $_POST['pa_note'],
		'p_add_date' => date("Y-m-d H:i:s"),
	);
	if ($_POST['pa_id'] == 0) {
		if (($id = $App->save('product_added_tbl', $pdata)) > 0) {
			$new_qty = $pqty['p_quantity'] + $_POST['pa_qty'];

			if (db_update_values("product_tbl", array('p_quantity' => $new_qty, 'p_price' => $_POST['pa_price']), array('p_code' => $_POST['pa_code'])) > 0) {
				echo '1';
				// <div class="alert alert-success"><button class="close" data-dismiss="alert"></button>							<strong><span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span> Success ! </strong> Product Successfully added with ID:'. $id .'!						</div>';
			} else {
				echo '<div class="alert alert-danger">
							<button class="close" data-dismiss="alert"></button>
							<strong><span class="glyphicon glyphicon-remove-circle" aria-hidden="true"></span>Error ! </strong> Problem updating the quantity!
						</div>';
			}
		} else {
			echo '<div class="alert alert-warning">
					<button class="close" data-dismiss="alert"></button>
					<strong><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Error ! </strong> Problem  adding product .Please check the product details!
				</div>';
		}
	}
}

//delete the product and all related info in other table using the product code

else if (isset($_POST['action']) && $_POST['action'] == "delete-product") {
	$sql = "DELETE FROM return_tbl where r_p_code='" . $_POST['p_code'] . "'";
	$res = db_execute_sql($sql);
	echo $res;
	$sql2 = "DELETE FROM product_added_tbl where p_add_pro_code='" . $_POST['p_code'] . "'";
	$res2 = db_execute_sql($sql2);
	echo $res2;
	$sql3 = "DELETE FROM stock_out_tbl where sal_product_code='" . $_POST['p_code'] . "'";
	$res3 = db_execute_sql($sql3);
	echo $res3;
	$sql4 = "DELETE FROM product_tbl where p_code='" . $_POST['p_code'] . "'";
	$res4 = db_execute_sql($sql4);
	echo $res4;
	$sql5 = "DELETE FROM package_product_tbl where pp_product_code='" . $_POST['p_code'] . "'";
	$res5 = db_execute_sql($sql5);
	echo $res5;
} else if (isset($_POST['action']) && $_POST['action'] == "get-product-detail") {
	$sql = "SELECT * from product_tbl where `p_id`=" . $_POST['pid'] . " and `p_code`='" . $_POST['pcode'] . "'";
	$pleft = $Product->get_product_left($_POST['pcode']);
	$res = db_get_table_sql($sql);
	if (count($res) > 0) {
		/**
		 * 
		 * These are extra informations
		 * 
		 *      <tr>
                            <th scope="row">Child Category 1</th>
                            <td>' . (empty($res[0]['p_child_cat_1']) ? "<span class='removeProduct'>Not Set</span>" : $App->get_category_name($res[0]['p_child_cat_1'])) . '</td>
                        </tr>
                  
                        <tr>
                            <th scope="row">Child Category 2</th>
                            <td>' . (empty($res[0]['p_child_cat_2']) ? "<span class='removeProduct'>Not Set</span>" : $App->get_category_name($res[0]['p_child_cat_2'])) . '</td>
						</tr>
						<tr>
                            <th scope="row">CTEVT Standard Quantity</th>
                            <td>' . (empty($res[0]['p_stnd_qnty']) ? "<span class='removeProduct'>Not Set</span>" : $res[0]['p_stnd_qnty']) . '</td>
                        </tr>
						<tr>
                            <th scope="row">Image</th>
                            <td>' . (empty($res[0]['p_image']) ? "<span class='removeProduct'>Not Set</span>" : '<img src="' . _DOMAIN_ . 'files/product/' . $res[0]['p_image'] . '" width="100px" height="100px" class="img-responsive">') . '</td>
						</tr>

		 */
		echo '<table class="table table-striped">
                    <tbody>
                        <tr>
                            <th scope="row">Product Code</th>
                            <td>' . (empty($res[0]['p_code']) ? "<span class='removeProduct'>Not Set</span>" : $res[0]['p_code']) . '</td>
                        </tr>
                        <tr>
                            <th scope="row">Product Name</th>
                            <td>' . (empty($res[0]['p_name']) ? "<span class='removeProduct'>Not Set</span>" : $res[0]['p_name']) . '</td>
                        </tr>
                        <tr>
                            <th scope="row">Parent Category</th>
                            <td>' . (empty($res[0]['p_parent_cat']) ? "<span class='removeProduct'>Not Set</span>" : $App->get_category_name($res[0]['p_parent_cat'])) . '</td>
                        </tr>
 
						<tr>
                            <th scope="row">Quantity </th>
                            <td>' . (empty($res[0]['p_quantity']) ? "<span class='removeProduct'>Not Set</span>" : $pleft['p_left']) . '</td>
                        </tr>
                        <tr>
                            <th scope="row">Price</th>
                            <td>' . (empty($res[0]['p_price']) ? "<span class='removeProduct'>Not Set</span>" : $res[0]['p_price']) . '</td>
						</tr>
						<tr>
                            <th scope="row">Note</th>
                            <td>' . (empty($res[0]['p_note']) ? "<span class='removeProduct'>Not Set</span>" : $res[0]['p_note']) . '</td>
                        </tr>
                    </tbody>
                </table>';
	} else {
		echo "No info found";
	}
}
/***************categroy******/
//get the list of sub category when main cat value is entered
else if (isset($_POST['action']) && $_POST['action'] == "get-sub-cat") {
	$sql = "SELECT c_id,c_name from category_tbl where `c_main_category`=" . $_POST['main-cat-id'] . " and `c_sub_category`=0 ";
	$res = db_get_table_sql($sql);
	if (count($res) > 0) {
		$option = "<option value='0'>---Select---</option>";
		foreach ($res as $value) :
			$option .= "<option value='" . $value['c_id'] . "'>" . $value['c_name'] . "</option>";

		endforeach;
		echo $option;
	} else {
		echo "<option value='0'>No Child1 category</option>";
	}
}

// //get the list of leaf category when sub cat and main cat value  are selected
else if (isset($_POST['action']) && $_POST['action'] == "get-leaf-cat") {
	$sql = "SELECT c_id,c_name from category_tbl where `c_sub_category`=" . $_POST['sub-cat-id'] . "";
	$res = db_get_table_sql($sql);
	if (count($res) > 0) {
		$option = "<option value='0'>----Select----</option>";
		foreach ($res as $value) :
			$option .= "<option value='" . $value['c_id'] . "'>" . $value['c_name'] . "</option>";

		endforeach;
		echo $option;
	} else {
		echo "<option value='0'>No Child2 category</option>";
	}
}
//delete category
else if (isset($_POST['action']) && $_POST['action'] == "delete-category") {
	$product_exists = $App->check_product_exists($_POST['cid']);
	$package_exists = $App->check_package_exists($_POST['cid']);
	if ($product_exists == 1 || $package_exists > 0) {
		echo '<div class="alert alert-danger">
							<button class="close" data-dismiss="alert"></button>
							<strong><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Error ! </strong> contains product associated to it, cannot be deleted
					</div>';
	} else {
		$sql = " DELETE FROM `category_tbl` WHERE `c_id`=" . $_POST['cid'];
		$res = db_execute_sql($sql);
		$sql2 = "	DELETE from `category_tbl` where `c_main_category`=" . $_POST['cid'];
		$res2 = db_execute_sql($sql2);
		$sql3 = "	DELETE from `category_tbl` where `c_sub_category`=" . $_POST['cid'];
		$res3 = db_execute_sql($sql3);
		$sql4 = "DELETE from `package_tbl` where `pack_category`=" . $_POST['cid'];
		$res4 = db_execute_sql($sql4);
		echo 1;
	}
}
//delete package
else if (isset($_POST['action']) && $_POST['action'] == "delete-package") {
	$sql = "DELETE from package_tbl where pack_id=" . $_POST['packid'];
	$res = db_execute_sql($sql);
	$sql = "DELETE from package_product_tbl where `pp_pack_id`=" . $_POST['packid'];
	$res = db_execute_sql($sql);
	echo $res;
}
//delete the return and stockout
else if (isset($_POST['action']) && $_POST['action'] == "delete-stockout") {
	$sql = "DELETE from return_tbl where `r_sale_id`=" . $_POST['salid'];
	$res = db_execute_sql($sql);
	$sql = "DELETE FROM stock_out_tbl where `sal_id`=" . $_POST['salid'];
	$res = db_execute_sql($sql);
	if ($res != 0) {
		echo 1;
	} else {
		echo 2;
	}
}
// 


//get the list of product with p_code as its id when value entered using select2 ajax
else if (isset($_GET['pcode']) && $_GET['pcode'] != "") {
	$sql = "SELECT p_code,p_name from product_tbl where  `p_name` like " . "'%" . $_GET['pcode'] . "%'";
	//echo $sql;
	$res = db_get_table_sql($sql);
	echo JSON_encode($res);
}
//get the list of product with p_code as its id when value entered using select2 ajax
else if (isset($_GET['memcodecart']) && $_GET['memcodecart'] != "") {
	$sql = "SELECT mem_code,mem_fname,mem_lname,mem_contact from members_tbl where  `mem_fname` like " . "'%" . $_GET['memcodecart'] . "%' or `mem_contact` like " . "'%" . $_GET['memcodecart'] . "%' and mem_status=1";
	//echo $sql;
	$res = db_get_table_sql($sql);
	echo JSON_encode($res);
}
/**
 * PAYMENTS_LIST
 * 
 */
else if (isset($_GET['ac']) && $_GET['page'] == 'payments') {
	$sql = null;
	if ($_GET['ac'] == "pname") {
		$sql = "SELECT * from payments_tbl where  `pay_custo_name` like " . "'%" . $_GET['memcode'] . "%'";
	} else if ($_GET['ac'] == "pcontact") {
		$sql = "SELECT * from payments_tbl where  `pay_custo_contact` like " . "'%" . $_GET['memcode'] . "%'";
	} else if ($_GET['ac'] == "ptype") {
		$sql = "SELECT DISTINCT * from payments_tbl where  `pay_custo_type` like " . "'%" . $_GET['memcode'] . "%' GROUP BY pay_custo_type";
	}

	//echo $sql;
	$res = db_get_table_sql($sql);
	echo JSON_encode($res);
} else if (isset($_GET['memcode']) && $_GET['memcode'] != "") {
	$sql = "SELECT mem_code,mem_fname,mem_lname from members_tbl where  `mem_fname` like " . "'%" . $_GET['memcode'] . "%' ";
	//echo $sql;
	$res = db_get_table_sql($sql);
	echo JSON_encode($res);
} else if (isset($_POST['action']) && $_POST['action'] == "get_pname") {
	$res = db_get_table("product_tbl", "p_name", array('p_code' => $_POST['code']));
	echo $res;
}
/**
 * delete payment (soft delete)
 * 
 */
else if (isset($_POST['action']) && $_POST['action'] == "deletePpayment") {
	// echo $_POST['payId'];
	$sql = "UPDATE payments_tbl SET pay_is_deleted = 1 WHERE pay_id =" . $_POST['payId'];
	// echo $sql;
	// exit(0);
	$res = db_execute_sql($sql);
}

/**
 * 
 * 
 */
//add to cart
else if (isset($_POST['action']) && $_POST['action'] == "get_cart_form") {
	//mytesting
	$pdtls = ($Product->get_product_details($_POST['code']));
	// print_r($pdtls);
	// exit(0);
	$cerqty = $Product->get_p_Incart($_POST['code']);
	// print_r($cerqty['qty']);
	$qleft = $pdtls['p_left'] - $cerqty['qty'];
	// echo $qleft;
	// 
	echo '<form method="post">
				<div class="mesg"></div>
		     	<div class="form-group">
	       			<input type="hidden" name="cart_pcode" id="cart_pcode" value="' . $_POST['code'] . '">
					<input type="hidden" name="q_left" id="q_left" value="' . $qleft . '">
					<input type="hidden" name="p_id" id="p_id" value="' . $pdtls['p_id'] . '">

	       			<p>Product Title : ' . $pdtls['p_name'] . '</p>
	       			<p>Current Stock : ' . $qleft . '</p>
	       			<p>Unit Price : ' . $pdtls['p_price'] . '</p>

	       			<label>Enter your quantity :</label>
	       			<input type="text" name="cart_qty" id="cart_qty" value="" required>
				</div>
	       		<button type="button" class="btn btn-primary" name="p_add_to_cart" id="p_add_to_cart"> Add To Cart </button>

		       </form>';
} else if (isset($_POST['action']) && $_POST['action'] == "save_in_cart") {
	$data = array(
		'cartpid' => $_POST['pid'],
		'cart_p_code' => $_POST['pcode'],
		'cart_qty' => $_POST['qty'],
	);

	$pname = $Product->get_product_name($_POST['pcode']);
	if ($App->save("cart_tbl", $data)) {

		// echo '<div class="alert alert-success">
		// 			<button class="close" data-dismiss="alert"></button>
		// 			<strong><span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span> Success ! </strong> '.$pname['p_name'].'('.$_POST['qty'].' items) added in cart!
		// 		</div>';
		echo '1';
		//<a href="cart" class="btn btn-primary"> Show in cart </a>';
	} else {
		echo '<div class="alert alert-danger">
							<button class="close" data-dismiss="alert"></button>
							<strong><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Error ! </strong> Problem adding product in cart
					</div>';
	}
}
/******** cart *******/
else if (isset($_POST['action']) && $_POST['action'] == "del_from_cart") {
	if ($_POST['id'] == 0) {
		$sql = "DELETE from cart_tbl ";

		$val = db_execute_sql($sql);
		echo $val;
	} else {
		$sql = "DELETE from cart_tbl where cart_id=" . $_POST['id'];

		$val = db_execute_sql($sql);
		echo $val;
	}
} else if (isset($_POST['action']) && $_POST['action'] == "send-to-stock-out") {
	$data = $App->get_cart_data();
	foreach ($data as $s) :
		$pById = $App->get_product_details_by_id($s['cartpid']);
		$stock_data = array(
			'sal_mem_code' => $_POST['mem'],
			'sal_product_code' => $s['cart_p_code'],
			'sal_product_qty' => $s['cart_qty'],
			'sal_date' => date("Y-m-d H:i:s"),
			'sal_return_id' => 0,
			'sal_return_qty' => 0,
			'sal_staff_id' => $page->user->userid,
			'sal_total_amt' => ($pById['p_price'] * $s['cart_qty']),
		);
		$App->save("stock_out_tbl", $stock_data);
	endforeach;
	$val = db_execute_sql("DELETE from cart_tbl ");
}
//form to edit the quantity entered in the cartt
else if (isset($_POST['action']) && $_POST['action'] == "get_cart_form_toEdit") {
	$c_dtls = $Product->get_cart_dtls($_POST['cartid']);
	echo '	<div class="msg_display"><div>
				<p>Product Title: ' . $c_dtls['p_name'] . '</p>
       			<p>Product Code : ' . $c_dtls['cart_p_code'] . '</p>
       			<p>Unit Price : ' . $c_dtls['p_price'] . '</p>
       			<form method="post">
       			<input type="hidden" value="' . $_POST['cartid'] . '" name="cart_id" id="cart_id">
				<div class="form-group">

					<label>Quantity :</label>
	       			<input type="text" name="c_qty" id="c_qty" class="form-control" value="' . $c_dtls['cart_qty'] . '" required>
				</div>
	       		<button type="button" class="btn btn-primary" name="btn_edit_cart_submit" id="btn_edit_cart_submit">Update Cart </button>

		       </form>';
}
//edit the qnty in cart
else if (isset($_POST['action']) && $_POST['action'] == "edit_cart_form") {
	$res = db_update_values("cart_tbl", array('cart_qty' => $_POST['qty']), array('cart_id' => $_POST['cartid']));
	echo $res;
}

/******************************************stock***********************************************/
//return stock
else if (isset($_POST['action']) && $_POST['action'] == "get_return_form") {
	$qty_taken = $App->get_p_qty_taken($_POST['sid']);
	// print_r($qty_taken);
	$q_already_ret = $App->get_qty_returned($_POST['sid']);
	// print_r($q_already_ret);
	$p_ret_left = $qty_taken['sal_product_qty'] - $q_already_ret['returned'];
	echo '<form method="post">
		<div class="msg"></div>
	     	<div class="form-group">
	       			<input type="hidden" name="sid" id="sid" value="' . $_POST['sid'] . '">
	       			<input type="hidden" name="spcode" id="spcode" value="' . $_POST['code'] . '">
	       			<label>Product taken</label> <input type="text" class=" form-control taken" value="' . $qty_taken['sal_product_qty'] . '" readonly="readonly">';
	if ($q_already_ret['returned'] > 0) {
		echo '<label>Product Returned</label><input type="text" class="form-control returned" value="' . $q_already_ret['returned'] . '" readonly="readonly">
					<input type="hidden" class="ret-left" value="' . $p_ret_left . '" >';
	}
	echo '<label>Return Quantity </label>
	       			<input type="text" name="ret_qty" class="form-control" id="ret_qty" value=""><br>
				
	       		<button type="button" class="btn btn-primary" name="submit_return_form" id="submit_return_form"> Submit </button>
	       		</div>
	       </form>';
} else if (isset($_POST['action']) && $_POST['action'] == "stock_returned") {
	$data = array(
		'r_sale_id' => $_POST['salid'],
		'r_qty' => $_POST['rqty'],
		'r_date' => date('Y-m-d H:i:s'),
		'r_p_code' => $_POST['spcode'],
	);
	///
	if ($rid = $App->save("return_tbl", $data)) {
		$ret = $App->get_product_return($_POST['salid']);
		$amt = $ret + $_POST['rqty'];
		db_update_values("stock_out_tbl", array('sal_return_id' => $rid, 'sal_return_qty' => $amt), array('sal_id' => $_POST['salid']));
		echo '<div class="alert alert-success">
							<button class="close" data-dismiss="alert"></button>
							<strong><span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span> Success ! </strong> Product returned!
						</div>';
	} else {
		echo '<div class="alert alert-danger">
							<button class="close" data-dismiss="alert"></button>
							<strong><span class="glyphicon glyphicon-remove-circle" aria-hidden="true"></span> Error ! </strong> Problem recording return.try again
					</div>';
	}
} else if (isset($_POST['action']) && $_POST['action'] == "after_stock_returned") {
	//sql1
	$sql = "SELECT `sal_product_qty`, `sal_return_qty` FROM `stock_out_tbl` WHERE `sal_id`=" . $_POST['salid'];

	$stockDataToUpdateStockTotalValue  = db_get_table_sql($sql);
	$remaning_qty = ($stockDataToUpdateStockTotalValue[0]['sal_product_qty'] - $stockDataToUpdateStockTotalValue[0]['sal_return_qty']);

	$sql12 = "SELECT `p_price` FROM `product_tbl` WHERE `p_code` = '" . $_POST['spcode'] . "'";
	$getProductPrice  = db_get_table_sql($sql12);
	$product_price = $getProductPrice[0]['p_price'];

	$totalPriceAfterReturn = $product_price * $remaning_qty;
	db_update_values("stock_out_tbl", array('sal_total_amt' => $totalPriceAfterReturn), array('sal_id' => $_POST['salid']));

	/////
} else if (isset($_POST['action']) && $_POST['action'] == "get_pname_forModal") {
	$sql = "SELECT p_name from product_tbl where `p_code`='" . $_POST['code'] . "'";

	$res = db_get_table_sql($sql);
	//"product_tbl","p_name",array('p_name'=>$_POST['code']));
	echo json_encode($res[0]);
} else if (isset($_POST['action']) && $_POST['action'] == "get_package_details") {
	$res = db_get_table("package_product_tbl left join package_tbl on pp_pack_id=pack_id left join product_tbl on p_code=pp_product_code", "pack_name,pack_category,p_name,pp_product_qty", array('pack_id' => $_POST['packid']));
	if (count($res) > 0) {
		echo '<h4>Package Name : ' . $res[0]['pack_name'] . '</h4>
				<h4>Category : ' . $App->get_category_name($res[0]['pack_category']) . '</h4><br>
				Products';
		foreach ($res as $r) :
			echo '<p>' . $r['p_name'] . ' : ' . $r['pp_product_qty'] . ' qty</p>';
		endforeach;
	} else {
		echo "No product";
	}
}
//get package details and view in form for edit with delete btn
else if (isset($_POST['action']) && $_POST['action'] == "edit_package_products_form") {
	$res = db_get_table("package_product_tbl left join product_tbl on p_code=pp_product_code", "pp_product_code,pp_product_qty,p_name,pp_id", array('pp_id' => $_POST['ppid']));


	echo "<div class='msg'></div>";
	echo '<div class="col-md-3  ">
						<label for="InputUser">Product</label>
						<input type="text" class="form-control" name="name" value="' . $res[0]['p_name'] . '" readonly="readonly">
					</div>

					<div class="col-md-3 ">
						<label for="InputServiceCode">Product Code</label>
						<input type="text" class="form-control" name="name" value="' . $res[0]['pp_product_code'] . '" readonly="readonly">
					</div>

					<div class="col-md-2 control-label ">
						<label for="inputDOB">Quantity </label>
						<input type="text" class="form-control" name="qty" value="' . $res[0]['pp_product_qty'] . '"id="qty"/>
					</div>';
	echo '<button type="button" id="' . $_POST['ppid'] . '" class="btn btn-primary btn-update-package-product"> Update </button> </form>';
} else if (isset($_POST['action']) && $_POST['action'] == "edit-package-products") {
	db_update_values("package_product_tbl", array('pp_product_qty' => $_POST['qty']), array('pp_id' => $_POST['ppid']));
	echo '<div class="alert alert-success">
			<button class="close" data-dismiss="alert"></button>
			<strong><span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span> Success ! </strong> Updated Successfully!
		</div>';
} else if (isset($_POST['action']) && $_POST['action'] == "delete-package-product") {
	echo $_POST['ppid'];
	$sql = " DELETE from `package_product_tbl` where `pp_id`=" . $_POST['ppid'];
	echo $sql;
	$res = db_execute_sql($sql);
	echo $res;
} else if (isset($_POST['action']) && $_POST['action'] == "delete-user") {
	$sql = "DELETE from login_tbl where log_id=" . $_POST['uid'];
	$res = db_execute_sql($sql);
	echo $res;
} else if (isset($_POST['action']) && $_POST['action'] == "deactivate-user") {
	$res = db_update_values("login_tbl", array('is_active' => 0), array('log_id' => $_POST['uid']));
	echo $res;
} else if (isset($_POST['action']) && $_POST['action'] == "activate-user") {
	$res = db_update_values("login_tbl", array('is_active' => 1), array('log_id' => $_POST['uid']));
	echo $res;
}


//working with backkup database
else if (isset($_POST['action']) && $_POST['action'] == "backup-data") {
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);

	$host = $db[0];
	$database = $db[3];
	$user = $db[1];
	$pass = $db[2];
	if (!file_exists('./backup_database/')) {
		mkdir('./backup_database/', 0777, true);
	}
	$fileName = "backup-" . date("Y-m-d-H-i-s") . ".sql";
	$dir = "./backup_database/" . $fileName;

	// echo "<h3>Backing up database to <code>backup_database</code></h3>";

	exec(MYSQLDUMP . " --user={$user} --password={$pass} --host={$host} {$database} --result-file={$dir} 2>&1", $output);
	$data = array(
		'db_name' => $dir ? $dir : "data not found...",
		'db_created_date' => date('Y-m-d H:i:s'),
		'db_is_deleted' => 0,
	);
	if ($App->save('db_backups', $data)) {
		$msg = '<div class="backup_msg alert alert-success">
				<button type="button" class="close btn_cart_form_close btn-lg" data-dismiss="modal">Close X</button>
				<h4 class="modal-title"> Data Backeup Successfull.</h4>
			</div>';
		echo $msg;
	}
	// var_dump($output);
}

//working with backkup remove
else if (isset($_POST['action']) && isset($_POST['dbId']) && $_POST['action'] == "remove-data") {
	$dataName = "backup_database/" . $_POST['dataName'];
	if (file_exists($dataName)) {
		if (!is_dir($dataName)) {
			if (!unlink($dataName)) {
				echo ("$dataName cannot be deleted due to an error");
			} else {
				$sql = "DELETE from db_backups where db_id=" . $_POST['dbId'];
				$res = db_execute_sql($sql);
				echo $res;
			}
		}
	}
}
