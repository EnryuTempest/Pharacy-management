<?php
include "header.php";
?>
<div class="container-fluid">

    <div class="col-md-12 wrapper-pad" style="padding:20px 30px;">
        <!-- <div class="flash"></div> -->
        <div class="" style="display: flex; justify-content: space-between;">
            <h3><i class="	glyphicon glyphicon-list-alt" style="font-size:17px;"></i> Payments List</h3>
            <h3 class="">
                <a href="payment" class="small btn btn-success">
                    <i class="glyphicon glyphicon-plus"></i>&nbsp;New Payment
                </a>
            </h3>
        </div>
        <div class="row">
            <div class="bs-example-title" data-example-id="striped-table">
                <!----advance filter section --->
                <h4 class="followup-heading">Advance Filter</h4>
                <div class="advance_filter">
                    <div class="col-md-2  ">
                        <label for="InputUser">Member</label>
                        <input type="text" name="pay_custo_name" id="pay_custo_name" class="select2">
                    </div>

                    <div class="col-md-2 ">
                        <label for="InputServiceCode">Contact</label>
                        <input type="text" name="pay_custo_contact" id="pay_custo_contact" class="select2">
                    </div>
                    <div class="col-md-2 ">
                        <label for="InputServiceCode">Patient Type</label>
                        <input type="text" name="pay_custo_type" id="pay_custo_type" class="select2">
                    </div>

                    <div class="col-md-2 control-label ">
                        <label for="inputDOB">Date: From </label>
                        <input type="date" class="form-control" name="start_date" id="start_date" />
                    </div>

                    <div class="col-md-2 control-label ">
                        <label for="inputDOB">To</label>
                        <input type="date" class="form-control" name="end_date" id="end_date" />
                    </div>

                    <div class="col-md-2 control-label nopadding">
                        <button type="button" id="adv-filter" class="btn btn-warning btn_search" style="margin-top:23px"> <span class="glyphicon glyphicon-search" aria-hidden="true"></span> Search</button>
                    </div>
                </div>
            </div>
        </div>


        <h3 class="followup-heading">Payments History </h3>
        <!-- Add Member form -->
        <table class="table table-hover table-striped" id="viewsaletable" aria-describedby="viewtable_info">
            <thead>
                <tr role="row" style="background:#337ab7;color:#FFF;">
                    <th class="sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 60px;" aria-label="Name">S.No.</th>

                    <th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 150px;">Customer's Name</th>
                    <!-- <th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 100px;">Code</th> -->
                    <th class="" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 150px;" aria-label="Name">Contact Number</th>
                    <th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 100px;">Amount</th>
                    <!-- <th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 120px;">Remark</th> -->
                    <th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 90px;">Patient Type</th>
                    <th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 170px;">Date</th>
                    <th class="hidden-480" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 250px;">Action</th>
                </tr>
            </thead>
            <tbody>

            </tbody>
        </table>

    </div>
</div>
<!-- Modal -->
<div id="stock_returned" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close btn-lg" data-dismiss="modal">Close X</button>
                <h4 class="modal-title"> Stock Returned</h4>

            </div>
            <div class="modal-body">
                <div class="return_form"></div>
            </div>
            <div class="modal-footer">

            </div>
        </div>

    </div>
</div>
<!-- End Main container -->
<?php include "pro_pic_model.html"; ?>
<?php include "footer.php"; ?>
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>css/demo_table.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>css/buttons.dataTables.min.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>css/buttons.foundation.min.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>css/buttons.jqueryui.min.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>css/buttons.bootstrap4.min.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>css/buttons.semanticui.min.css" />

<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/buttons.bootstrap4.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/buttons.html5.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/buttons.jqueryui.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/buttons.semanticui.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/buttons.flash.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/buttons.colVis.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/jszip.min.js"></script>

<script type="text/javascript">
    $(document).ready(function() {
        var table;
        table = $('#viewsaletable').dataTable({
            "aaSorting": [
                [0, 'desc']
            ],
            "bProcessing": true,
            "bRetrieve": true,
            "bServerSide": true,
            "pagingType": "simple",
            "sAjaxSource": "<?php echo _DOMAIN_; ?>admin/zform/view_payments_list_server",
            "fnServerData": function(sSource, aoData, fnCallback) {
                aoData.push({
                    "name": "pay_custo_name",
                    "value": $("#pay_custo_name").val()
                }, {
                    "name": "pay_custo_contact",
                    "value": $("#pay_custo_contact").val()
                }, {
                    "name": "pay_custo_type",
                    "value": $("#pay_custo_type").val()
                }, {
                    "name": "start_date",
                    "value": $("#start_date").val()
                }, {
                    "name": "end_date",
                    "value": $("#end_date").val()
                });
                $.getJSON(sSource, aoData, function(json) {
                    fnCallback(json);
                })
            },
            "aoColumnDefs": [{
                'bSortable': true,
                'aTargets': [0]
            }],
            "bAutoWidth": false,
            "dom": 'lBfrtip',
            "buttons": [{
                extend: 'excel',
                messageTop: 'Stock Out History ',
                exportOptions: {
                    columns: ':visible',
                }
            }, 'colvis'],
            columnDefs: [{
                targets: -1,
                visible: false
            }]
        });

        $("#adv-filter").click(function() {
            table.fnDraw();
        });

        //submit the form
        $(document).on("click", "#submit_return_form", function() {
            if ($("input[type=hidden]").hasClass("ret-left")) {
                var takenqty = $(".ret-left").val();

            } else {
                var takenqty = $(".taken").val();
            }
            var returnedqty = $("#ret_qty").val();

            if (parseInt(takenqty) < parseInt(returnedqty)) {
                $(".msg").html('<div class="alert alert-warning"><button class="close" data-dismiss="alert"></button><strong><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Error ! </strong> Quantity entered is greater than left</div>');
            } else if ((returnedqty == "") || (parseInt(returnedqty) == 0)) {
                $(".msg").html('<div class="alert alert-warning"><button class="close" data-dismiss="alert"></button><strong><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Error ! </strong> Enter the quantity</div>');
            } else {
                dataString = "action=stock_returned&salid=" + $("#sid").val() + "&rqty=" + returnedqty + "&spcode=" + $("#spcode").val();
                // alert(dataString);
                $.ajax({
                    type: "POST",
                    url: "<?php echo _DOMAIN_; ?>admin/dal",
                    data: dataString,
                    dataType: "html",
                    success: function(data) {
                        $(".msg").html(data);
                        $("#ret_qty").val("");
                        table.fnDraw();
                    }
                })
            }
        })

        $(document).on("click", ".btn-del-stockout", function() {
            var id = $(this).attr("sid");
            var result = confirm("Are you sure you want to delete this stockout history?");
            if (result) {
                data = "action=delete-stockout&salid=" + id;
                $.post("<?php echo _DOMAIN_; ?>admin/dal", data, function(res) {
                    table.fnDraw();
                })
            }
        });


        /**
         * DELETE PAYMENTS (SOFT DELETE);
         * by pay_status column         * 
         */
        $(document).on("click", ".btn_get_payment_delete", function() {
            var payId = $(this).attr("payId");
            var result = confirm("Are you sure want to delete ?");
            if (result) {
                data = "action=deletePpayment&payId=" + payId;
                $.post("<?php echo _DOMAIN_; ?>admin/dal", data, function(res) {
                    table.fnDraw();
                })
            }

        });
    });
</script>
<script src="<?php echo _DOMAIN_; ?>js/ajax.js"></script>