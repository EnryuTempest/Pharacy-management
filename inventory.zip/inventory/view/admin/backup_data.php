<?php include "header.php"; ?>
<div class="container-fluid">

    <div class="col-md-12 wrapper-pad" style="padding:20px 30px;">
        <div class="msg">

        </div>
        <div class="" style="display: flex; justify-content: space-between;">
            <h3><i class="	glyphicon glyphicon-list-alt" style="font-size:17px;"></i> Payments List</h3>
            <h3 class="">
                <button class="small btn btn-success" id="btn_get_backup_db">
                    <i class="glyphicon glyphicon-upload"></i>&nbsp;Backup Data
                </button>
            </h3>
        </div>
        <div class="row">
            <div class="bs-example-title" data-example-id="striped-table">
                <!----advance filter section --->
                <h4 class="followup-heading">Advance Filter</h4>
                <div class="advance_filter">
                    <div class="col-md-6 control-label ">

                    </div>
                    <div class="col-md-2 control-label ">
                        <label for="inputDOB">Date: From </label>
                        <input type="date" class="form-control" name="start_date" id="start_date" />
                    </div>

                    <div class="col-md-2 control-label ">
                        <label for="inputDOB">To</label>
                        <input type="date" class="form-control" name="end_date" id="end_date" />
                    </div>

                    <div class="col-md-2 control-label nopadding">
                        <button type="button" id="adv-filter" class="btn btn-warning btn_search" style="margin-top:23px"> <span class="glyphicon glyphicon-search" aria-hidden="true"></span> Search</button>
                    </div>
                </div>
            </div>
        </div>


        <h3 class="followup-heading">Payments History </h3>
        <!-- Add Member form -->
        <table class="table table-hover table-striped" id="viewsaletable" aria-describedby="viewtable_info">
            <thead>
                <tr role="row" style="background:#337ab7;color:#FFF;">
                    <th class="sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 60px;" aria-label="Name">S.No.</th>
                    <th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 150px;">File</th>
                    <th class="" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 150px;" aria-label="Date">Date</th>
                    <th class="" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 150px;" aria-label="Action">Action</th>
                </tr>
            </thead>
            <tbody>

            </tbody>
        </table>

    </div>
</div>
<?php include "pro_pic_model.html"; ?>
<?php include "footer.php"; ?>
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>css/demo_table.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>css/buttons.dataTables.min.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>css/buttons.foundation.min.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>css/buttons.jqueryui.min.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>css/buttons.bootstrap4.min.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>css/buttons.semanticui.min.css" />

<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/buttons.bootstrap4.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/buttons.html5.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/buttons.jqueryui.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/buttons.semanticui.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/buttons.flash.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/buttons.colVis.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>js/jszip.min.js"></script>

<script type="text/javascript">
    $(document).ready(function() {
        var table;
        table = $('#viewsaletable').dataTable({
            "aaSorting": [
                [0, 'desc']
            ],
            "bProcessing": true,
            "bRetrieve": true,
            "bServerSide": true,
            "pagingType": "simple",
            "sAjaxSource": "<?php echo _DOMAIN_; ?>admin/zform/view_db_backup_server",
            "fnServerData": function(sSource, aoData, fnCallback) {
                aoData.push({
                    "name": "start_date",
                    "value": $("#start_date").val()
                }, {
                    "name": "end_date",
                    "value": $("#end_date").val()
                });
                $.getJSON(sSource, aoData, function(json) {
                    fnCallback(json);
                })
            },
            "aoColumnDefs": [{
                'bSortable': true,
                'aTargets': [0]
            }],
            "bAutoWidth": false,
            "dom": 'lBfrtip',
            "buttons": [{
                extend: 'excel',
                exportOptions: {
                    columns: ':visible',
                }
            }, 'colvis'],
            columnDefs: [{
                targets: -1,
                visible: false
            }]
        });

        $("#adv-filter").click(function() {
            table.fnDraw();
        });


        $(document).on("click", ".btn_cart_form_close", function() {
            $(".backup_msg").fadeOut();
        });

        $(document).on("click", "#btn_get_backup_db", function() {
            var result = confirm("Are you sure want to backup ?");
            if (result) {
                data = "action=backup-data";
                $.post("<?php echo _DOMAIN_; ?>admin/dal", data, function(res) {
                    table.fnDraw();
                    $(".msg").html(res);
                })
            }

        });
        $(document).on("click", ".remove-data", function() {
            var result = confirm("Are you sure want to remove ?");
            var dbId = $(this).attr('dbId');
            var dataName = $(this).attr('dataName');
            if (result) {
                data = `action=remove-data&dbId=${dbId}&dataName=${dataName}`;
                $.post("<?php echo _DOMAIN_; ?>admin/dal", data, function(res) {
                    table.fnDraw();
                    $(".msg").html(res);
                })
            }

        });

    });
</script>
<script src="<?php echo _DOMAIN_; ?>js/ajax.js"></script>
<?php
?>