<?php include "header.php"; ?>
<?php include "stockin_product.php";?>
<!-- Main container area -->
<div class="container-fluid nopadding" style="border:1px #CCC solid;background:#FFF;">
	<div class="col-md-12 wrapper-pad" style="padding:0px 30px 20px;">
	
	<div class="cart_msg"></div>
	<!-- View list of existing groups -->
		<h3>List of Standard Products </h3>
		<table class="table table-hover table-striped" id="product_table" aria-describedby="sample_2_info">
			<thead>
				<tr role="row" style="background:#337ab7;color:#FFF;">
<th class="sorting" role="columnheader" tabindex="0" aria-controls="viewtable" rowspan="1" colspan="1" style="width: 70px;" aria-label="Name">S.No.</th>					

					<th class="sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" style="width: 150px;" aria-label="Name">Product Name</th>
					<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" style="width: 150px;"> Main Category</th>
					<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" style="width: 120px;"> Standard Qty</th>
					<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" style="width: 100px;">Current Stock</th>
					<th class="hidden-480 sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" style="width: 250px;">Remark</th>
				</tr>
			</thead>
			<tbody >
				
			</tbody>
		</table>
	</div>
</div><!-- End Main container -->

<?php include "footer.php";?>
 <link rel="stylesheet" href="<?php echo _DOMAIN_;?>css/demo_table.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_;?>css/buttons.bootstrap4.min.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_;?>css/buttons.dataTables.min.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_;?>css/buttons.foundation.min.css" />
<link rel="stylesheet" href="<?php echo _DOMAIN_;?>css/buttons.jqueryui.min.css" />

<link rel="stylesheet" href="<?php echo _DOMAIN_;?>css/buttons.semanticui.min.css" />

<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/buttons.bootstrap4.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/buttons.html5.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/buttons.jqueryui.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/buttons.semanticui.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/buttons.flash.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/jszip.min.js"></script>
<script type="text/javascript">
    var table;
    $(document).ready(function() {	
        table=$('#product_table').dataTable({
            "bProcessing": true,
            "bRetrieve": true,
            "bServerSide": true,
            "pagingType": "simple",
            "sAjaxSource": "<?php echo _DOMAIN_;?>admin/zform/view_standard_pro_server",
            "aaSorting" : [[0,"desc"]],
"dom": 'lBfrtip',
                "buttons": [
                {
                    extend: 'collection',
                    text: 'Export',
                    buttons: [
                        'excel',
                        'csv',                       
                    ]
                }]
        });
    })
</script>
