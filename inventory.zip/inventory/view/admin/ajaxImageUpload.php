 <?php
// define ("MAX_SIZE","20000"); 
function getExtension($str)
{
         $i = strrpos($str,".");
         if (!$i) { return ""; }
         $l = strlen($str) - $i;
         $ext = substr($str,$i+1,$l);
         return $ext;
}
$valid_formats = array("jpg","jpeg","png");
if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST") 
{
	if(isset($_GET['mem']) && $_GET['mem']=="image")
	{
		$uploaddir = "files/member/"; //a directory inside
	}
	else if(isset($_GET['product']) && $_GET['product']=="image")
	{
		$uploaddir = "files/product/"; //a directory inside
	}
    	 $filename = stripslashes($_FILES['photos']['name']);
        $size=filesize($_FILES['photos']['tmp_name']);
          $ext = getExtension($filename);
          $ext = strtolower($ext);
        if(in_array($ext,$valid_formats))
        {
	       	if ($size < (MAX_SIZE*1024))
	       	{
				$image_name=$filename;
				$newname=$uploaddir.$image_name;
				if(file_exists($newname))
				{
				   	$final_name=rand(1,1000)."-".$image_name;
				   	$newname =$uploaddir.$final_name;
				}
			  	$newname = str_replace(' ', '', $newname);
				if (move_uploaded_file($_FILES['photos']['tmp_name'],$newname)) 
				{
					//echo '<span class="imgList"><span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span> File Uploaded Successfully !</span>';
						echo $newname;
				}
				else
				{
					// exceeded the size limit! 
					echo "2";
				}
			}
			else
			{
					//You have exceeded the size limit!
		        echo "3";
			}
	       
        }
        else
        { 
			//echo '<span class="imgList error"><span class="glyphicon glyphicon-remove-circle" aria-hidden="true"></span> Unknown File extension!</span>';
			echo "4";
           
	    }
           
   //  }
}

?>