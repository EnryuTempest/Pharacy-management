<?php 
include "header.php";
require_once('plugins/zform/Zebra_Form.php'); 
?>
<?php
$form = new Zebra_Form('change_pwd_form', 'post', '', array('autocomplete' => 'off','class'=>'form-horizontal'));
//add the "Media title" element
$obj = $form->add('text', 'curr_pass','',array('class'=>'form-control'));
$obj->set_rule(array(
        'required'  =>  array('error', 'Current Password is required!'),
    ));
//add the "New pass" element
$obj = $form->add('password', 'new_pass','',array('class'=>'form-control'));
$obj->set_rule(array(
        'required'  =>  array('error', 'New Password is required!'),
        // 'alphanumeric'=>array('+,-,@,$,&','error','Only alphanumeric characters and special character +,-,@,$,& allowed!'),
    ));
//add the "confirm pass" element
$obj = $form->add('password', 'confirm_pass','',array('class'=>'form-control'));
 $obj->set_rule(array(
        'compare' => array('new_pass', 'error', 'Password not confirmed correctly!')
    ));
?>
<?php
if ($form->validate()) {
		$data=array(
			'password' => md5($_POST['new_pass']),
		);
		if($App->is_valid_password($page->user->userid,$page->user->user_info,$_POST['curr_pass']))
		{
			if(db_update_values('login_tbl',$data,array('log_id'=>$page->user->userid))>0)
			{
				$msg='<div class="alert alert-success">
								<button class="close" data-dismiss="alert"></button><span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span>
								<strong>Success ! </strong> Password has been updated successfully !
							</div>';
			}
			else
				{
					$msg='<div class="alert alert-danger">
								<button class="close" data-dismiss="alert"></button><span class="glyphicon glyphicon-remove" aria-hidden="true"></span>	<strong>Sorry ! </strong> problem !
							</div>';
				}
				$form->reset();
		}
		else
		{
		$msg='<div class="alert alert-danger">
								<button class="close" data-dismiss="alert"></button>
								<strong> <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> Failure ! </strong> Your current password is incorrect!
							</div>';
		
		}
}
?>

 

<div class="container nopadding" style="border:1px #CCC solid;background:#FFF;">
	<div class="col-md-12 wrapper-pad" style="padding:20px;">	
	<?php if(isset($msg)) echo $msg; ?>

		  	<div  style="padding:15px 30px 50px 30px;">

				<!-- Add form -->
				<form class="form-horizontals" method="post" id="change_pwd_form" name="change_pwd_form" >
					<?php
					$form->render('view/zform_template/change_pwd_zform.php');
					?>
				</form>
				<!-- ends form -->
			</div>
		
	</div>
</div>
<!-- End Main container -->
<?php include "footer.php";?>

