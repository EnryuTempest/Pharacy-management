<?php include "header.php"; ?>
<?php //include "sidebar.php"; 

// $MAC = exec('getmac');

// // Storing 'getmac' value in $MAC
// $MAC = strtok($MAC, ' ');

// // Updating $MAC value using strtok function, 
// // strtok is used to split the string into tokens
// // split character of strtok is defined as a space
// // because getmac returns transport name after
// // MAC address   
// echo "MAC address of Server is: $MAC";
?>




<div class="container-fluid " style="border:1px #CCC solid;background:#FFF;">
	<div class="col-md-12 wrapper-pad" style="padding:20px;">
		<div class="col-md-6 nopadding">
			<h4 style="padding-left:20px;">DASHBOARD</h4>

			<div class="col-xs-6 ">
				<div class="box_number text-center">
					<h1 class="box-title"><a href="product"><span class="glyphicon glyphicon-th-large" aria-hidden="true"></span>&nbsp;Total Products</a></h1>
					<!-- get_all_product(date("Y"),date("m")) -->
					<h1 class="text-center count"><?php echo $Product->get_all_products_for_dashboard(); ?></h1>

				</div>
			</div>
			<div class="col-xs-6 nopadding">
				<div class="box_number text-center">
					<h1 class="box-title"><a href="member"><span class="glyphicon glyphicon-scale" aria-hidden="true"></span>&nbsp;Stock Price</a></h1>
					<h1 class="text-center count"><span class='small'>NRs</span>&nbsp;<?php echo $Product->get_total_stock_price(); ?></h1>

				</div>
			</div>
		</div>
		<div class="col-md-6">
			<h4>Today's Statistics: <strong><?php echo date("d-M-Y"); ?></strong></h4>
			<div class="col-xs-6 nopadding">
				<div class="box_number text-center">

					<h1 class="box-title"><a href="stock_out"><span class="glyphicon glyphicon-inbox" aria-hidden="true"></span>&nbsp;Stock Out (<?php $today_sal = $App->get_todays_stockout_new(date("Y-m-d"));
																																					echo $today_sal['sal']; ?>) </a></h1>
					<h1 class="text-center count"><span class='small'>NRs</span>&nbsp;<?php echo $today_sal['tamt'] ? $today_sal['tamt'] : 0; ?> </h1>

				</div>
			</div>
			<div class="col-xs-6 ">
				<div class="box_number text-center">
					<h1 class="box-title"><a href="paymentsx_list"><span class="glyphicon glyphicon-inbox" aria-hidden="true"></span>&nbsp;In/Out-Patient </a></h1>
					<h1 class="text-center count">
						<span class='small'>NRs</span>&nbsp;<?php
															$inOutProduct = $Product->get_todays_in_out_patient();
															echo "" . ($inOutProduct['inPatient'] ? $inOutProduct['inPatient'] : 0) . "&nbsp;/&nbsp;" . ($inOutProduct['outPatient'] ? $inOutProduct['outPatient'] : 0) . "";
															?>
					</h1>
				</div>
			</div>
		</div>
		<?php $res = $Product->get_product_qty_5();

		if ($res != "") { ?>
			<div class="row">
				<div class="col-md-12" style="margin-top:20px;">
					<div class="bs-example-title">
						<h4><u> Less Stock Product's</u></h4>
						<div class="row">
							<?php echo $res; ?>
						</div>
					</div>
				</div>
			</div>
		<?php } ?>
	</div>
</div>

<?php include "footer.php"; ?>