<?php include "header.php"; ?>
<?php 
require_once('plugins/zform/Zebra_Form.php'); 
?>
<?php 
	

	$form = new Zebra_Form('addmem_form', 'post', '', array('autocomplete' => 'off','class'=>'form-horizontal'));
    $form->csrf(false,0);
		
	$obj = $form->add('hidden', 'c_id', '0');
	$obj = $form->add('hidden', 'submit_value', '0');
    $obj = $form->add('text', 'cname', '', array('autocomplete' => 'off','class'=>'form-control','placeholder'=>'Category Name is required'));
    $obj->set_rule(array(
        'required'  =>  array('error', 'Firstname is required!'),
    ));
		
	$obj = $form->add('select', 'main_cat', '', array('autocomplete' => 'off','class'=>'form-control','placeholder'=>'Main Category'));
	$obj->add_options(combo_values("category_tbl","c_id,c_name",array('c_main_category'=>0,'c_sub_category'=>0),"order by c_name asc"));
 	$obj->set_rule(array(
		// 'required'  => array('error', 'Source is required!'),
			));

	$obj = $form->add('select', 'sub_cat', '', array('autocomplete' => 'off','class'=>'form-control','placeholder'=>'Sub Category'));
	$obj->add_options(combo_values("category_tbl","c_id,c_name",array(),"c_main_category!=0 and c_sub_category=0"));
	$obj->set_rule(array(
			//'required'  => array('error', 'Source is required!'),
	));
	$form->add('submit', 'btnsubmit', 'Submit');

if(isset($_GET['edit']) && $_GET['edit']!="")
{
	$result=db_get_table('category_tbl','*',array('c_id'=>$_GET['edit']));
	
		$form->auto_fill(array(
			'c_id'  =>$result[0]['c_id'],
			'cname' =>$result[0]['c_name'],
			'main_cat' =>$result[0]['c_main_category'],
			'sub_cat'=>$result[0]['c_sub_category'],
		));
}
	if ($form->validate()) 
	{		
		$data=array(
			'c_name'			=>$_POST['cname'],
			'c_main_category'	=> $_POST['main_cat'],
			'c_sub_category' 	=> $_POST['sub_cat'],
		);	
		
			if(($_POST['main_cat']==""||$_POST['main_cat']==0) && $_POST['sub_cat']>0)
			{
				$msg='<div class="alert alert-warning">
						<button class="close" data-dismiss="alert"></button>
						<strong><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Error ! </strong> Select the main Category then sub category
					</div>';
			}
			else
			{
				if($_POST['c_id']=='0')
				{
					if(($id=$App->save('category_tbl',$data))>0)
					{
						$form->assign('submit_value', '1');
						$okmsg='<div class="alert alert-success">
								<button class="close" data-dismiss="alert"></button>
								<strong><span class="glyphicon glyphicon-ok-sign" aria-hidden="true"></span> Success !</strong>New category has been Submitted Successfully with ID :'.$id.'! Click <a href="add_category">here to continue</a>
							</div>';
					}
					else
					{
						$msg='<div class="alert alert-warning">
									<button class="close" data-dismiss="alert"></button>
									<strong><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Error ! </strong> problem adding new category.Click <a href="add_category">here to try again</a>
								</div>';
					}
					
				}
				else
				{
					db_update_values("category_tbl",$data,array('c_id'=>$_POST['c_id']));
					$msg='<div class="alert alert-success">
								<button class="close" data-dismiss="alert"></button>
								<strong><span class="glyphicon glyphicon-ok-sign" aria-hidden="true"></span> Success !</strong>Updated Successfully. Click <a href="'._DOMAIN_.'admin/add_category">here</a> to go back to catgeory table.
							</div>';
				}
		}
		
	}?>
<!-- Main container area -->
<div class="container-fluid nopadding" style="border:1px #CCC solid;background:#FFF;">
	<div class="col-md-12 wrapper-pad" style="padding:20px;">
	<div class="msg"><?php if(isset($msg)){echo $msg;}
	 						if(isset($okmsg)) {echo $okmsg;} ?></div>

		<div class="col-md-5" >
			<?php if(isset($_GET['edit']))
					echo '<h3><i class="glyphicon glyphicon-edit"></i> Edit Category </h3>';
				else
					echo '<h3><i class="glyphicon glyphicon-plus"></i> Add Category</h3>';?>
					<form class="form-horizontals" method="post" id="addmem_form" name="addmem_form" >
						<?php
						$form->render('view/zform_template/add_category_zform.php');
						?>
					</form><!-- ends form -->
		</div>
<div class="col-md-1" ></div>
		<div class="col-md-5" >
			<h3>Category List</h3>
			<div class="category_list">
				<?php echo $App->get_category_list($page->user->user_type);?>
			</div>
		</div>
	</div>
</div>	

<?php include "footer.php";?>
<script src="<?php echo _DOMAIN_;?>js/ajax.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	<?php if(isset($okmsg))
		{?>
			$(this).attr("disabled","true");
		<?php } ?>
})
	$(document).on("click","#submit",function(){
		
		
		<?php if(isset($okmsg))
		{?>
			$(this).attr("disabled","true");
		<?php } ?>
	})

	$(document).on("click",".btn-del-category",function(){
		var ele=$(this);
		var id=$(this).attr("cid");
		var result=confirm("Are you sure you want to delete the category?");
		if(result)
		{
			data="action=delete-category&cid="+id;
			$.post("<?php echo _DOMAIN_;?>admin/dal",data,function(res){
				if(res==1)
				{
					ele.parents("."+id+"").hide();
				}
				else
				{
					$(".msg").html(res).fadeOut(7000);
				}
			})
		}
	})
</script>

