<?php include "header.php"; ?>
<?php
require_once('plugins/zform/Zebra_Form.php');

?>
<?php
$cid = $Mem->get_last_mem_id();
$form = new Zebra_Form('addmem_form', 'post', '', array('autocomplete' => 'off', 'class' => 'form-horizontal'));
$form->csrf(false, 0);
//default value
$obj = $form->add('hidden', 'm_id', '0');
$obj = $form->add('hidden', 'hidden_m_image', '');

$obj = $form->add('text', 'm_fname', '', array('autocomplete' => 'off', 'class' => 'form-control', 'placeholder' => 'First Name'));
$obj->set_rule(array(
	'required'  =>  array('error', 'Firstname is required!'),
));
$obj = $form->add('text', 'm_mname', '', array('autocomplete' => 'off', 'class' => 'form-control', 'placeholder' => 'Middle Name'));
$obj = $form->add('text', 'm_lname', '', array('autocomplete' => 'off', 'class' => 'form-control', 'placeholder' => 'last Name'));
$obj->set_rule(array(
	'required'  => array('error', 'Lastname is required!'),
));
$obj = $form->add('text', 'm_phone', '', array('autocomplete' => 'off', 'class' => 'form-control', 'placeholder' => 'Phone Number'));
$obj->set_rule(array(
	'required'  => array('error', 'Contact is required!'),
	'digits'    => array('', 'error', 'Accepts only digits (0 to 9)'),
	'length'    => array(10, 10, 'error', 'Contact number must be valid.'),

));

$obj = $form->add('text', 'm_email', '', array('autocomplete' => 'off', 'class' => 'form-control', 'placeholder' => 'Email Address'));
$obj->set_rule(array(
	//'required'  => array('error', 'Email is required!'),
	'email'     =>  array('error', 'Email address seems to be invalid!')
));
$obj = $form->add('text', 'm_code', $cid, array('class' => 'form-control', 'readonly' => 'readonly'));
$obj->set_rule(array(
	'required'  => array('error', 'member code is required!'),
));
$obj = $form->add('text', 'm_add', '', array('class' => 'form-control'));
$obj->set_rule(array(
	'required'  => array('error', 'Address is required!'),
));
// $obj = $form->add('file', 'my_file_upload');

$form->add('submit', 'btnsubmit', 'Submit');

if (isset($_GET['edit'])) {
	//get the existing data to autofill for updating
	$result = db_get_table('members_tbl', '*', array('mem_id' => $_GET['edit']));
	$form->auto_fill(array(
		'm_id'  => $result[0]['mem_id'],
		'm_code' => $result[0]['mem_code'],
		'm_fname' => $result[0]['mem_fname'],
		'm_mname' => $result[0]['mem_mname'],
		'm_lname' => $result[0]['mem_lname'],
		'm_add' => $result[0]['mem_address'],
		'm_phone' => $result[0]['mem_contact'],
		'm_email' => $result[0]['mem_email'],
		'hidden_m_image' => $result[0]['mem_image'],
	));
}
?>
<?php

if ($form->validate()) {
	$memcode = $Mem->get_last_mem_id();
	$data = array(
		'mem_code'			=> $memcode,
		'mem_fname'			=> $_POST['m_fname'],
		'mem_mname' 		=> $_POST['m_mname'],
		'mem_lname' 		=> $_POST['m_lname'],
		'mem_address'		=> $_POST['m_add'],
		'mem_contact' 		=> $_POST['m_phone'],
		'mem_email'			=> $_POST['m_email'],
		'mem_image'			=> $_POST['hidden_m_image'],
		'mem_added_date'	=> date("Y-m-d H:i:s"),
		'mem_status'		=> 1,
	);

	if ($_POST['m_id'] == '0') {
		$id = $App->save('members_tbl', $data);
		if ($id > 0) {
			$okmsg = '<div class="alert alert-success">
								<button class="close" data-dismiss="alert"></button>
								<strong><span class="glyphicon glyphicon-ok-sign" aria-hidden="true"></span> Success ! </strong>New Patient has been Submitted Successfully with ID :' . $id . '! Click <a href="add_member">here to continue</a> 
						</div>';
		} else {
			$msg = '<div class="alert alert-warning">
								<button class="close" data-dismiss="alert"></button>
								<strong><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Error ! </strong> problem creating new member.Please check the member code which must be unique
							</div>';
		}
	} else {
		db_update_values("members_tbl", $data, array('mem_id' => $_POST['m_id']));
		$msg = '<div class="alert alert-success">
								<button class="close" data-dismiss="alert"></button>
								<strong><span class="glyphicon glyphicon-ok-sign" aria-hidden="true"></span> Success ! </strong> Patient detail has been successfully updated <span style="float:right;"><a href="member"><< Back to Patient list</a></span>
						</div>';
	}
} ?>
<!-- Main container area -->

<div class="container nopadding" style="border:1px #CCC solid;background:#FFF;">
	<div class="col-md-12 wrapper-pad" style="padding:20px;">

		<?php if (isset($msg)) {
			echo $msg;
		}
		if (isset($okmsg)) {
			echo $okmsg;
		} ?>

		<div style="padding:0px 30px 50px 30px;">
			<!-- Add student form -->
			<form class="form-horizontals" method="post" id="addmem_form" name="addmem_form">
				<?php
				$form->render('view/zform_template/addmem_zform.php');
				?>
			</form><!-- ends form -->

		</div>

	</div>
</div>
<!--end container-->
<?php include "footer.php"; ?>
<script type="text/javascript">
	$(document).ready(function() {
		var img = ($("#hidden_m_image").val());
		if (img != "") {
			$("#img_preview").html('<img src="<?php echo _DOMAIN_ . _MEMBER_IMAGE_; ?>' + img + '" target="_blank" class="img-responsive">');
		}
		$('input[type=file]').change(function() {

			console.log((this).value);
			$(this).simpleUpload("ajaxImageUpload?mem=image", {
				start: function(file) {
					$('#photos').html(file.name);
					$('#progress').html("");
					$('#progressBar').width(0);
				},
				progress: function(progress) {
					// $("#img_preview").append('<div class="col-md-2"><div class="doc_upload_box"><div class="gradient" id="ajax-loader"></div></div></div>');

					$('#progress').html("Progress: " + Math.round(progress) + "%");
					$('#progressBar').width(progress + "%");
				},

				success: function(data) {
					if (data == 4) {
						$(".display_msg").html('<span class="imgList"><span class="glyphicon glyphicon-remove-circle" aria-hidden="true"></span> Unknown File Extension !</span>');

					} else if (data == 2 || data == 3) {
						$(".display_msg").html('<span class="imgList"><span class="glyphicon glyphicon-remove-circle" aria-hidden="true"></span> File Size Exceed !</span>');

					} else if (data != 2 || data != 3 || data != 4) {
						$("display_msg").html("success");
						var name = data;
						var foldername = name.trim();
						var index = name.lastIndexOf("/");
						var filename = name.substring(index + 1);
						$("#hidden_m_image").val(filename);
						$("#img_preview").html('<img src="<?php echo _DOMAIN_; ?>' + foldername + '" target="_blank" class="img-responsive"> ');

					}
				}
			});
		});
	});
</script>
<script type="text/javascript" src="<?php echo _DOMAIN_ ?>js/ajax.js"></script>
<script type="text/javascript">
	$(document).ready(function() {

		<?php if (isset($okmsg)) { ?>
			$(this).attr("disabled", "true");
		<?php } ?>
	})
	$(document).on("click", "#submit", function() {

		<?php if (isset($okmsg)) { ?>
			$(this).attr("disabled", "true");
		<?php } ?>
	})
</script>