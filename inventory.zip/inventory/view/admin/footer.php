<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/jquery-3.4.0.js"></script> 
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/bootstrap.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/select2.min.js"></script> 
<script type="text/javascript" src="<?php echo _DOMAIN_;?>plugins/zform/public/javascript/zebra_form.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/jquery.dataTables.min.js" ></script>  
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/fontawesome.all.min.js"></script>
<script type="text/javascript" src="<?php echo _DOMAIN_;?>js/simpleUpload.min.js"></script>

<script type="text/javascript">
	$(document).ready(function(){
		var cnt=$(".cart_cnt").text();
		if(cnt>0)
		{
			$(".count_cart").css("display","block");
		}
	})
</script>
 <!-- <script src="<?php echo _DOMAIN_;?>js/jquery.form.js"></script> -->

<!-- Footer -->
<div class="clearfix"></div>
<div style="padding:20px;border-top:0px #7ca521 solid;">
All Rights Reserved, 2020
</div>
<!-- Ends -->
</body>


</html>
