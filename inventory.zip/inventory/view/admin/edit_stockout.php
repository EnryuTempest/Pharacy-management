<?php include "header.php"; ?>
<?php 
require_once('plugins/zform/Zebra_Form.php'); 

?>
<?php 
	$cid=$Mem->get_last_mem_id();
	
	$form = new Zebra_Form('edit_stockout_form', 'post', '', array('autocomplete' => 'off','class'=>'form-horizontal'));
    $form->csrf(false,0);
	//default value
	
	$obj = $form->add('hidden', 's_id', '0');
	
    $obj = $form->add('Select', 's_mem_code', '', array('autocomplete' => 'off','class'=>'form-control','placeholder'=>'Member'));
    $obj->add_options(combo_values_member("members_tbl","mem_code,mem_fname,mem_lname",array()));
    $obj->set_rule(array(
        'required'  =>  array('error', 'Firstname is required!'),
    ));
	
	$obj = $form->add('select', 's_product_code', '', array('autocomplete' => 'off','class'=>'form-control','placeholder'=>'product','readonly'=>'readonly'));
	$obj->add_options(combo_values("product_tbl","p_code,p_name",array()));
	$obj->set_rule(array(
        'required'  => array('error', 'Contact is required!'),
	));
   	$obj = $form->add('text', 's_product_qty','',array('class'=>'form-control','autocomplete' => 'off'));
    $obj->set_rule(array(
        'required'  => array('error', 'member code is required!'),
        'digits'    => array('', 'error', 'Accepts only digits (0 to 9)'),
    ));
	
   // $obj = $form->add('file', 'my_file_upload');

	$form->add('submit', 'btnsubmit', 'Submit');
	
	if(isset($_GET['edit'])){
		//get the existing data to autofill for updating
		$result=db_get_table('stock_out_tbl','*',array('sal_id'=>$_GET['edit']));
		$form->auto_fill(array(
			's_id'  =>$result[0]['sal_id'],
			's_mem_code'=>$result[0]['sal_mem_code'],
			's_product_code' =>$result[0]['sal_product_code'],
			's_product_qty' =>$result[0]['sal_product_qty'],
			
		));
	}
	?>
	<?php 
	
	if ($form->validate()) 
	{		
		$memcode=$Mem->get_last_mem_id();
			$data=array(
			'sal_mem_code'			=> $_POST['s_mem_code'],
			'sal_product_qty' 		=> $_POST['s_product_qty'],
			);	
			
			if($_POST['s_id']!='0')
			{
				db_update_values("stock_out_tbl",$data,array('sal_id'=>$_POST['s_id']));
				$msg='<div class="alert alert-success">
							<button class="close" data-dismiss="alert"></button>
							<strong><span class="glyphicon glyphicon-ok-sign" aria-hidden="true"></span> Success ! </strong> Successfully updated <span style="float:right;"><a href="member"><< Back to stockout list</a></span>
						</div>';
			}
	}?>
<!-- Main container area -->

<div class="container nopadding" style="border:1px #CCC solid;background:#FFF;">
	<div class="col-md-12 wrapper-pad" style="padding:20px;">

	<?php if(isset($msg)) echo $msg; ?>
			<div  style="padding:0px 30px 50px 30px;">
				<h3><i class="glyphicon glyphicon-edit"></i>Edit Stockout</h3>
			<!-- Add student form -->
				<form class="form-horizontals" method="post" id="edit_stockout_form" name="edit_stockout_form">
					<?php
					$form->render('view/zform_template/edit_stockout_zform.php');
					?>
				</form><!-- ends form -->
			</div>
	</div>
</div><!--end container-->
<?php include "footer.php";?>