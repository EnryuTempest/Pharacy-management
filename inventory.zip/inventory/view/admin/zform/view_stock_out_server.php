<?php
require_once "cgi-bin/objects.php";
/*
	 * Script:    DataTables server-side script for PHP and MySQL
	 * Copyright: 2010 - Allan Jardine
	 * License:   GPL v2 or BSD (3-point)
	 */

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	 * Easy set variables
	 */

/* Array of database columns which should be read and sent back to DataTables. Use a space where
	 * you want to insert a non-database field (for example a counter or static image)
	 */
$aColumns = array('sal_id', 'mem_fname', 'username', 'p_name', 'sal_product_qty', 'sal_return_qty', 'p_price', 'sal_date', 'mem_lname', 'p_code', 'p_image', 'sal_total_amt', 'username', 'sal_staff_id');
/* Indexed column (used for fast and accurate table cardinality) */
$sIndexColumn = "sal_id";
/* DB table to use */
$sTable = " `stock_out_tbl` left join members_tbl on sal_mem_code=mem_code left join product_tbl on sal_product_code=p_code left join login_tbl on  sal_staff_id = log_id";


/****filter */
$sCondition = "";

if (isset($_GET['start_date']) && $_GET['start_date'] != "" && $_GET['end_date'] == "") {
	$sCondition .= "`sal_date` between '" . $_GET['start_date'] . "' AND '" . date("Y-m-d") . "' AND ";
} else if (isset($_GET['end_date']) && $_GET['end_date'] != "" && $_GET['start_date'] == "") {
	$sCondition .= "`sal_date`< '" . $_GET['end_date'] . "' AND";
} else if ($_GET['end_date'] != "" && $_GET['start_date'] != "") {
	$sCondition .= "`sal_date` between '" . $_GET['start_date'] . "' AND '" . $_GET['end_date'] . "' AND ";
}


//get value for the adv filter 

if (isset($_GET['mem_code']) && ($_GET['mem_code'] != "" && $_GET['mem_code'] != "0")) {
	$sCondition .= "`mem_code`='" . $_GET['mem_code'] . "' AND ";
}
if (isset($_GET['product_code']) && ($_GET['product_code'] != "" && $_GET['product_code'] != "0")) {
	$sCondition .= "`sal_product_code`='" . $_GET['product_code'] . "' AND ";
}

$sCondition = substr_replace($sCondition, "", -4);


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	 * If you just want to use the basic configuration for DataTables with PHP server-side, there is
	 * no need to edit below this line
	 */
/* 
	/* 
	 * Paging
	 */
$sLimit = "";
if (isset($_GET['iDisplayStart']) && $_GET['iDisplayLength'] != '-1') {
	$sLimit = "LIMIT " . intval($_GET['iDisplayStart']) . ", " .
		intval($_GET['iDisplayLength']);
}


/*
	 * Ordering
	 */
$sOrder = "";
if (isset($_GET['iSortCol_0'])) {
	$sOrder = "ORDER BY  ";
	for ($i = 0; $i < intval($_GET['iSortingCols']); $i++) {
		if ($_GET['bSortable_' . intval($_GET['iSortCol_' . $i])] == "true") {
			$sOrder .= "`" . $aColumns[intval($_GET['iSortCol_' . $i])] . "` " .
				($_GET['sSortDir_' . $i] === 'asc' ? 'asc' : 'desc') . ", ";
		}
	}

	$sOrder = substr_replace($sOrder, "", -2);
	if ($sOrder == "ORDER BY") {
		$sOrder = "";
	}
}


/* 
	 * Filtering
	 * NOTE this does not match the built-in DataTables filtering which does it
	 * word by word on any field. It's possible to do here, but concerned about efficiency
	 * on very large tables, and MySQL's regex functionality is very limited
	 */
$sWhere = "";
if (isset($_GET['sSearch']) && $_GET['sSearch'] != "") {
	$sWhere = "WHERE (";
	for ($i = 0; $i < count($aColumns); $i++) {
		$sWhere .= "`" . $aColumns[$i] . "` LIKE '%" . $mysqli->real_escape_string($_GET['sSearch']) . "%' OR ";
	}
	$sWhere = substr_replace($sWhere, "", -3);
	$sWhere .= ')';
}

/* Individual column filtering */
for ($i = 0; $i < count($aColumns); $i++) {
	if (isset($_GET['bSearchable_' . $i]) && $_GET['bSearchable_' . $i] == "true" && $_GET['sSearch_' . $i] != '') {
		if ($sWhere == "") {
			$sWhere = "WHERE ";
		} else {
			$sWhere .= " AND ";
		}
		$sWhere .= "`" . $aColumns[$i] . "` LIKE '%" . $mysqli->real_escape_string($_GET['sSearch_' . $i]) . "%' ";
	}
}

///condition in sql
if ($sWhere == "" && $sCondition !== '')
	$sWhere .= 'where' . $sCondition . '';
else if ($sCondition !== "")
	$sWhere .= 'and' . $sCondition . ' ';


/*
	 * SQL queries
	 * Get data to display
	 */
$sQuery = "
		SELECT SQL_CALC_FOUND_ROWS `" . str_replace(" , ", " ", implode("`, `", $aColumns)) . "`
		FROM  $sTable
		$sWhere
		$sOrder
		$sLimit
		";

$rResult = $mysqli->query($sQuery);
//echo $sQuery;
$sQuery = "
		SELECT COUNT(`" . $sIndexColumn . "`) as 'count'
		FROM $sTable $sWhere
	";
$rResultTotal = $mysqli->query($sQuery);
$rResultTotal = mysqli_fetch_assoc($rResultTotal);
$iTotal = $rResultTotal["count"];
$iFilteredTotal = $iTotal;

/*
	 * Output
	 */
$output = array(
	"sEcho" => intval($_GET['sEcho']),
	"iTotalRecords" => $iTotal,
	"iTotalDisplayRecords" => $iFilteredTotal,
	"aaData" => array()
);
$sn = 1;
$value = 0.00;
while ($aRow = mysqli_fetch_array($rResult)) {
	$row = array();
	for ($i = 0; $i < count($aColumns); $i++) {
		if ($i == 0) {
			$row[] = $sn;
		} else if ($i == 1) {
			$row[] = $aRow['mem_fname'] . ' ' . $aRow['mem_lname'];
		} else if ($i == 3) {
			$row[] = '<a href="#" class="p_image_hover" data-toggle="modal" data-target="#product_image" pimg="' . $aRow['p_image'] . '">' . $aRow['p_name'] . '</a>';
		} else if ($i == 5) {
			if ($aRow['sal_return_qty'] > 0) {
				$row[] = $aRow['sal_return_qty'];
			} else {
				$row[] = "-";
			}
		} else if ($i == 7) {
			// $tamt = ($aRow['sal_product_qty'] - $aRow['sal_return_qty']) * $aRow['p_price'];
			$tamt = $aRow['sal_total_amt'];
			$value += $tamt;
			if ($tamt >= 0) {
				$row[] = $tamt;
			} else {
				$row[] = "-";
			}
		} else if ($i == 8) {
			$row[] = date("Y-M-d ", strtotime($aRow['sal_date']));
		} else if ($i == 9) {
			$qty_taken = $App->get_p_qty_taken($aRow['sal_id']);
			$q_already_ret = $App->get_qty_returned($aRow['sal_id']);
			if ($page->user->user_type == "1") {
				if (($aRow['sal_product_qty'] == $aRow['sal_return_qty']) || ($qty_taken['sal_product_qty'] == $q_already_ret['returned'])) {
					$row[] = '<a href="edit_stockout?edit=' . $aRow['sal_id'] . '" class="btn btn-default btn-primary btn-xs" ><i class="glyphicon glyphicon-edit"></i> Edit</a>&nbsp;&nbsp;
						<button class="btn btn-success btn-xs" sid="' . $aRow['sal_id'] . '" >Returned</button>&nbsp;&nbsp;
						<a href="#" sid="' . $aRow['sal_id'] . '" class="btn btn-default btn-danger btn-del-stockout btn-xs"><i class="glyphicon glyphicon-trash"></i> Delete</button>';
				} else {
					$row[] = '<a href="edit_stockout?edit=' . $aRow['sal_id'] . '" class="btn btn-default btn-primary btn-xs" ><i class="glyphicon glyphicon-edit"></i> Edit</a>&nbsp;&nbsp;
						<button class="btn_get_stock_return_form btn-warning btn-xs" pcode="' . $aRow['p_code'] . '" sid="' . $aRow['sal_id'] . '" data-toggle="modal" data-target="#stock_returned"> Return</button>&nbsp;&nbsp;
						<a href="#" sid="' . $aRow['sal_id'] . '" class="btn btn-default btn-danger btn-del-stockout btn-xs"><i class="glyphicon glyphicon-trash"></i>  Delete</button>';
				}
			} else {
				if (($aRow['sal_product_qty'] == $aRow['sal_return_qty']) || ($qty_taken['sal_product_qty'] == $q_already_ret['returned'])) {
					$row[] = '<a href="edit_stockout?edit=' . $aRow['sal_id'] . '" class="btn btn-default btn-primary btn-xs" ><i class="glyphicon glyphicon-edit"></i> Edit</a>&nbsp;&nbsp;
						<button class="btn btn-success btn-xs" sid="' . $aRow['sal_id'] . '" >Returned</button>&nbsp;&nbsp;';
				} else {
					$row[] = '<a href="edit_stockout?edit=' . $aRow['sal_id'] . '" class="btn btn-default btn-primary btn-xs" ><i class="glyphicon glyphicon-edit"></i> Edit</a>&nbsp;&nbsp;
						<button class="btn_get_stock_return_form btn-warning btn-xs" pcode="' . $aRow['p_code'] . '" sid="' . $aRow['sal_id'] . '" data-toggle="modal" data-target="#stock_returned"> Return</button>&nbsp;&nbsp;';
				}
			}
		} else if ($aColumns[$i] != ' ') {
			/* General output */
			$row[] = $aRow[$aColumns[$i]];
		}
	}
	$output['aaData'][] = $row;
	$sn++;
}
$row = array();
$row[] = "";
$row[] = "";
$row[] = "";
$row[] = "";
$row[] = "";
$row[] = "";
$row[] = "Total";
$row[] = $value;
$row[] = "";
$row[] = "";
$output['aaData'][] = $row;
echo json_encode($output);
