<?php
require 'cgi-bin/objects.php';
/*
	 * Script:    DataTables server-side script for PHP and MySQL
	 * Copyright: 2010 - Allan Jardine
	 * License:   GPL v2 or BSD (3-point)
	 */

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	 * Easy set variables
	 */

/* Array of database columns which should be read and sent back to DataTables. Use a space where
	 * you want to insert a non-database field (for example a counter or static image)
	 */
$aColumns = array('p_id', 'p_code', 'p_name', 'p_parent_cat', 'p_quantity', 'p_price', 'c_name');
/* Indexed column (used for fast and accurate table cardinality) */
$sIndexColumn = "p_id";
/* DB table to use */
$sTable = "`product_tbl` left join category_tbl on p_parent_cat=c_id";
$sCondition = "`p_is_available`=1 AND ";
if (isset($_GET['main_cat']) && ($_GET['main_cat'] != "" && $_GET['main_cat'] != 0)) {
	$sCondition .= "`p_parent_cat`=" . $_GET['main_cat'] . " AND ";
}
$sCondition = substr_replace($sCondition, "", -4);
$sgroup = "";
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	 * If you just want to use the basic configuration for DataTables with PHP server-side, there is
	 * no need to edit below this line
	 */
/* 
	/* 
	 * Paging
	 */
$sLimit = "";
if (isset($_GET['iDisplayStart']) && $_GET['iDisplayLength'] != '-1') {
	$sLimit = "LIMIT " . intval($_GET['iDisplayStart']) . ", " .
		intval($_GET['iDisplayLength']);
}


/*
	 * Ordering
	 */
$sOrder = "";
if (isset($_GET['iSortCol_0'])) {
	$sOrder = "ORDER BY  ";
	for ($i = 0; $i < intval($_GET['iSortingCols']); $i++) {
		if ($_GET['bSortable_' . intval($_GET['iSortCol_' . $i])] == "true") {
			$sOrder .= "`" . $aColumns[intval($_GET['iSortCol_' . $i])] . "` " .
				($_GET['sSortDir_' . $i] === 'asc' ? 'asc' : 'desc') . ", ";
		}
	}

	$sOrder = substr_replace($sOrder, "", -2);
	if ($sOrder == "ORDER BY") {
		$sOrder = "";
	}
}


/* 
	 * Filtering
	 * NOTE this does not match the built-in DataTables filtering which does it
	 * word by word on any field. It's possible to do here, but concerned about efficiency
	 * on very large tables, and MySQL's regex functionality is very limited
	 */
$sWhere = "";
if (isset($_GET['sSearch']) && $_GET['sSearch'] != "") {
	$sWhere = "WHERE (";
	for ($i = 0; $i < count($aColumns); $i++) {
		$sWhere .= "`" . $aColumns[$i] . "` LIKE '%" . $mysqli->real_escape_string($_GET['sSearch']) . "%' OR ";
	}
	$sWhere = substr_replace($sWhere, "", -3);
	$sWhere .= ')';
}

/* Individual column filtering */
for ($i = 0; $i < count($aColumns); $i++) {
	if (isset($_GET['bSearchable_' . $i]) && $_GET['bSearchable_' . $i] == "true" && $_GET['sSearch_' . $i] != '') {
		if ($sWhere == "") {
			$sWhere = "WHERE ";
		} else {
			$sWhere .= " AND ";
		}
		$sWhere .= "`" . $aColumns[$i] . "` LIKE '%" . $mysqli->real_escape_string($_GET['sSearch_' . $i]) . "%' ";
	}
}

///condition in sql
if ($sWhere == "" && $sCondition !== '')
	$sWhere .= 'where' . $sCondition . '';
else if ($sCondition !== "")
	$sWhere .= 'and' . $sCondition . ' ';

/*
	 * SQL queries
	 * Get data to display
	 */
$sQuery = "
		SELECT SQL_CALC_FOUND_ROWS `" . str_replace(" , ", " ", implode("`, `", $aColumns)) . "`
		FROM   $sTable
		$sWhere
		$sOrder
		$sLimit
		";
//echo $sQuery;
$rResult = $mysqli->query($sQuery);

$sQuery = "
		SELECT COUNT(`" . $sIndexColumn . "`) as 'count'
		FROM $sTable $sWhere
	";
//echo $sQuery;
$rResultTotal = $mysqli->query($sQuery);
$rResultTotal = mysqli_fetch_assoc($rResultTotal);
$iTotal = $rResultTotal['count'];
$iFilteredTotal = $iTotal;

/*
	 * Output
	 */
$output = array(
	"sEcho" => intval($_GET['sEcho']),
	"iTotalRecords" => $iTotal,
	"iTotalDisplayRecords" => $iFilteredTotal,
	"aaData" => array(),
);
$value = 0.00;
$tqty = 0;
$sn = 1;
while ($aRow = mysqli_fetch_array($rResult)) {
	$row = array();
	for ($i = 0; $i < count($aColumns) + 1; $i++) {
		if ($i == 0) {
			$row[] = $sn;
		} else if ($i == 3) {
			if ($aRow['p_parent_cat'] == 0) {
				$row[] = "-";
			} else {

				$row[] = $App->get_category_name($aRow['p_parent_cat']);
			}
		} else if ($i == 4) {
			$res = $Product->get_product_left($aRow['p_code']);

			if ($res['p_left'] == "") {
				$row[] = "0";
			} else {
				$tqty += $res['p_left'];
				$row[] = $res['p_left'];
			}
		} else if ($i == 5) {
			$row[] = $res['p_price'];
		} else if ($i == 6) {
			$value += $res['p_left'] * $aRow['p_price'];
			$row[] = $res['p_left'] * $aRow['p_price'];
		} else if ($i == 7) {
			$del = "";
			if ($page->user->user_type == "1") {
				$del = '&nbsp;&nbsp;<a href="#" code="' . $aRow['p_code'] . '" pid="' . $aRow['p_id'] . '" class="btn btn-danger btn-del-product btn-xs"><i class="glyphicon glyphicon-trash"></i> Delete</a>&nbsp;';
			}
			$row[] = '<a href="add_product?edit=' . $aRow['p_id'] . '" code="' . $aRow['p_code'] . '" class="btn btn-primary btn-edit-product btn-xs"><i class="glyphicon glyphicon-edit"></i>  Edit</a>&nbsp;
						 <button type="button" code="' . $aRow['p_code'] . '" pid="' . $aRow['p_id'] . '" class=" btn_stock_in btn btn-warning btn-xs" data-toggle="modal" data-target="#refill_stock" data-keyboard="false" data-backdrop="static"><i class="fas fa-plus"></i> Stock In </button>&nbsp;
						<button  type="button" class="btn btn-primary btn-xs btn-add-to-cart" code="' . $aRow['p_code'] . '" data-toggle="modal" data-keyboard="false" data-backdrop="static" data-target="#modal_add_to_cart"> <i class="fas fa-cart-plus"></i> Add to cart</button>
						<button  type="button" class="btn btn-success btn-xs btn-get-pro-det" code="' . $aRow['p_code'] . '" pid="' . $aRow['p_id'] . '" data-toggle="modal"  data-target="#modal_view_pro_detail"> <i class="fas fa-eye"></i> View</button>' . $del;
		} else if ($aColumns[$i] != ' ') {
			/* General output */
			$row[] = $aRow[$aColumns[$i]];
		}
	}
	$output['aaData'][] = $row;
	$sn++;
}
$row = array();
$row[] = "";
$row[] = "Total";
$row[] = "";
$row[] = "";
$row[] = $tqty;
$row[] = "";
$row[] = $value;
$row[] = "";
$output['aaData'][] = $row;
echo json_encode($output);
