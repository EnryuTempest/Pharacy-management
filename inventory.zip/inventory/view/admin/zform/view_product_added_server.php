<?php
require 'cgi-bin/objects.php';
/*
	 * Script:    DataTables server-side script for PHP and MySQL
	 * Copyright: 2010 - Allan Jardine
	 * License:   GPL v2 or BSD (3-point)
	 */

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	 * Easy set variables
	 */

/* Array of database columns which should be read and sent back to DataTables. Use a space where
	 * you want to insert a non-database field (for example a counter or static image)
	 */
$aColumns = array('p_add_id', 'p_name', 'p_add_pro_code', 'p_add_date', 'p_add_qty', 'p_add_price', 'p_add_note', 'p_name', 'p_image', 'p_parent_cat', 'p_id');
/* Indexed column (used for fast and accurate table cardinality) */
$sIndexColumn = "p_add_id";
/* DB table to use */
$sTable = "`product_added_tbl` left join product_tbl on p_code=p_add_pro_code";
$sCondition = "`p_is_available`=1 AND ";
if (isset($_GET['main_cat']) && ($_GET['main_cat'] != "0" && $_GET['main_cat'] != "")) {
	$sCondition .= " `p_parent_cat`=" . $_GET['main_cat'] . " AND ";
}
if (isset($_GET['start_date']) && $_GET['start_date'] != "" && $_GET['end_date'] == "") {
	$sCondition .= "`p_add_date` between '" . $_GET['start_date'] . "' AND '" . date("Y-m-d") . "' AND ";
} else if (isset($_GET['end_date']) && $_GET['end_date'] != "" && $_GET['start_date'] == "") {
	$sCondition .= "`p_add_date`< '" . $_GET['end_date'] . "' AND";
} else if ($_GET['end_date'] != "" && $_GET['start_date'] != "") {
	$sCondition .= "`p_add_date` between '" . $_GET['start_date'] . "' AND '" . $_GET['end_date'] . "' AND ";
}

if (isset($_GET['product_code']) && !empty($_GET['product_code'])) {
	$sCondition .= " `p_add_pro_code`='" . $_GET['product_code'] . "' AND ";
}
$sCondition = substr_replace($sCondition, "", -4);
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	 * If you just want to use the basic configuration for DataTables with PHP server-side, there is
	 * no need to edit below this line
	 */
/* 
	/* 
	 * Paging
	 */
$sLimit = "";
if (isset($_GET['iDisplayStart']) && $_GET['iDisplayLength'] != '-1') {
	$sLimit = "LIMIT " . intval($_GET['iDisplayStart']) . ", " .
		intval($_GET['iDisplayLength']);
}


/*
	 * Ordering
	 */
$sOrder = "";
if (isset($_GET['iSortCol_0'])) {
	$sOrder = "ORDER BY  ";
	for ($i = 0; $i < intval($_GET['iSortingCols']); $i++) {
		if ($_GET['bSortable_' . intval($_GET['iSortCol_' . $i])] == "true") {
			$sOrder .= "`" . $aColumns[intval($_GET['iSortCol_' . $i])] . "` " .
				($_GET['sSortDir_' . $i] === 'asc' ? 'asc' : 'desc') . ", ";
		}
	}

	$sOrder = substr_replace($sOrder, "", -2);
	if ($sOrder == "ORDER BY") {
		$sOrder = "";
	}
}


/* 
	 * Filtering
	 * NOTE this does not match the built-in DataTables filtering which does it
	 * word by word on any field. It's possible to do here, but concerned about efficiency
	 * on very large tables, and MySQL's regex functionality is very limited
	 */
$sWhere = "";
if (isset($_GET['sSearch']) && $_GET['sSearch'] != "") {
	$sWhere = "WHERE (";
	for ($i = 0; $i < count($aColumns); $i++) {
		$sWhere .= "`" . $aColumns[$i] . "` LIKE '%" . $mysqli->real_escape_string($_GET['sSearch']) . "%' OR ";
	}
	$sWhere = substr_replace($sWhere, "", -3);
	$sWhere .= ')';
}

/* Individual column filtering */
for ($i = 0; $i < count($aColumns); $i++) {
	if (isset($_GET['bSearchable_' . $i]) && $_GET['bSearchable_' . $i] == "true" && $_GET['sSearch_' . $i] != '') {
		if ($sWhere == "") {
			$sWhere = "WHERE ";
		} else {
			$sWhere .= " AND ";
		}
		$sWhere .= "`" . $aColumns[$i] . "` LIKE '%" . $mysqli->real_escape_string($_GET['sSearch_' . $i]) . "%' ";
	}
}
///condition in sql
if ($sWhere == "" && $sCondition !== '')
	$sWhere .= 'where' . $sCondition . '';
else if ($sCondition !== "")
	$sWhere .= 'and' . $sCondition . ' ';


/*
	 * SQL queries
	 * Get data to display
	 */
$sQuery = "
		SELECT SQL_CALC_FOUND_ROWS `" . str_replace(" , ", " ", implode("`, `", $aColumns)) . "`
		FROM   $sTable
		$sWhere
		$sOrder
		$sLimit
		";
//echo $sQuery;
$rResult = $mysqli->query($sQuery);

$sQuery = "
		SELECT COUNT(`" . $sIndexColumn . "`) as 'count'
		FROM $sTable $sWhere
	";

$rResultTotal = $mysqli->query($sQuery);
$rResultTotal = mysqli_fetch_assoc($rResultTotal);
$iTotal = $rResultTotal['count'];
$iFilteredTotal = $iTotal;

/*
	 * Output
	 */
$output = array(
	"sEcho" => intval($_GET['sEcho']),
	"iTotalRecords" => $iTotal,
	"iTotalDisplayRecords" => $iFilteredTotal,
	"aaData" => array(),
);

$sn = 1;
while ($aRow = mysqli_fetch_array($rResult)) {
	$row = array();
	for ($i = 0; $i < count($aColumns); $i++) {
		if ($i == 0) {
			$row[] = $sn;
		} else if ($i == 1) {
			$row[] = '<a href="#" class="p_image_hover" data-toggle="modal" data-target="#product_image" pimg="' . $aRow['p_image'] . '">' . $aRow['p_name'] . '</a>';
		} else if ($i == 3) {
			$row[] = date("Y-m-d h:i A", strtotime($aRow['p_add_date']));
		} else if ($i == 6) {
			if (empty($aRow['p_add_note'])) {
				$row[] = "-";
			} else {
				$row[] = $aRow['p_add_note'];
			}
		} else if ($i == 7) {
			$row[] = '<a href="stockIn?edit=' . $aRow['p_add_id'] . '" pid="' . $aRow['p_id'] . '" code="' . $aRow['p_add_pro_code'] . '" class="btn btn-primary btn-edit-stockin btn-xs" data_toggle="modal" data-target="#refill_stock_edit"> <i class="fas fa-edit"></i> Edit</a>';
		} else if ($aColumns[$i] != ' ') {
			/* General output */
			$row[] = $aRow[$aColumns[$i]];
		}
	}
	$output['aaData'][] = $row;
	$sn++;
}

echo json_encode($output);
