<?php
$page->user->login_required();
require "cgi-bin/objects.php";
$page->page_init('bootstrap', 'Inventory Management System| Dashboard', array(), array('bootstrap.min.css', 'dashboard.css', 'sidebar.css'));
?>
<link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,700,900" rel="stylesheet">
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>plugins/zform/public/css/zebra_form.css">
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>css/demo_table.css">
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>css/fontawesome.all.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo _DOMAIN_; ?>css/bootstrap-datepicker.css">
<link rel="stylesheet" type="text/css" href="<?php echo _DOMAIN_; ?>css/custom.css">
<link rel="stylesheet" type="text/css" href="<?php echo _DOMAIN_; ?>css/add_user.css" />
<link rel="stylesheet" type="text/css" href="<?php echo _DOMAIN_; ?>css/select2.css" />
<style>
	/* datatable's last row color */
	/* .dataTable>tbody>tr:last-child {
		background-color: #337ab7 !important;
		color: white;
	} */
</style>

</head>

<body>
	<nav class="navbar navbar-default">
		<div class="container-fluid nopadding">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" style="color:white;padding-left: 35px;" href="<?php echo _DOMAIN_; ?>admin/">Inventory </a>
			</div>
			<?php $count = $Product->get_p_cnt_inCart(); ?>

			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">
					<li><a href="<?php echo _DOMAIN_; ?>admin/">Dashboard</a></li>
					<?php if ($page->user->user_type == "1") { ?>
						<li class="dropdown"><a href="user"> User</a></li>

						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Patient</a>
							<ul class="dropdown-menu">
								<li><a href="add_member">Add New Patient</a></li>
								<li><a href="member">Patient List</a></li>
							</ul>
						</li>
					<?php } ?>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Product</a>
						<ul class="dropdown-menu">
							<li><a href="add_category"> Category</a></li>
							<li><a href="add_product">Add new Product</a></li>
							<li><a href="product">Product List</a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Stock</a>
						<ul class="dropdown-menu">
							<li><a href="stockIn"> Stock In History</a></li>
							<li><a href="stock_out"> Stock Out History</a></li>
							<li><a href="returned"> Return History</a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a href="cart"> Cart <span class="count_cart" style="display:none;"> (<span class="cart_cnt"><?php echo $count['cnt']; ?></span>)</span></a>
					</li>
					<!-- <li class="dropdown">
						<a href="payment"> Payment </a>
					</li> -->
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Payments</a>
						<ul class="dropdown-menu">
							<li><a href="payment"> Add Payment</a></li>
							<li><a href="payments_list"> Payments List</a></li>
							<!-- <li><a href="returned"> Return History</a></li> -->
						</ul>
					</li>
					<!--li><a href="product_report"> Standard  Report</a></li-->
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="glyphicon glyphicon-cog"></i>Settings</a>
						<ul class="dropdown-menu">
							<li><a href="change_password"><span class="glyphicon glyphicon-lock"></span> Change Password</a></li>
							<li><a href="backup_data"><span class="glyphicon glyphicon-download-alt"></span> Backup Data</a></li>
						</ul>
					</li>
					<li><a href="../logout">Logout <i class="glyphicon glyphicon-off"></i></a></li>
				</ul>
			</div><!-- /.navbar-collapse -->
		</div><!-- /.container-fluid -->
	</nav>
	<!--nav-->
	<!-- End Header -->
	<div class="clearfix"></div>