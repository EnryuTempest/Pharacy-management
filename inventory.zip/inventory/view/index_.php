<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="../../favicon.ico">
  <title>FEWWF</title>
  <!-- Bootstrap core CSS -->
  <link href="<?php echo _DOMAIN_; ?>css/bootstrap.min.css" rel="stylesheet">

  <style>
    .navbar-default {
      background: none;
      border: none;
      margin-bottom: 0px;
    }

    .navbar-default .navbar-nav>li>a,
    .navbar-default .navbar-brand {
      padding: 25px;
    }

    .intro {
      padding: 5% 15%;
    }

    .footer {
      padding: 30px 0px;
      background: #EEE;
      margin-top: 50px;
    }
  </style>
</head>

<body>
  <div class="container">
    <!--nav-->
    <nav class="navbar navbar-default">
      <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">FEWWF</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

          <ul class="nav navbar-nav navbar-right">
            <li><a href="<?php echo _DOMAIN_; ?>">HOME</a></li>
            <li><a href="<?php echo _DOMAIN_; ?>login">LOGIN</a></li>
            <li><a href="#">SIGNUP</a></li>
          </ul>
        </div><!-- /.navbar-collapse -->
      </div><!-- /.container-fluid -->
    </nav>
    <!--nav-->
  </div>
  <div class="row">
    <img src="<?php echo _DOMAIN_; ?>images/slide.jpg" class="img-responsive" />
  </div>
  <div class="container">
    <div class="intro text-center">

      <h1>About FEWWF</h1>
      <p>Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Cras mattis consectetur purus sit amet fermentum.Donec id elit
        non mi porta gravida at eget metus. Maecenas faucibus mollis interdum.vestibulum at eros. Cras mattis consectetur purus sit amet fermentum.
        Donec id elit non mi porta gravida at eget metus. Maecenas faucibus mollis interdum.</p>
    </div>

    <div class="row marketing">

    </div>
  </div> <!-- /container -->
  <footer class="footer">
    <div class="container">
      <p>&copy; 2018 Developed By Saayami Technology <img src="<?php echo _DOMAIN_; ?>images/saayami.jpg" style="width:100px;" /></p>
    </div>
  </footer>
</body>

</html>