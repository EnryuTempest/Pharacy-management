<?php 
  echo (isset($zf_error) ? $zf_error : (isset($error) ? $error : '')); 
  ?>

	<div class=" form-group">
		<div class="col-md-3">
			<label for="inputcategory"> Name</label>
			<?php echo $f_name;?>
		</div>
	
		<div class="col-md-3">
			<label for="InputUser"> Username </label>
			<?php echo $username;?>
		</div>
	
		<div class="col-md-3">
			<label for="InputUser"> Password </label>
			<?php echo $pass;?>
		</div>
		<div class="col-md-3">
			<label for="InputUser">Confirm Password </label>
			<?php echo $conf_pass;?>
		</div>
	</div>
	<div class=" form-group">
		<div class="col-md-3">
			<label for="InputUser"> Contact </label>
			<?php echo $contact;?>
			
		</div>
	
	</div>
	
	    <button type="Submit" id="submit" class=" btn btn-primary ">  Submit </button>
	
