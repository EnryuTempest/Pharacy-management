<div class="form-group">
	<?php
	echo (isset($zf_error) ? $zf_error : (isset($error) ? $error : ''));
	?>
</div>
<div class="form-group">
	<label for="exampleInputPassword1">Patient Full Name</label>
	<?php echo $pname; ?>
</div>
<div class="form-group">
	<label for="exampleInputPassword1">Contact</label>
	<?php echo $p_contact; ?>
</div>
<div class="form-group">
	<label for="exampleInputPassword1">Patient Type</label>
	<?php echo $p_type; ?>
</div>
<div class="form-group">
	<label for="exampleInputPassword1">Amount</label>
	<?php echo $p_amount; ?>
</div>
<div class="form-group" style="display: flex;">
	<?php echo $p_newCustomer_1 ? $p_newCustomer_1 : ''; ?>
	<label for="p_newCustomer" class="" style="margin: 10px;">Save Customer</label>
</div>
<div class="clearfix"></div>
<div class="form-group">
	<button type="submit" class="btn btn-primary" id="pro_submit">Submit</button>
</div>