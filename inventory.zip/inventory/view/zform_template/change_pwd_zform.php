<?php 
  echo (isset($zf_error) ? $zf_error : (isset($error) ? $error : '')); 
  ?>
  <div>
	<h3>Change Password Form</h3>
</div>
					
<div class="form-group">
	<div class="col-md-3 control-label">
		<label for="inputcurrpassword">Current Password</label>
		<?php echo $curr_pass; ?>
	</div>
	<div class="col-md-3 control-label">
		<label for="inputnewpassword">New Password</label>
		<?php echo $new_pass; ?>
	</div>

	<div class="col-md-3 control-label">
		<label for="inputnewpassword">Re-Type Password</label>
		<?php echo $confirm_pass; ?>
	</div>
	<button type="submit" class="btn btn-primary" id="submit">Submit</button>
</div>