<div class="form-group">
								<div class="col-xs-12" >
								 <?php echo $forget_password;?>
								</div>
							  </div>
							<div class="form-group">
							  <div class="col-xs-3" >
								<button type="submit" class="btn btn-default btn-green" id="reset_pass"><span class="glyphicon glyphicon-circle-arrow-right" aria-hidden="true"></span> Submit</button>
							</div>
							<div class="col-xs-9">
							<div class="flash"></div>
							</div>
							</div>

					