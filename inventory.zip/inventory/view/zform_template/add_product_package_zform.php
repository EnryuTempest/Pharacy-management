<?php 
  echo (isset($zf_error) ? $zf_error : (isset($error) ? $error : '')); 
  ?>

	<div class="form-group">
		<label for="inputcategory">Package </label>
		<?php echo $package;?>
	</div>
	<div class="">
		<label for="InputUser"> Product </label>
		<?php echo $pro_code;?>
		
	</div>
	<div class="form-group">
		<label for="InputUser">Quantity</label>
		<?php echo $qty;?>
		
	</div>
	
	<div class="form-group">
	    <button type="Submit" id="submit" class=" btn btn-primary  submit">  Submit </button>
	</div>
