<?php 
  echo (isset($zf_error) ? $zf_error : (isset($error) ? $error : '')); 
  ?>

	<div class="form-group">
		<label for="inputcategory">Package Name</label>
		<?php echo $name;?>
	</div>
	<div class="form-group">
		<label for="InputUser"> Category </label>
		<?php echo $category;?>
		
	</div>
	
	<div class="form-group">
	    <button type="Submit" id="submit" class=" btn btn-primary btn-view submit">  Submit </button>
	</div>
