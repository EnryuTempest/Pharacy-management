						<div class="login_controls">
							  <div class="form-group">
								<div class="col-xs-12">
								 <?php echo $uname;?>
								</div>
							  </div>
							  <div class="form-group">
								<div class="col-xs-12">
								  <?php echo $pass;?>
								</div>
							  </div>
									<div class="form-group">
									<div class="col-xs-12 center">
									<a href="#" data-toggle="modal" id="forgot_passa" class="forget" data-target="#forgot_pass">&raquo; Forgot Password ! </a>
									</div>
									</div>
										 <div class="form-group">
											<div class="col-xs-12">
											<button type="submit" class="btn btn-default btn_width100 btn-green" ><span class="glyphicon glyphicon-circle-arrow-right" aria-hidden="true"></span> Sign in</a>
											</div>
										</div>
							  </div>
						</div>	
					