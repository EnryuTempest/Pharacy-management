<?php 
  echo (isset($zf_error) ? $zf_error : (isset($error) ? $error : '')); 
  ?>

	<div class="form-group">
		<label for="inputcategory">Category Name</label>
		<?php echo $cname;?>
	</div>
	<div class="form-group">
		<label for="InputUser"> Parent Category </label>
		<?php echo $main_cat;?>
		
	</div>
	<div class="form-group">
		<label for="InputUser"> Child Category </label>
		<?php echo $sub_cat;?>
	</div>
	<div class="form-group">
	    <button type="Submit" id="submit" class=" btn btn-primary btn-view submit">  Submit </button>
	</div>
