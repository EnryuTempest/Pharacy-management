<?php
echo (isset($zf_error) ? $zf_error : (isset($error) ? $error : ''));
?>

<h3><i class="glyphicon	glyphicon-user" style="font-size:17px;"></i> Add Patient</h3>
<hr />
<div class="row">
	<div class="col-md-3">
		<div class="form-group">
			<label for="exampleInputName2">First Name</label>
			<?php echo $m_fname; ?>
		</div>
	</div>
	<div class="col-md-3">
		<div class="form-group">
			<label for="exampleInputName2">Middle Name</label>
			<?php echo $m_mname; ?>
		</div>
	</div>
	<div class="col-md-3">
		<div class="form-group">
			<label for="exampleInputName2">Last Name</label>
			<?php echo $m_lname; ?>
		</div>
	</div>
	<div class="col-md-3">
		<div class="form-group">
			<label for="exampleInputName2">Member Code</label>
			<?php echo $m_code; ?>
		</div>
	</div>

</div>
<div class="row">
	<div class="col-md-6">
		<div class="form-group">
			<label for="exampleInputName2"> Address</label>
			<?php echo $m_add; ?>
		</div>
	</div>
	<div class="col-md-6">
		<div class="form-group">
			<label for="exampleInputName2">Email Address </label>
			<?php echo $m_email; ?>
		</div>
	</div>
	<div class="col-md-4">
		<div class="form-group">
			<label for="exampleInputName2">Contact Number</label>
			<?php echo $m_phone; ?>
		</div>
	</div>

	<div class=" col-md-4 image_upload ">
		<div class="form-group">
			<label for="exampleInputName2">Profile Image</label>
			<input type="file" name="photos" id="photos">
			<div id="progress"></div>
			<div id="progressBar"></div>
			<div class="display_msg" style="color: red;"></div>
			<div id="img_preview"></div>
		</div>
	</div>
</div>

<button type="submit" class="btn btn-primary" id="submit">Submit</button>
<!-- ends form -->



</div>
</div>
<!--panel-body-->
</div>
<!--col-->

<div class="clearfix"></div>