<?php require_once('cgi-bin/objects.php');
echo (isset($zf_error) ? $zf_error : (isset($error) ? $error : ''));
?>

<div class="form-group">
	<div class=" col-md-4" style="margin-left:-15px;">
		<label for="exampleInputPassword1">Product Name*</label>
		<?php echo $pname; ?>
	</div>

	<!-- <div class=" col-md-4">
		<label for="exampleInputPassword1">CTEVT Standard Quantity</label>
		<?php //echo $st_qty; 
		?>
	</div> -->

	<div class=" col-md-4" style="margin-left:-15px;">
		<label for="exampleInputPassword1">Product Quantity*</label>
		<?php echo $p_qty; ?>
	</div>
	<div class="col-md-4">
		<label for="exampleInputPassword1">Price (Rs./piece)*</label>
		<?php echo $p_price; ?>
	</div>

</div>
<div class="form-group">

	<div class="col-md-4">
		<label for="exampleInputPassword1">Total Price (Rs)</label>
		<?php echo $tot_price; ?>
	</div>
	<div class=" col-md-4" style="margin-left:-15px;">
		<label for="exampleInputPassword1">Parent Category*</label>
		<?php echo $main_cat; ?>
	</div>
	<!-- <div class="col-md-4">
		<label for="exampleInputPassword1">Child Category 1 </label>
		<?php //echo $sub_cat; 
		?>
	</div> 
	<div class="col-md-4">
		<label for="exampleInputPassword1">Child Category 2</label>
		<?php //echo $p_leaf_cat; 
		?>
	</div> -->
</div>
<div class="form-group">
	<label for="exampleInputPassword1">Note</label>
	<?php echo $p_note; ?>
</div>
<!-- <div class="form-group">
	<label for="exampleInputPassword1">Product Image</label>
	<div class="image_upload ">
		<input type="file" name="photos" id="photos">
		<div id="progress"></div>
		<div id="progressBar"></div>
		<div class="display_msg" style="color: red;"></div>
		<div id="img_preview">

		</div>
	</div>
</div>
<?php //echo $pro_available_1 . $label_pro_available_1; 
?> -->

<div class="clearfix"></div>


<button type="submit" class="btn btn-primary submit_product" id="submit">Submit</button>