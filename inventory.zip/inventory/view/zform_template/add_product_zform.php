<?php 
  echo (isset($zf_error) ? $zf_error : (isset($error) ? $error : '')); 
  ?>
  <div class="form-group">
	    <label for="exampleInputPassword1">Product Name</label>
	    <?php echo $pname;?>
	</div>
	<div class="form-group">
	    <label for="exampleInputPassword1">Product Code</label>
	    <?php echo $pa_code;?>
	</div>
	<div class="form-group">
	    <label for="exampleInputPassword1">Product Quantity</label>
	    <?php echo $pa_qty;?>
	</div>
	<div class="form-group">
	    <label for="exampleInputPassword1">Price</label>
	    <?php echo $pa_price; ?>
	</div>
	<div class="form-group">
	    <label for="exampleInputPassword1">Note</label>
		<?php echo $pa_note; ?>  
	</div>
 			
			
			<div class="clearfix"></div>
			
			
			<button type="submit" class="btn btn-primary" id="pro_submit">Submit</button>