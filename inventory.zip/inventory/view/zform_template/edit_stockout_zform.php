<?php 
  echo (isset($zf_error) ? $zf_error : (isset($error) ? $error : '')); 
  ?>

	<div class="form-group">
		<label for="inputcategory">Member</label>
		<?php echo $s_mem_code;?>
	</div>
	<div class="form-group">
		<label for="InputUser"> Product </label>
		<?php echo $s_product_code;?>
		
	</div>
	<div class="form-group">
		<label for="InputUser"> Quantity </label>
		<?php echo $s_product_qty;?>
	</div>
	<div class="form-group">
	    <button type="Submit" id="submit" class=" btn btn-primary btn-view submit"> Update </button>
	</div>
