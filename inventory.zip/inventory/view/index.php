<?php
$page->page_init('bootstrap', 'FEWWF Application | Login', array('jquery.js', 'bootstrap.min.js'), array('bootstrap.min.css', 'login.css'));
require('cgi-bin/objects.php');
require('plugins/zform/Zebra_Form.php');
?>
<script type="text/javascript" src="<?php echo _DOMAIN_; ?>plugins/zform/public/javascript/zebra_form.js"></script>
<link rel="stylesheet" href="<?php echo _DOMAIN_; ?>plugins/zform/public/css/zebra_form.css" />
<div class="loginform">
  <?php
  $form = new Zebra_Form('login_form', 'post', '', array('autocomplete' => 'off'));
  $form->csrf(false, 0);
  $obj = $form->add('text', 'uname', '', array('autocomplete' => 'off', 'class' => 'form-control', 'placeholder' => 'UserName'));
  $obj->set_rule(array(
    'required'  =>  array('error', 'Username is required!'),
  ));
  $obj = $form->add('password', 'pass', '', array('autocomplete' => 'off', 'class' => 'form-control', 'placeholder' => 'Password'));
  $obj->set_rule(array(
    'required'  => array('error', 'Password is required!'),
    'length'    => array(4, 20, 'error', 'The password must have between 4 and 20 characters!'),
  ));
  $form->add('submit', 'btnsubmit', 'Submit');
  if ($form->validate()) {
    if ($page->user->is_valid_admin($_POST['uname'], $_POST['pass'])) {
      header("location:" . _DOMAIN_ . "admin/");
    } else {
      $msg = '<div class="alert alert-danger">
									<button class="close" data-dismiss="alert"></button>
									<span><span class="glyphicon glyphicon-remove-circle" aria-hidden="true"></span>Invalid username or password.</span>
								</div>';
    }
  }
  ?>
  <?php
  $form1 = new Zebra_Form('forgot_pass_form', 'post', '', array('autocomplete' => 'off'));
  //$form1->csrf(false,0);
  $obj = $form1->add('text', 'forget_password', '', array('autocomplete' => 'off', 'class' => 'form-control', 'placeholder' => 'Enter Email Address'));
  $obj->set_rule(array(
    'required'  =>  array('error', 'Email Address is required!'),
    'email'     => array('error', 'Email address seems to be invalid!')
  ));
  ?>
  <div class="container">
    <!-- Start Login -->
    <div class="loginbox">
      <h3 style="width:280px;margin:20px auto;padding-bottom:20px; text-align:center;">SAFAL HEALTH HOME</h3>

      <form name="login_form" id="login_form" method="post" action="" class="form-horizontal">
        <?php if (isset($msg)) echo $msg;
        $form->render('view/zform_template/login_zform.php');
        ?>
      </form>
    </div>
  </div><!-- End Panel -->
  <div class="clearfix"></div>
  <div>
    <div class="container">
      <p style="text-align:center;padding:0px 0px 20px 0px;margin-bottom:0px;">&copy; All Rights Reserved, 2020 </p>
    </div>

  </div>
</div>
<!-- Forget Password Modal -->
<div class="modal fade" id="forgot_pass" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="background: rgba(0,0,0,0.5);">
  <div class="modal-dialog modal-xs">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Forgot Password</h4>
      </div>
      <div class="modal-body">
        <p>Provide your Email Address to Retrieve your Password.</p>
        <form name="forgot_pass_form" id="forgot_pass_form" method="post" action="" class="form-horizontal">
          <?php $form1->render('view/zform_template/forgot_zform.php'); ?>
        </form>
        <div class="clearfix"></div>

      </div>
    </div>
  </div>
</div>
<!-- <script src="<?php echo _DOMAIN_; ?>js/css3-mediaqueries.js"></script> -->
<!-- <script src="<?php echo _DOMAIN_; ?>js/respond.src.js"></script> -->
</body>
<script type="text/javascript">
  $(document).ready(function() {
    $("#forgot_pass_form").submit(function(e) {
      var $form = $('#forgot_pass_form').data('Zebra_Form');
      if ($form.validate()) {
        e.preventDefault();
        dataString = $("#forgot_pass_form").serialize();
        $.ajax({
          type: "POST",
          url: "dal?forgot=1",
          data: dataString,
          dataType: "html",
          success: function(data) {
            console.log(data);
            if (data)
              $(".flash").html(data);
            $("#form1_div_loading").hide();
            $("#form1_div").fadeTo('fast', 1);
          }
        });
      }
      return false;
    });
    return false;
  });
</script>