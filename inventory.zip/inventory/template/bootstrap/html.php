<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $title;?></title>
<?php
//TO display all css initialized
foreach($css as $c) {
echo '<link rel="stylesheet" href="'.$this->domain.'css/'.$c.'" type="text/css"/>';
}
?>
<link rel="stylesheet/less" type="text/css" href="http://localhost/bootstrap/less/styles.less" />
<?php
foreach($js as $j)
		echo '<script src="'.$this->domain.'js/'.$j.'" type="text/javascript"></script>';
?>
<script type="text/javascript">
	var DOMAIN="<?php echo _DOMAIN_;?>";
	var PRODUCT_IMAGE="<?php echo _PRODUCT_IMAGE_;?>";
	var MEMBER_IMAGE="<?php echo _MEMBER_IMAGE_;?>";
</script>
<!-- </head>
<body> -->
